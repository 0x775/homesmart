#include "lvgl/lvgl.h"
#include "lv_drivers/display/fbdev.h"
#include "lvgl/examples/porting/lv_port_disp.h"
//#include "lv_ex_conf.h"

#include <sys/time.h>

//#include "lvgl/lvgl.h"
#include "lv_drivers/display/drm.h"
//#include "lv_drivers/indev/evdev.h"
//#include "lv_drivers/display/fbdev.h"
#include "lvgl/src/widgets/lv_img.h"
#include "lvgl/src/core/lv_event.h"
//#include "lvgl/examples/porting/lv_port_disp_template.h"
#include "lvgl/examples/porting/lv_port_indev.h"
#include <unistd.h>

#define DISP_BUF_SIZE (480 * 480)   /* lvgl 用于绘制屏幕的缓冲区 */

#define LVGL_TICK 	5


static lv_obj_t *label;
static lv_color_t buf[DISP_BUF_SIZE];
static lv_disp_draw_buf_t  disp_buf;

lv_disp_drv_t disp_drv;
lv_disp_t *disp;


void demo(void)
{
    lv_obj_t * label1 =  lv_label_create(lv_scr_act());

    /*Modify the Label's text*/
    lv_label_set_text(label1, "Hello world!");

    /* Align the Label to the center
     * NULL means align on parent (which is the screen now)
     * 0, 0 at the end means an x, y offset after alignment*/
    lv_obj_align(label1, LV_ALIGN_CENTER, 0, 0);
}

int main(int argc, char **argv)
{
    lv_init();  /* lvgl 初始化 */

    //lv_hal_init();
    
    lv_port_disp_init(); 

    /**
     * fb 初始化 此函数在 lv_drivers/display/fbdev.c 中
     * 就是打开 fb 设备映射显存出来使用
     */
    fbdev_init();

    lv_disp_draw_buf_init(&disp_buf, buf, NULL, DISP_BUF_SIZE);

    lv_disp_drv_init(&disp_drv);
    disp_drv.draw_buf = &disp_buf;
    disp_drv.flush_cb = fbdev_flush;    /* fbdev_flush这就是输入显示驱动提供的操作函数 */
    disp_drv.hor_res = 480;
    disp_drv.ver_res = 480;     
    disp = lv_disp_drv_register(&disp_drv);
    
    demo();

    
    //printf("width: %d, height: %d, dpi: %d\n", width, height, dpi);

    while(1)
    {
        lv_tick_inc(LVGL_TICK);
        lv_task_handler();
        usleep(5000);
    }
}

uint32_t my_tick(void)
{
	static uint64_t start_ms = 0;
	struct timeval tv_time;
	if(start_ms == 0) {
		gettimeofday(&tv_time, NULL);
		start_ms = (tv_time.tv_sec * 1000000 + tv_time.tv_usec) / 1000;
		}
	gettimeofday(&tv_time, NULL);

	uint64_t now_ms;
	now_ms = (tv_time.tv_sec * 1000000 + tv_time.tv_usec) / 1000;
	uint32_t time_ms = now_ms - start_ms;

	printf("time_ms = %d\n", time_ms);
	return time_ms;
}
