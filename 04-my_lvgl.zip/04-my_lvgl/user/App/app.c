﻿/**
 * @file lv_app.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../lvgl/lvgl.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./Page/mainwindow.h"
#include "./Page/screen_protection.h"
#include "./Page/voice_response.h"
#include "../../lv_conf.h"
#include "./Page/wifi.h"
#include <stdio.h>
#include <unistd.h>
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *par;
static lv_obj_t *label;
// static lv_obj_t * btnm;

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_wifi);
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);

LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);
//int is_checked_wifi=1;
char language_Chinese[100][256]; 
char language_English[100][256]; 
char language_setting[100][256];
int len;
static void obj_bar_anim_exec_callback(void *bar, int32_t value)
{
	    for (size_t i = 0; i <=len; )
    {
        strcpy(language_setting[i],language_Chinese[i]); 
        printf("i111=%s\n",language_setting[i]);
        i++;
    }
	FILE* fpflag;/*文件指针*/ 
	char sw_flag[5];
	memset(sw_flag, 0, sizeof(sw_flag));
	if ((fpflag = fopen("/userdata/sw_flag", "r")) == NULL){ 
	perror("fail to read flag");}
	else{
	fgets(sw_flag, 5, fpflag);fclose(fpflag);}
	//判断是否有网
	printf("sw_flag---------%s\n",sw_flag);
	if(sw_flag[0]=='y'){
	printf("3333333333333333\n");
	}
    if (bar != NULL)
    {
        lv_bar_set_value((lv_obj_t *)bar, value, LV_ANIM_OFF); // 设置进度条对象的值
        // lv_obj_t * label = lv_obj_get_child(par, 0);
        lv_label_set_text_fmt(label, "启动中%d%%", value);

        if (value == 100)
        {

	switch(sw_flag[0])
		{
	case 'y':
		mainwindow();
		break;
	case 0:
		network();
		break;
	default:
		network();
		}
	
      }
    }
}

void lv_app(void)
{
    //背景
    par = lv_obj_create(lv_scr_act());
    // lv_obj_set_size(par, 480, 480);
    LV_IMG_DECLARE(bg_loading1);       //声明图片
    par = lv_img_create(lv_scr_act()); //创建一个图像对象
    lv_img_set_src(par, &bg_loading1); //设置图片源
    lv_obj_center(par);

    // logo
    LV_IMG_DECLARE(logo_colour);

    lv_obj_t *img = lv_img_create(par);
    lv_img_set_src(img, &logo_colour);
    // lv_obj_center(img);
    lv_obj_align(img, LV_ALIGN_CENTER, 0, -30);

    label = lv_label_create(par);
    lv_obj_align(label, LV_ALIGN_CENTER, 0, 30);
    // LV_FONT_DECLARE(font_loading); //设置字体
    lv_obj_set_style_text_font(label, &font_loading, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(0xfefefe), 0);
    // lv_label_set_text(label, buf);
    lv_label_set_text_fmt(label, "启动中0%%");

    //进度条
    lv_obj_t *bar1 = lv_bar_create(par);
    // lv_obj_add_style(bar1, LV_BAR_PART_INDIC, &style);
    lv_obj_set_style_bg_color(bar1, lv_color_hex(0xfefefe), 0);                 // 设置背景颜色
    lv_obj_set_style_bg_color(bar1, lv_color_hex(0xfefefe), LV_PART_INDICATOR); // 设置背景颜色
    lv_obj_set_size(bar1, 200, 15);
    lv_obj_align(bar1, LV_ALIGN_CENTER, 0, 50);

    lv_anim_t anim;
    lv_anim_init(&anim);                                    // 初始化动画
    lv_anim_set_exec_cb(&anim, obj_bar_anim_exec_callback); // 添加回调函数
    lv_anim_set_time(&anim, 1000);                          // 设置动画时长
    lv_anim_set_var(&anim, bar1);                           // 动画绑定对象
    lv_anim_set_values(&anim, 0, 100);                      // 设置开始值和结束值
    lv_anim_set_repeat_count(&anim, 1);                     // 重复次数，默认值为1 LV_ANIM_REPEAT_INFINITE用于无限重复
    lv_anim_start(&anim);                                   // 应用动画效果

    // screen_protection();
    // voice_response();
    // add_scene();
}
