﻿/**
 * @file voice_response.h
 *
 */

#ifndef VOICE_RESPONSE_H
#define VOICE_RESPONSE_H

#ifdef __cplusplus
extern "C" {
#endif
    void voice_response(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*VOICE_RESPONSE_H*/
