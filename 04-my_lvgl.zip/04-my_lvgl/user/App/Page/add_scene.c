#include "add_scene.h"
#include "lvgl/lvgl.h"
#include "mainwindow.h"
#include "date.h"
lv_obj_t *page;
lv_obj_t *close_btn;

LV_IMG_DECLARE(bg_loading1);

LV_FONT_DECLARE(font_chs_16);
LV_FONT_DECLARE(font_scene_hint_10);
LV_FONT_DECLARE(lv_font_montserrat_18);

static void event_handler_close(lv_event_t *e)
{
   lv_obj_clean(page);
   lv_obj_del(page);
}

void add_scene()
{
   page = lv_obj_create(lv_scr_act());
   lv_obj_set_height(page, LV_SIZE_CONTENT);
   lv_obj_set_width(page, lv_pct(100));
   lv_obj_set_style_pad_all(page, 0, 0);
   lv_obj_set_style_border_width(page, 0, 0);
   lv_obj_set_style_radius(page, 0, 0);

   lv_obj_t *panel1 = lv_obj_create(page);
   lv_obj_set_size(panel1, lv_pct(100), 120);
   lv_obj_set_style_radius(panel1, 0, 0);
   lv_obj_set_style_border_width(panel1, 0, 0);
   lv_obj_set_style_bg_color(panel1, lv_color_hex(0x454C52), 0);
   lv_obj_align(panel1, LV_ALIGN_TOP_LEFT, 0, 0);

   lv_obj_t *label1 = lv_label_create(panel1);
   // lv_label_set_text(label1, "添加场景");
   lv_label_set_text(label1, language_setting[add_scene_label1]);
   lv_obj_set_style_text_font(label1, &font_chs_16, 0);
   lv_obj_align(label1, LV_ALIGN_TOP_LEFT, 5, 10);
   lv_obj_set_style_text_color(label1, lv_color_white(), 0);

   lv_obj_t *label2 = lv_label_create(panel1);
   // lv_label_set_text(label2, "您可以选择场景添加到主屏");
   lv_label_set_text(label2, language_setting[add_scene_label2]);
   lv_obj_set_style_text_font(label2, &font_scene_hint_10, 0);
   lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 5, 40);
   lv_obj_set_style_text_color(label2, lv_color_white(), 0);

   static lv_style_t close_style_btn;
   lv_style_init(&close_style_btn);
   lv_style_set_bg_color(&close_style_btn, lv_color_hex(0x454C52));
   lv_style_set_border_width(&close_style_btn, 0);
   lv_style_set_radius(&close_style_btn, 10);
   lv_style_set_shadow_width(&close_style_btn, 0);
   // lv_style_set_bg_opa(&close_style_btn, LV_OPA_0); // 设置背景的透明度

   close_btn = lv_btn_create(page);
   LV_IMG_DECLARE(icon_close);
   lv_obj_add_style(close_btn, &close_style_btn, 0);
   lv_obj_set_size(close_btn, 50, 50);
   lv_obj_set_pos(close_btn, 400, 25);
   lv_obj_t *add_img1 = lv_img_create(close_btn);
   lv_img_set_src(add_img1, &icon_close); //设置图片源
   lv_obj_align(add_img1, LV_ALIGN_CENTER, 0, 0);
   lv_obj_add_event_cb(close_btn, event_handler_close, LV_EVENT_CLICKED, NULL);

   lv_obj_t *panel2 = lv_obj_create(page);
   lv_obj_set_size(panel2, lv_pct(100), LV_SIZE_CONTENT);
   lv_obj_set_style_min_height(panel2, 358, 0);
   lv_obj_set_style_radius(panel2, 0, 0);
   lv_obj_set_style_border_width(panel2, 0, 0);
   lv_obj_align(panel2, LV_ALIGN_TOP_LEFT, 0, 122);
   //   lv_obj_set_style_bg_img_src(panel2,&bg_loading1,0);
   lv_obj_set_style_pad_all(panel2, 0, 0);

   lv_obj_t *bg_img = lv_img_create(panel2);
   lv_img_set_src(bg_img, &bg_loading1);
   lv_obj_set_size(bg_img, lv_pct(100), lv_pct(100));

   lv_obj_t *grid = lv_obj_create(panel2);
   lv_obj_set_size(grid, lv_pct(100), LV_SIZE_CONTENT);
   lv_obj_set_style_radius(grid, 0, 0);
   lv_obj_set_style_border_width(grid, 0, 0);
   lv_obj_set_style_bg_opa(grid, LV_OPA_0, 0);

   static lv_style_t style_btn;
   lv_style_init(&style_btn);
   lv_style_set_bg_color(&style_btn, lv_color_hex(0x80878C));
   lv_style_set_border_color(&style_btn, lv_palette_darken(LV_PALETTE_LIGHT_BLUE, 3));
   lv_style_set_border_width(&style_btn, 0);
   lv_style_set_radius(&style_btn, 10);
   lv_style_set_shadow_width(&style_btn, 0);
   lv_style_set_shadow_ofs_y(&style_btn, 5);
   lv_style_set_shadow_opa(&style_btn, LV_OPA_50);
   lv_style_set_text_color(&style_btn, lv_color_white());
   lv_style_set_width(&style_btn, 100);

   lv_obj_t *party_btn;
   LV_IMG_DECLARE(icon_party);
   party_btn = lv_btn_create(grid);
   lv_obj_add_style(party_btn, &style_btn, 0);
   lv_obj_set_size(party_btn, 210, 100);
   lv_obj_t *add_img2 = lv_img_create(party_btn);
   lv_img_set_src(add_img2, &icon_party); //设置图片源
   lv_obj_align(add_img2, LV_ALIGN_LEFT_MID, 0, 0);
   lv_obj_t *label_party = lv_label_create(party_btn);
   lv_obj_set_style_text_font(label_party, &lv_font_montserrat_18, 0);
   lv_label_set_text(label_party, "Party");
   lv_obj_align(label_party, LV_ALIGN_CENTER, 0, 0);

   lv_obj_t *away_btn;
   LV_IMG_DECLARE(icon_home);
   away_btn = lv_btn_create(grid);
   lv_obj_add_style(away_btn, &style_btn, 0);
   lv_obj_set_size(away_btn, 210, 100);
   lv_obj_t *add_img3 = lv_img_create(away_btn);
   lv_img_set_src(add_img3, &icon_home); //设置图片源
   lv_obj_align(add_img3, LV_ALIGN_LEFT_MID, 0, 0);
   lv_obj_t *label_home = lv_label_create(away_btn);
   lv_obj_set_style_text_font(label_home, &lv_font_montserrat_18, 0);
   lv_label_set_text(label_home, "Away");
   lv_obj_align(label_home, LV_ALIGN_CENTER, 0, 0);
   // lv_obj_set_pos(add_btn, 50, 300);

   /*Create the top panel*/
   static lv_coord_t grid_1_col_dsc[] = {LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};
   static lv_coord_t grid_1_row_dsc[] = {100, 100, LV_GRID_TEMPLATE_LAST};

   lv_obj_set_grid_dsc_array(grid, grid_1_col_dsc, grid_1_row_dsc);
   lv_obj_set_grid_align(grid, LV_GRID_ALIGN_SPACE_BETWEEN, LV_GRID_ALIGN_END);
   lv_obj_set_grid_cell(party_btn, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 0, 1);
   lv_obj_set_grid_cell(away_btn, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_CENTER, 0, 1);

   // static lv_coord_t grid_1_col_dsc[] = { LV_GRID_FR(1),  LV_GRID_TEMPLATE_LAST };
   // static lv_coord_t grid_1_row_dsc[] = {120, 360, LV_GRID_TEMPLATE_LAST };
   // lv_obj_set_grid_dsc_array(page, grid_1_col_dsc, grid_1_row_dsc);
   // lv_obj_set_grid_align(page, LV_GRID_ALIGN_SPACE_BETWEEN, LV_GRID_ALIGN_END);
   // lv_obj_set_grid_cell(panel1, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 0, 1);
   // lv_obj_set_grid_cell(panel2, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 1, 1);
}

void add_device()
{
   page = lv_obj_create(lv_scr_act());
   lv_obj_set_height(page, LV_SIZE_CONTENT);
   lv_obj_set_width(page, lv_pct(100));
   lv_obj_set_style_pad_all(page, 0, 0);
   lv_obj_set_style_border_width(page, 0, 0);
   lv_obj_set_style_radius(page, 0, 0);

   lv_obj_t *panel1 = lv_obj_create(page);
   lv_obj_set_size(panel1, lv_pct(100), 120);
   lv_obj_set_style_radius(panel1, 0, 0);
   lv_obj_set_style_border_width(panel1, 0, 0);
   lv_obj_set_style_bg_color(panel1, lv_color_hex(0x454C52), 0);
   lv_obj_align(panel1, LV_ALIGN_TOP_LEFT, 0, 0);

   lv_obj_t *label11 = lv_label_create(panel1);
   // lv_label_set_text(label11, "添加设备开关");
   lv_label_set_text(label11, language_setting[add_scene_label11]);
   lv_obj_set_style_text_font(label11, &font_chs_16, 0);
   lv_obj_align(label11, LV_ALIGN_TOP_LEFT, 5, 10);
   lv_obj_set_style_text_color(label11, lv_color_white(), 0);

   lv_obj_t *label22 = lv_label_create(panel1);
   // lv_label_set_text(label22, "您可以选择设备添加到主屏");
   lv_label_set_text(label22, language_setting[add_scene_label22]);
   lv_obj_set_style_text_font(label22, &font_scene_hint_10, 0);
   lv_obj_align(label22, LV_ALIGN_TOP_LEFT, 5, 40);
   lv_obj_set_style_text_color(label22, lv_color_white(), 0);

   static lv_style_t close_style_btn;
   lv_style_init(&close_style_btn);
   lv_style_set_bg_color(&close_style_btn, lv_color_hex(0x454C52));
   lv_style_set_border_width(&close_style_btn, 0);
   lv_style_set_radius(&close_style_btn, 10);
   lv_style_set_shadow_width(&close_style_btn, 0);
   // lv_style_set_bg_opa(&close_style_btn, LV_OPA_0); // 设置背景的透明度

   close_btn = lv_btn_create(page);
   LV_IMG_DECLARE(icon_close);
   lv_obj_add_style(close_btn, &close_style_btn, 0);
   lv_obj_set_size(close_btn, 50, 50);
   lv_obj_set_pos(close_btn, 400, 25);
   lv_obj_t *add_img1 = lv_img_create(close_btn);
   lv_img_set_src(add_img1, &icon_close); //设置图片源
   lv_obj_align(add_img1, LV_ALIGN_CENTER, 0, 0);
   lv_obj_add_event_cb(close_btn, event_handler_close, LV_EVENT_CLICKED, NULL);

   lv_obj_t *panel2 = lv_obj_create(page);
   lv_obj_set_size(panel2, lv_pct(100), LV_SIZE_CONTENT);
   lv_obj_set_style_min_height(panel2, 358, 0);
   lv_obj_set_style_radius(panel2, 0, 0);
   lv_obj_set_style_border_width(panel2, 0, 0);
   lv_obj_align(panel2, LV_ALIGN_TOP_LEFT, 0, 122);
   //   lv_obj_set_style_bg_img_src(panel2,&bg_loading1,0);
   lv_obj_set_style_pad_all(panel2, 0, 0);

   lv_obj_t *bg_img = lv_img_create(panel2);
   lv_img_set_src(bg_img, &bg_loading1);
   lv_obj_set_size(bg_img, lv_pct(100), lv_pct(100));

   lv_obj_t *grid = lv_obj_create(panel2);
   lv_obj_set_size(grid, lv_pct(100), LV_SIZE_CONTENT);
   lv_obj_set_style_radius(grid, 0, 0);
   lv_obj_set_style_border_width(grid, 0, 0);
   lv_obj_set_style_bg_opa(grid, LV_OPA_0, 0);

   static lv_style_t style_btn;
   lv_style_init(&style_btn);
   lv_style_set_bg_color(&style_btn, lv_color_hex(0x80878C));
   lv_style_set_border_color(&style_btn, lv_palette_darken(LV_PALETTE_LIGHT_BLUE, 3));
   lv_style_set_border_width(&style_btn, 0);
   lv_style_set_radius(&style_btn, 10);
   lv_style_set_shadow_width(&style_btn, 0);
   lv_style_set_shadow_ofs_y(&style_btn, 5);
   lv_style_set_shadow_opa(&style_btn, LV_OPA_50);
   lv_style_set_text_color(&style_btn, lv_color_white());
   lv_style_set_width(&style_btn, 100);

   lv_obj_t *light_btn;
   LV_IMG_DECLARE(icon_lignt_s_white);
   light_btn = lv_btn_create(grid);
   lv_obj_add_style(light_btn, &style_btn, 0);
   lv_obj_set_size(light_btn, 210, 100);
   lv_obj_t *add_img2 = lv_img_create(light_btn);
   lv_img_set_src(add_img2, &icon_lignt_s_white); //设置图片源
   lv_obj_align(add_img2, LV_ALIGN_LEFT_MID, 0, 0);
   lv_obj_t *label_light = lv_label_create(light_btn);
   lv_obj_set_style_text_font(label_light, &lv_font_montserrat_18, 0);
   lv_label_set_text(label_light, "Light");
   lv_obj_align(label_light, LV_ALIGN_CENTER, 0, 0);

   lv_obj_t *AC_btn;
   LV_IMG_DECLARE(icon_air_c_s);
   AC_btn = lv_btn_create(grid);
   lv_obj_add_style(AC_btn, &style_btn, 0);
   lv_obj_set_size(AC_btn, 210, 100);
   lv_obj_t *add_img3 = lv_img_create(AC_btn);
   lv_img_set_src(add_img3, &icon_air_c_s); //设置图片源
   lv_obj_align(add_img3, LV_ALIGN_LEFT_MID, 0, 0);
   lv_obj_t *label_AC = lv_label_create(AC_btn);
   lv_obj_set_style_text_font(label_AC, &lv_font_montserrat_18, 0);
   lv_label_set_text(label_AC, "AC");
   lv_obj_align(label_AC, LV_ALIGN_CENTER, 0, 0);
   // lv_obj_set_pos(add_btn, 50, 300);

   lv_obj_t *door_btn;
   LV_IMG_DECLARE(icon_EN_MG_s);
   door_btn = lv_btn_create(grid);
   lv_obj_add_style(door_btn, &style_btn, 0);
   lv_obj_set_size(door_btn, 210, 100);
   lv_obj_t *add_img4 = lv_img_create(door_btn);
   lv_img_set_src(add_img4, &icon_EN_MG_s); //设置图片源
   lv_obj_align(add_img4, LV_ALIGN_LEFT_MID, 0, 0);
   lv_obj_t *label_door = lv_label_create(door_btn);
   lv_obj_set_style_text_font(label_door, &lv_font_montserrat_18, 0);
   lv_label_set_text(label_door, "Door");
   lv_obj_align(label_door, LV_ALIGN_CENTER, 0, 0);

   lv_obj_t *floor_btn;
   LV_IMG_DECLARE(icon_fl_heat_s);
   floor_btn = lv_btn_create(grid);
   lv_obj_add_style(floor_btn, &style_btn, 0);
   lv_obj_set_size(floor_btn, 210, 100);
   lv_obj_t *add_img5 = lv_img_create(floor_btn);
   lv_img_set_src(add_img5, &icon_fl_heat_s); //设置图片源
   lv_obj_align(add_img5, LV_ALIGN_LEFT_MID, 0, 0);
   lv_obj_t *label_floor = lv_label_create(floor_btn);
   lv_obj_set_style_text_font(label_floor, &lv_font_montserrat_18, 0);
   lv_label_set_text(label_floor, "FloorHeat");
   lv_obj_align(label_floor, LV_ALIGN_CENTER, 0, 0);

   /*Create the top panel*/
   static lv_coord_t grid_1_col_dsc[] = {LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};
   static lv_coord_t grid_1_row_dsc[] = {100, 100, LV_GRID_TEMPLATE_LAST};

   lv_obj_set_grid_dsc_array(grid, grid_1_col_dsc, grid_1_row_dsc);
   lv_obj_set_grid_align(grid, LV_GRID_ALIGN_SPACE_BETWEEN, LV_GRID_ALIGN_END);
   lv_obj_set_grid_cell(light_btn, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 0, 1);
   lv_obj_set_grid_cell(AC_btn, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_CENTER, 0, 1);

   lv_obj_set_grid_cell(door_btn, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 1, 1);
   lv_obj_set_grid_cell(floor_btn, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_CENTER, 1, 1);
}