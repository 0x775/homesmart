/**
 * @file wifi.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
#include "../../../lvgl/src/misc/lv_timer.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "code.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX_LINE 1024
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label_wifi0;
static lv_obj_t *label_wifi1;
static lv_obj_t *label_wifi2;
static lv_obj_t *label_wifi3;
static lv_obj_t *label_wifi4;
static lv_obj_t *label_wifi5;
static lv_obj_t *label_wifi6;
static lv_obj_t *label_wifi7;
static lv_obj_t *label_wifi8;
static lv_obj_t *label_wifi9;
static lv_obj_t *connect_img;
static lv_obj_t *label_connect;
/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_wifi);
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);

static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}
static void event_handler_network(lv_event_t *e)
{
    network();
}
static void event_handler_code2(lv_event_t *e)
{
    code2();
}

void code(void)
{
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);

    static lv_style_t drag_style;
    lv_style_init(&drag_style);
    lv_style_set_bg_color(&drag_style, lv_color_hex(0xe3e6e8));
    lv_style_set_border_width(&drag_style, 0);
    lv_style_set_radius(&drag_style, 10);
    lv_style_set_shadow_width(&drag_style, 0);
    lv_style_set_text_color(&drag_style, lv_color_hex(0x2f3338));
    lv_style_set_bg_opa(&drag_style, LV_OPA_70); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_network, LV_EVENT_CLICKED, NULL);

    label = lv_label_create(page);
    lv_label_set_text(label, "请先扫码下载[涂鸦智能]APP");
    LV_FONT_DECLARE(font_code_chs_12);
    lv_obj_set_style_text_font(label, &font_code_chs_12, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 55,85);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);


    lv_obj_t *code_img = lv_img_create(page);
    LV_IMG_DECLARE(icon_code1);
    lv_img_set_src(code_img, &icon_code1); //设置图片源
    lv_obj_align(code_img, LV_ALIGN_LEFT_MID, 115, 10);

    lv_obj_t *code_btn = lv_btn_create(page);
    LV_IMG_DECLARE(icon_code3);
    lv_obj_add_style(code_btn, &style_btn, 0);
    lv_obj_t *code3_img = lv_img_create(code_btn);
    lv_img_set_src(code3_img, &icon_code3); //设置图片源
    lv_obj_align_to(code_btn,code_img, LV_ALIGN_OUT_BOTTOM_LEFT, -5, 3);
    lv_obj_add_event_cb(code_btn, event_handler_code2, LV_EVENT_CLICKED, NULL);
}
void code2(void)
{
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);

    return_btn = lv_btn_create(page);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);

    label = lv_label_create(page);
    lv_label_set_text(label, "请用APP绑定此设备");
    LV_FONT_DECLARE(font_code_chs_12);
    lv_obj_set_style_text_font(label, &font_code_chs_12, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 98,85);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);


    lv_obj_t *code_img = lv_img_create(page);
    LV_IMG_DECLARE(icon_code2);
    lv_img_set_src(code_img, &icon_code2); //设置图片源
    lv_obj_align(code_img, LV_ALIGN_LEFT_MID, 115, 10);
}

