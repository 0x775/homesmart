/**tabview
 * @file date.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
#include "../../../lvgl/src/misc/lv_timer.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define MAX_LINE 1024
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *sw1;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label5;
static lv_obj_t *label6;
static lv_obj_t *label7;
static lv_obj_t *label_date0;
static lv_obj_t *label_date1;
static lv_obj_t *label_date2;
static lv_obj_t *label_date3;
static lv_obj_t *label_date4;
static lv_obj_t *label_date5;
static lv_obj_t *label_date6;
static lv_obj_t *label_date7;
static lv_obj_t *label_date8;
static lv_obj_t *label_date9;
static lv_obj_t *date_img;
static lv_obj_t *label_date;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static bool is_checked;
lv_obj_t *slider;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static lv_obj_t *slider_label;
static lv_obj_t *slider_label2;
static lv_obj_t *set_img1;
static lv_obj_t *set_img2;
static lv_obj_t *set_img3;
/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);
LV_FONT_DECLARE(font_chs_16);
LV_FONT_DECLARE(font_voice_chs_10);
LV_FONT_DECLARE(font_voice_chs_6);
LV_IMG_DECLARE(bg_loading1);
static void event_handler_switch(lv_event_t *e)
{
}
static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}

static void slider_event_handler(lv_obj_t *obj, lv_event_t event)
{
    // if (event == LV_EVENT_VALUE_CHANGED) {
    printf("Value: %d\n", lv_slider_get_value(obj));
    // }
}
static void slider_show_event_cb(lv_event_t *e)
{
    lv_obj_t *slider = lv_event_get_target(e);
    char buf[8];
    lv_snprintf(buf, sizeof(buf), "%d", (int)lv_slider_get_value(slider));
    lv_label_set_text(slider_label, buf);
    lv_obj_align_to(slider_label, slider, LV_ALIGN_OUT_BOTTOM_MID, -160, -68);
    lv_obj_set_style_text_color(slider_label, lv_color_hex(0xffb400), 0);
    lv_label_set_text(slider_label2, "%"); //设置label内容
    lv_obj_align_to(slider_label2, slider, LV_ALIGN_OUT_BOTTOM_MID, -135, -68);
    lv_obj_set_style_text_color(slider_label2, lv_color_hex(0xffb400), 0);
}
void response(void)
{

    LV_FONT_DECLARE(font_response_chs_10);
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);

    // static lv_style_t tb1_style;
    // lv_style_init(&tb1_style);
    // lv_style_set_bg_color(&tb1_style, lv_color_hex(0x80878c));
    // lv_style_set_border_width(&tb1_style, 0);
    // lv_style_set_radius(&tb1_style, 10);
    // lv_style_set_shadow_width(&tb1_style, 0);
    // // lv_style_set_bg_opa(&tb1_style, LV_OPA_50); // 设置背景的透明度

    // lv_obj_t *response_btn = lv_btn_create(page);
    // lv_obj_add_style(response_btn, &tb1_style, 0);
    // lv_obj_set_size(response_btn, 440, 60);
    // lv_obj_align(response_btn, LV_ALIGN_TOP_LEFT, -17, 305);
    // lv_obj_t *label_response = lv_label_create(response_btn);
    // lv_obj_set_style_text_font(label_response, &font_response_chs_10, 0);
    // lv_label_set_text(label_response, "帮助");
    // lv_obj_align_to(label_response, response_btn, LV_ALIGN_LEFT_MID, 0, 0);

    label = lv_label_create(page);
    lv_label_set_text(label, "我在,主人有什么吩咐请讲..");
    lv_obj_set_style_text_font(label, &font_response_chs_10, 0);
    lv_obj_align(label, LV_ALIGN_TOP_LEFT, 100, 160);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);
    LV_IMG_DECLARE(icon_help);
    LV_IMG_DECLARE(icon_voice);
    LV_IMG_DECLARE(line1);
    LV_IMG_DECLARE(line2);
    set_img2 = lv_img_create(page);
    lv_img_set_src(set_img2, &line1); //设置图片源
    lv_obj_align(set_img2, LV_ALIGN_TOP_LEFT, -17, 305);
    set_img3 = lv_img_create(page);
    lv_img_set_src(set_img3, &line2); //设置图片源
    lv_obj_align(set_img3, LV_ALIGN_TOP_LEFT, -17, 305);
    set_img1 = lv_img_create(page);
    lv_img_set_src(set_img1, &icon_voice); //设置图片源
    lv_obj_align(set_img1, LV_ALIGN_TOP_LEFT, 180, 280);
    label2 = lv_label_create(page);
    lv_label_set_text(label2, "正在聆听");
    LV_FONT_DECLARE(font_response_chs_10);
    lv_obj_set_style_text_font(label2, &font_response_chs_10, 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 180, 375);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);
}