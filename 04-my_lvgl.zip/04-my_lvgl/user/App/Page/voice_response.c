﻿#include "voice_response.h"
#include "../../../lvgl/lvgl.h"
#include "screen_protection.h"

LV_IMG_DECLARE(bg_loading1); //声明图片
LV_IMG_DECLARE(icon_voice_02);
LV_IMG_DECLARE(line1);
LV_IMG_DECLARE(line2);
LV_IMG_DECLARE(icon_return);
LV_IMG_DECLARE(icon_close);

LV_FONT_DECLARE(font_help_9);
LV_FONT_DECLARE(font_hint_12);

lv_obj_t* page;
 lv_obj_t* page2;

static void event_cb_close(lv_event_t* e)
{
    lv_obj_del(page2);
}

static void event_cb_return(lv_event_t* e)
{
    lv_obj_del(page);
    screen_protection();
}

static void event_cb_help(lv_event_t* e)
{
    page2 = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page2, 480, 480);
    lv_obj_set_style_bg_color(page2,lv_color_hex(0x000000),0);
    lv_obj_set_style_bg_opa(page2,LV_OPA_80,0);
    lv_obj_set_style_border_width(page2,0,0);
    lv_obj_center(page2);

    lv_obj_t* box = lv_obj_create(page2);
    lv_obj_set_style_bg_color(box,lv_color_hex(0x2f3338),0);
    lv_obj_set_style_border_width(box,0,0);
    lv_obj_set_style_radius(box,50,0);
    lv_obj_set_align(box,LV_ALIGN_CENTER);
    lv_obj_set_size(box,320,320);

    lv_obj_t* close_btn = lv_imgbtn_create(box);
    lv_obj_align(close_btn,LV_ALIGN_TOP_MID,120,5);
    lv_obj_set_size(close_btn,25,25);
    lv_imgbtn_set_src(close_btn, LV_IMGBTN_STATE_RELEASED, &icon_close,NULL,NULL); 
	lv_imgbtn_set_src(close_btn, LV_IMGBTN_STATE_PRESSED, &icon_close,NULL,NULL);
    lv_obj_add_event_cb(close_btn,event_cb_close,LV_EVENT_CLICKED,NULL);

    lv_obj_t* hint_label2 = lv_label_create(box);
    lv_obj_align(hint_label2,LV_ALIGN_TOP_MID,0,30);
    lv_label_set_text(hint_label2,"你可以这样说 ..");
    lv_obj_set_style_text_font(hint_label2,&font_hint_12,0);
    lv_obj_set_style_text_color(hint_label2,lv_color_white(),0);

    static lv_style_t style_hint;
    lv_style_init(&style_hint);
    lv_style_set_bg_color(&style_hint, lv_color_hex(0xffffff));
    lv_style_set_bg_opa(&style_hint, LV_OPA_20);
    lv_style_set_border_width(&style_hint, 0);
    lv_style_set_radius(&style_hint, 50);
    lv_style_set_shadow_width(&style_hint, 0);
    lv_style_set_shadow_ofs_y(&style_hint, 5);
    lv_style_set_shadow_opa(&style_hint, LV_OPA_100);
    lv_style_set_text_color(&style_hint, lv_color_white());
    lv_style_set_text_opa(&style_hint, LV_OPA_80);
    lv_style_set_pad_top(&style_hint,3);
    lv_style_set_pad_bottom(&style_hint,3);
    
    lv_obj_t* help_btn = lv_btn_create(box);
    lv_obj_align(help_btn,LV_ALIGN_CENTER,0,-30);
    lv_obj_add_style(help_btn,&style_hint,0);
    lv_obj_t* help_lab = lv_label_create(help_btn);
    lv_label_set_text(help_lab,"打开房间所有灯");
    lv_obj_set_style_text_font(help_lab,&font_hint_12,0);
    lv_obj_set_align(help_lab,LV_ALIGN_CENTER);

    lv_obj_t* help_btn2 = lv_btn_create(box);
    lv_obj_align(help_btn2,LV_ALIGN_CENTER,0,20);
    lv_obj_add_style(help_btn2,&style_hint,0);
    lv_obj_t* help_lab2 = lv_label_create(help_btn2);
    lv_label_set_text(help_lab2,"开启离家模式");
    lv_obj_set_style_text_font(help_lab2,&font_hint_12,0);
    lv_obj_set_align(help_lab2,LV_ALIGN_CENTER);

    lv_obj_t* help_btn3 = lv_btn_create(box);
    lv_obj_align(help_btn3,LV_ALIGN_CENTER,0,70);
    lv_obj_add_style(help_btn3,&style_hint,0);
    lv_obj_t* help_lab3 = lv_label_create(help_btn3);
    lv_label_set_text(help_lab3,"房间空调跳到26度");
    lv_obj_set_style_text_font(help_lab3,&font_hint_12,0);
    lv_obj_set_align(help_lab3,LV_ALIGN_CENTER);
    
}

void voice_response(void)
{
    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    page = lv_img_create(lv_scr_act());//创建一个图像对象
    lv_img_set_src(page, &bg_loading1);//设置图片源
    lv_obj_center(page);

    lv_obj_t* return_img = lv_imgbtn_create(page);
    lv_obj_align(return_img, LV_ALIGN_TOP_LEFT, 30, 30);
    lv_imgbtn_set_src(return_img, LV_IMGBTN_STATE_RELEASED, &icon_return,NULL,NULL); 
	lv_imgbtn_set_src(return_img, LV_IMGBTN_STATE_PRESSED, &icon_return,NULL,NULL);
    lv_obj_add_event_cb(return_img,event_cb_return,LV_EVENT_CLICKED,NULL);


    static lv_style_t style_help;
    lv_style_init(&style_help);
    lv_style_set_bg_color(&style_help, lv_color_hex(0xE3E6E8));
    lv_style_set_border_color(&style_help, lv_color_hex(0xffffff));
    lv_style_set_border_width(&style_help, 1);
    lv_style_set_radius(&style_help, 50);
    lv_style_set_shadow_width(&style_help, 0);
    lv_style_set_shadow_ofs_y(&style_help, 5);
    lv_style_set_shadow_opa(&style_help, LV_OPA_100);
    lv_style_set_text_color(&style_help, lv_color_white());

    lv_obj_t* help_btn = lv_btn_create(page);
    lv_obj_align(help_btn,LV_ALIGN_TOP_RIGHT,-30,30);
    lv_obj_add_style(help_btn,&style_help,0);
    lv_obj_set_style_bg_opa(help_btn,LV_OPA_0,0);
    lv_obj_set_size(help_btn,60,30);
    lv_obj_add_event_cb(help_btn,event_cb_help,LV_EVENT_CLICKED,NULL);
    lv_obj_t* help_lab = lv_label_create(help_btn);
    lv_label_set_text(help_lab,"帮助");
    lv_obj_set_style_text_font(help_lab,&font_help_9,0);
    lv_obj_set_align(help_lab,LV_ALIGN_CENTER);

    lv_obj_t* hint_lab = lv_label_create(page);
    lv_label_set_text(hint_lab,"我在 , 主人有什么吩咐请讲 ..");
    lv_obj_set_style_text_font(hint_lab,&font_hint_12,0);
    lv_obj_align(hint_lab,LV_ALIGN_CENTER,0,-80);
    lv_obj_set_style_text_color(hint_lab,lv_color_hex(0xffffff),0);

    lv_obj_t* voice_img = lv_img_create(page);
    lv_img_set_src(voice_img, &icon_voice_02);
    lv_obj_align(voice_img, LV_ALIGN_CENTER, 0, 80);

    lv_obj_t* line_img1 = lv_img_create(page);
    lv_img_set_src(line_img1, &line1);
    lv_obj_align(line_img1, LV_ALIGN_CENTER, 0, 80);
    
    lv_obj_t* line_img2 = lv_img_create(page);
    lv_img_set_src(line_img2, &line2);
    lv_obj_align(line_img2, LV_ALIGN_CENTER, 0, 80);

    lv_obj_t* hint_lab2 = lv_label_create(page);
    lv_label_set_text(hint_lab2,"正在聆听");
    lv_obj_set_style_text_font(hint_lab2,&font_hint_12,0);
    lv_obj_align(hint_lab2,LV_ALIGN_CENTER,0,160);
    lv_obj_set_style_text_color(hint_lab2,lv_color_hex(0xffffff),0);
}
