/**
 * @file devices1.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "devices1.h"
#include <stdio.h>
#include <unistd.h>
#include<unistd.h>
#include<sys/reboot.h>
#include "date.h"
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *bg;
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label5;
static bool is_checked;
lv_obj_t *slider;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static lv_style_t style_pressed_color;

/**********************
 *      MACROS
 **********************/
LV_IMG_DECLARE(icon_fresh_y); //声明图片
LV_IMG_DECLARE(bg_loading1);
LV_IMG_DECLARE(icon_return);
LV_IMG_DECLARE(icon_fresh_white);

LV_FONT_DECLARE(font_system_chs_20);

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}
static void event_handler_update(lv_event_t *e)
{

}
static void event_handler_reboot(lv_event_t *e)
{
     msgbox_create();
}
static void event_handler_reset(lv_event_t *e)
{
     msgbox2_create();
}
static void event_handler_close(lv_event_t *e)
{
    lv_obj_clean(bg);
    lv_obj_del(bg);
}
static void event_handler_open(lv_event_t *e)
{
    // system("reboot");
    reboot(0X01234567);
}
void msgbox_create(void)
{
    bg = lv_obj_create(lv_scr_act());
    lv_obj_set_size(bg, 480, 480);
    lv_obj_add_style(bg, &page_style, 0);
    lv_obj_set_style_bg_opa(bg, LV_OPA_70, 0);
    lv_obj_set_style_bg_color(bg, lv_color_black(), 0);

    lv_obj_t *mbox = lv_obj_create(bg);
    lv_obj_clear_flag(mbox, LV_OBJ_FLAG_SCROLLABLE); //禁止滚动
    lv_obj_align(mbox, LV_ALIGN_CENTER, 0, 0);
    lv_obj_add_style(mbox, &style_btn, 0);
    lv_obj_set_size(mbox, 305, 205);
    // lv_obj_set_style_text_color(mbox, lv_color_white(), 0);

    lv_obj_t *label_mbox = lv_label_create(mbox);
    // lv_label_set_text(label_mbox, "设备重启");
    lv_label_set_text(label_mbox, language_setting[system_label_system2]);
    lv_obj_t *label_mbox2 = lv_label_create(mbox);
    // lv_label_set_text(label_mbox2, "是否确定重启设备?");
    lv_label_set_text(label_mbox2,language_setting[system_label_mbox2]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_mbox, &font_chs_16, 0);
    lv_obj_set_style_text_font(label_mbox2, &font_chs_16, 0);
    lv_obj_align_to(label_mbox, mbox, LV_ALIGN_TOP_MID, 0, 10);
    lv_obj_align_to(label_mbox2, label_mbox, LV_ALIGN_TOP_MID, 0, 30);
    lv_obj_set_style_text_color(label_mbox, lv_color_white(), 0);
    lv_obj_set_style_text_color(label_mbox2, lv_color_white(), 0);
    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 100}, {300, 100}};
    static lv_point_t line_points2[] = {{0 ,0}, {0, 70}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(mbox);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);
    lv_obj_align_to(line1, mbox, LV_ALIGN_BOTTOM_MID, 0, -50);
    lv_obj_t *line2;
    line2 = lv_line_create(mbox);
    lv_line_set_points(line2, line_points2, 2); /*Set the points*/
    lv_obj_add_style(line2, &style_line, 0);
    lv_obj_align_to(line2, mbox, LV_ALIGN_BOTTOM_MID, 0, 20);

    lv_obj_t *btn = lv_btn_create(mbox);
    lv_obj_add_style(btn, &style_btn, 0);
    lv_obj_align_to(btn, mbox, LV_ALIGN_BOTTOM_MID, -95, -25);
    lv_obj_add_event_cb(btn, event_handler_close, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn = lv_label_create(btn);
    // lv_label_set_text(label_btn, "取消");
    lv_label_set_text(label_btn, language_setting[system_label_btn]);
    LV_FONT_DECLARE(font_system_chs_12);
    lv_obj_set_style_text_font(label_btn, &font_system_chs_12, 0);
    lv_obj_align_to(label_btn, btn, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_white(), 0);

    lv_obj_t *btn2 = lv_btn_create(mbox);
    lv_obj_add_style(btn2, &style_btn, 0);
    // lv_obj_align_to(btn2, mbox, LV_ALIGN_BOTTOM_MID, 50, -20);
    lv_obj_align_to(btn2, mbox, LV_ALIGN_BOTTOM_MID, 45, -25);
    lv_obj_add_event_cb(btn2, event_handler_open, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn2 = lv_label_create(btn2);
    // lv_label_set_text(label_btn2, "确定");
    lv_label_set_text(label_btn2, language_setting[system_label_btn2]);
    lv_obj_set_style_text_font(label_btn2, &font_system_chs_12, 0);
    lv_obj_align_to(label_btn2, btn2, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn2, lv_color_hex(0xffb400), 0);
}
void msgbox2_create(void)
{
    bg = lv_obj_create(lv_scr_act());
    lv_obj_set_size(bg, 480, 480);
    lv_obj_add_style(bg, &page_style, 0);
    lv_obj_set_style_bg_opa(bg, LV_OPA_70, 0);
    lv_obj_set_style_bg_color(bg, lv_color_black(), 0);

    lv_obj_t *mbox = lv_obj_create(bg);
    lv_obj_clear_flag(mbox, LV_OBJ_FLAG_SCROLLABLE); //禁止滚动
    lv_obj_align(mbox, LV_ALIGN_CENTER, 0, 0);
    lv_obj_add_style(mbox, &style_btn, 0);
    lv_obj_set_size(mbox, 305, 205);
    // lv_obj_set_style_text_color(mbox, lv_color_white(), 0);

    lv_obj_t *label_reset = lv_label_create(mbox);
    // lv_label_set_text(label_reset, "恢复出厂设置");
    lv_label_set_text(label_reset, language_setting[system_label_system3]);
    lv_obj_t *label_reset2 = lv_label_create(mbox);
    // lv_label_set_text(label_reset2, "是否确定恢复出厂设置并重启?");
    lv_label_set_text(label_reset2, language_setting[system_label_reset2]);
    LV_FONT_DECLARE(font_chs_16);
    LV_FONT_DECLARE(font_reset_chs_10);
    lv_obj_set_style_text_font(label_reset, &font_chs_16, 0);
    lv_obj_set_style_text_font(label_reset2, &font_reset_chs_10, 0);
    lv_obj_align_to(label_reset, mbox, LV_ALIGN_TOP_MID, 0, 20);
    lv_obj_align_to(label_reset2, label_reset, LV_ALIGN_TOP_MID, -15, 35);
    lv_obj_set_style_text_color(label_reset, lv_color_white(), 0);
    lv_obj_set_style_text_color(label_reset2, lv_color_white(), 0);
    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 100}, {300, 100}};
    static lv_point_t line_points2[] = {{0 ,0}, {0, 70}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(mbox);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);
    lv_obj_align_to(line1, mbox, LV_ALIGN_BOTTOM_MID, 0, -50);
    lv_obj_t *line2;
    line2 = lv_line_create(mbox);
    lv_line_set_points(line2, line_points2, 2); /*Set the points*/
    lv_obj_add_style(line2, &style_line, 0);
    lv_obj_align_to(line2, mbox, LV_ALIGN_BOTTOM_MID, 0, 20);

    lv_obj_t *btn = lv_btn_create(mbox);
    lv_obj_add_style(btn, &style_btn, 0);
    lv_obj_align_to(btn, mbox, LV_ALIGN_BOTTOM_MID, -95, -25);
    lv_obj_add_event_cb(btn, event_handler_close, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn = lv_label_create(btn);
    // lv_label_set_text(label_btn, "取消");
    lv_label_set_text(label_btn, language_setting[system_label_btn]);
    LV_FONT_DECLARE(font_system_chs_12);
    lv_obj_set_style_text_font(label_btn, &font_system_chs_12, 0);
    lv_obj_align_to(label_btn, btn, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_white(), 0);

    lv_obj_t *btn2 = lv_btn_create(mbox);
    lv_obj_add_style(btn2, &style_btn, 0);
    // lv_obj_align_to(btn2, mbox, LV_ALIGN_BOTTOM_MID, 50, -20);
    lv_obj_align_to(btn2, mbox, LV_ALIGN_BOTTOM_MID, 45, -25);
    lv_obj_add_event_cb(btn2, event_handler_open, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn2 = lv_label_create(btn2);
    // lv_label_set_text(label_btn2, "确定");
    lv_label_set_text(label_btn2, language_setting[system_label_btn2]);
    lv_obj_set_style_text_font(label_btn2, &font_system_chs_12, 0);
    lv_obj_align_to(label_btn2, btn2, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn2, lv_color_hex(0xffb400), 0);
}
void systemset(void)
{
//背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    lv_obj_t *logo_img = lv_img_create(page);
    LV_IMG_DECLARE(logo_white);
    lv_img_set_src(logo_img, &logo_white); //设置图片源
    lv_obj_align(logo_img, LV_ALIGN_TOP_LEFT, 140, 60);

    return_btn = lv_btn_create(page);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);
    label = lv_label_create(page);
    // lv_label_set_text(label, "设备与系统");
    lv_label_set_text(label, language_setting[system_label]);
    // lv_obj_set_size(label, 200, 50);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    static lv_style_t tb1_style;
    lv_style_init(&tb1_style);
    lv_style_set_bg_color(&tb1_style, lv_color_hex(0x80878c));
    lv_style_set_border_width(&tb1_style, 0);
    lv_style_set_radius(&tb1_style, 10);
    lv_style_set_shadow_width(&tb1_style, 0);
    lv_style_set_bg_opa(&tb1_style, LV_OPA_50); // 设置背景的透明度


    lv_obj_t *system_btn = lv_btn_create(page);
    lv_obj_add_style(system_btn, &tb1_style, 0);
    lv_obj_set_size(system_btn, 440, 60);
    lv_obj_align_to(system_btn,logo_img,LV_ALIGN_OUT_BOTTOM_LEFT, -137, 20);
    // lv_obj_add_event_cb(system_btn, event_handler_system, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img = lv_img_create(system_btn);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img, &icon_next_white); //设置图片源
    lv_obj_align(next_img, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_t *label_system = lv_label_create(system_btn);
    lv_obj_set_style_text_font(label_system, &font_chs_16, 0);
    // lv_label_set_text(label_system, "SN");
    lv_label_set_text(label_system, language_setting[system_label_system]);
    lv_obj_align_to(label_system, system_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *system_btn1 = lv_btn_create(page);
    lv_obj_add_style(system_btn1, &tb1_style, 0);
    lv_obj_set_size(system_btn1, 440, 60);
    lv_obj_align_to(system_btn1,system_btn,LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(system_btn, event_handler_update, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img1 = lv_img_create(system_btn1);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img1, &icon_next_white); //设置图片源
    lv_obj_align(next_img1, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_t *label_system1 = lv_label_create(system_btn1);
    lv_obj_set_style_text_font(label_system1, &font_chs_16, 0);
    // lv_label_set_text(label_system1, "系统升级");
    lv_label_set_text(label_system1, language_setting[system_label_system1]);
    lv_obj_align_to(label_system1, system_btn1, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *system_btn2 = lv_btn_create(page);
    lv_obj_add_style(system_btn2, &tb1_style, 0);
    lv_obj_set_size(system_btn2, 440, 60);
    lv_obj_align_to(system_btn2,system_btn1,LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(system_btn2, event_handler_reboot, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img2 = lv_img_create(system_btn2);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img2, &icon_next_white); //设置图片源
    lv_obj_align(next_img2, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_t *label_system2 = lv_label_create(system_btn2);
    lv_obj_set_style_text_font(label_system2, &font_chs_16, 0);
    // lv_label_set_text(label_system2, "设备重启");
    lv_label_set_text(label_system2, language_setting[system_label_system2]);
    lv_obj_align_to(label_system2, system_btn2, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *system_btn3 = lv_btn_create(page);
    lv_obj_add_style(system_btn3, &tb1_style, 0);
    lv_obj_set_size(system_btn3, 440, 60);
    lv_obj_align_to(system_btn3,system_btn2,LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(system_btn3, event_handler_reset, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img3 = lv_img_create(system_btn3);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img3, &icon_next_white); //设置图片源
    lv_obj_align(next_img3, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_t *label_system3 = lv_label_create(system_btn3);
    lv_obj_set_style_text_font(label_system3, &font_chs_16, 0);
    // lv_label_set_text(label_system3, "恢复出厂设置");
    lv_label_set_text(label_system3, language_setting[system_label_system3]);
    lv_obj_align_to(label_system3, system_btn3, LV_ALIGN_LEFT_MID, 0, 0);

     system("echo -e\"芯片名称:RV1126\\nLinux version:4.19.111\\nSDK版本号:v1.8.0\" > /userdata/system");
    //system("echo \"芯片名称:RV1126\\nLinux version:4.19.111\\nSDK版本号:v1.8.0\" > ./test.txt");
    // system("sed -i '$d' ./test.txt");
    char buf[1024];  /*缓冲区*/
    FILE *fp;            /*文件指针*/
    int len;             /*行字符个数*/
    int i=0;
    char txt[30][200];
    char *ptr;
   //if((fp = fopen("./test.txt","r")) == NULL)
    if((fp = fopen("/userdata/system","r")) == NULL)
    {
    perror("fail to read");
    exit (1) ;
    }
    while(fgets(buf,1024,fp) != NULL)
    {
    len = strlen(buf);
    buf[len-1] = '\0';  /*去掉换行符*/
    printf("%s %d \n",buf,len - 1);
    ptr=strrchr(buf,':');
    strcpy(txt[i],ptr+1);
    printf("%s\n",txt[i]);
    i++;
    }
 
    fclose(fp);
    lv_obj_t *label_system1_1 = lv_label_create(system_btn);
    lv_obj_set_style_text_font(label_system1_1, &font_chs_16, 0);
    lv_label_set_text(label_system1_1, txt[0]);
    lv_obj_align_to(label_system1_1, system_btn, LV_ALIGN_RIGHT_MID, -50, 0);
}
