/**
 * @file devices1.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "devices1.h"
#include <stdio.h>
#include <unistd.h>
#include "date.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *bg;
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label5;
static bool is_checked;
lv_obj_t *slider;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static lv_style_t style_pressed_color;
static lv_obj_t *label_network1;
int len;
/**********************
 *      MACROS
 **********************/
LV_IMG_DECLARE(icon_fresh_y); //声明图片
LV_IMG_DECLARE(bg_loading1);
LV_IMG_DECLARE(icon_return);
LV_IMG_DECLARE(icon_fresh_white);

LV_FONT_DECLARE(font_system_chs_20);

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

static void event_handler_return(lv_event_t *e)
{
    mainwindow();
}

static void event_handler_wifi(lv_event_t *e)
{
    wifi();
}
static void event_handler_code(lv_event_t *e)
{
    code();
}
// static void event_handler_sleep(lv_event_t *e)
// {
//    screen_sleep();
// }
void network(void)
{
//背景
    for (size_t i = 0; i <=len; )
    {
        strcpy(language_setting[i],language_Chinese[i]); 
        printf("i111=%s\n",language_setting[i]);
        i++;
    }

    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);


    label = lv_label_create(page);
    lv_label_set_text(label, "设置");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    label2 = lv_label_create(page);
    lv_label_set_text(label2, "");
    LV_FONT_DECLARE(font_system_chs_20);
    lv_obj_set_style_text_font(label2, &font_system_chs_20, 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 140, 60);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);
    
    static lv_style_t tb1_style;
    lv_style_init(&tb1_style);
    lv_style_set_bg_color(&tb1_style, lv_color_hex(0x80878c));
    lv_style_set_border_width(&tb1_style, 0);
    lv_style_set_radius(&tb1_style, 10);
    lv_style_set_shadow_width(&tb1_style, 0);
    lv_style_set_bg_opa(&tb1_style, LV_OPA_50); // 设置背景的透明度

    lv_obj_t *network_btn = lv_btn_create(page);
    lv_obj_add_style(network_btn, &tb1_style, 0);
    lv_obj_set_size(network_btn, 440, 60);
    lv_obj_align_to(network_btn,label2,LV_ALIGN_OUT_BOTTOM_LEFT, -137, -60);
    // lv_obj_add_event_cb(network_btn, event_handler_network, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img = lv_img_create(network_btn);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img, &icon_next_white); //设置图片源
    lv_obj_align(next_img, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_t *label_network = lv_label_create(network_btn);
    lv_obj_set_style_text_font(label_network, &font_chs_16, 0);
    lv_label_set_text(label_network, "有线网络");
    lv_obj_align_to(label_network, network_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *network_btn1 = lv_btn_create(page);
    lv_obj_add_style(network_btn1, &tb1_style, 0);
    lv_obj_set_size(network_btn1, 440, 60);
    lv_obj_align_to(network_btn1,network_btn,LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(network_btn1, event_handler_wifi, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img1 = lv_img_create(network_btn1);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img1, &icon_next_white); //设置图片源
    lv_obj_align(next_img1, LV_ALIGN_RIGHT_MID, 0, 0);
    label_network1 = lv_label_create(network_btn1);
    lv_obj_set_style_text_font(label_network1, &font_chs_16, 0);
    lv_label_set_text(label_network1, "无线网络");
    lv_obj_align_to(label_network1, network_btn1, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *network_btn2 = lv_btn_create(page);
    lv_obj_add_style(network_btn2, &tb1_style, 0);
    lv_obj_set_size(network_btn2, 440, 60);
    lv_obj_align_to(network_btn2,network_btn1,LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(network_btn2, event_handler_code, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img2 = lv_img_create(network_btn2);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img2, &icon_next_white); //设置图片源
    lv_obj_align(next_img2, LV_ALIGN_RIGHT_MID, 0, 0);
    lv_obj_t *label_network2 = lv_label_create(network_btn2);
    lv_obj_set_style_text_font(label_network2, &font_chs_16, 0);
    lv_label_set_text(label_network2, "APP二维码");
    lv_obj_align_to(label_network2, network_btn2 ,LV_ALIGN_LEFT_MID, 0, 0);

    // lv_obj_t *network_btn3 = lv_btn_create(page);
    // lv_obj_add_style(network_btn3, &tb1_style, 0);
    // lv_obj_set_size(network_btn3, 440, 60);
    // lv_obj_align_to(network_btn3,network_btn2,LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    // lv_obj_add_event_cb(network_btn3, event_handler_sleep, LV_EVENT_CLICKED, NULL);
    // lv_obj_t *next_img3 = lv_img_create(network_btn3);
    // LV_IMG_DECLARE(icon_next_white);
    // lv_img_set_src(next_img3, &icon_next_white); //设置图片源
    // lv_obj_align(next_img3, LV_ALIGN_RIGHT_MID, 0, 0);
    // lv_obj_t *label_network3 = lv_label_create(network_btn3);
    // lv_obj_set_style_text_font(label_network3, &font_chs_16, 0);
    // lv_label_set_text(label_network3, "test");
    // lv_obj_align_to(label_network3, network_btn3 ,LV_ALIGN_LEFT_MID, 0, 0);
}
