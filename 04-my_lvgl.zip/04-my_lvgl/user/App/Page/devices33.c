/**
 * @file devices.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "devices.h"
#include <stdio.h>
#include <unistd.h>
#include "date.h"
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *device;
static bool is_checked;
lv_obj_t *slider;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
//int device33_switch_state;

/**********************
 *      MACROS
 **********************/
LV_IMG_DECLARE(icon_light_white); //声明图片
LV_IMG_DECLARE(bg_loading1);
LV_IMG_DECLARE(icon_return);
LV_IMG_DECLARE(icon_light_yellow);

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}

static void event_handler_switch(lv_event_t *e)
{
	chg_device_switch = 1;
    is_checked = lv_obj_has_state(sw, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
    if (is_checked)
    {
        lv_img_set_src(device, &icon_light_yellow); //设置图片源
        lv_style_set_bg_color(&style_main, lv_color_white());
        lv_style_set_bg_color(&style_indicator, lv_color_hex(0xffb400));
        lv_style_set_bg_color(&style_knob, lv_color_white());
        lv_style_set_border_color(&style_knob, lv_color_white());
        printf("echo 0 > /sys/class/gpio/gpio65/value\n");
        system("echo 0 > /sys/class/gpio/gpio65/value");
        device33_switch_state = 1;
    }
    else
    {
        lv_img_set_src(device, &icon_light_white); //设置图片源
        lv_style_set_bg_color(&style_main, lv_color_hex(0x80878c));
        lv_style_set_bg_color(&style_indicator, lv_color_hex(0x80878c));
        lv_style_set_bg_color(&style_knob, lv_color_hex(0x80878c));
        lv_style_set_border_color(&style_knob, lv_color_hex(0x454c52));
        printf("echo 1 > /sys/class/gpio/gpio65/value\n");
        system("echo 1 > /sys/class/gpio/gpio65/value");
        device33_switch_state = 0;
    }

    lv_obj_remove_style_all(slider); /*Remove the styles coming from the theme*/
    lv_obj_add_style(slider, &style_main, LV_PART_MAIN);
    lv_obj_add_style(slider, &style_indicator, LV_PART_INDICATOR);
    lv_obj_add_style(slider, &style_knob, LV_PART_KNOB);
    lv_obj_align_to(slider, device, LV_ALIGN_OUT_BOTTOM_MID, 0, 50);
}

void devices33(void)
{
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_center(page);
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_obj_t *background = lv_img_create(page);
    lv_img_set_src(background, &bg_loading1); //设置图片源
    lv_obj_center(background);

    panel = lv_obj_create(page);
    lv_obj_set_size(panel, 480, 100);
    lv_obj_add_style(panel, &page_style, 0);
    lv_obj_align_to(panel, background, LV_ALIGN_TOP_LEFT, -16, -16);

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(panel);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);

    label = lv_label_create(panel);
    // lv_label_set_text(label, "吸顶灯3");
     lv_label_set_text(label, language_setting[mainwindow_label_lamp33]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    sw = lv_switch_create(panel);
    lv_obj_align(sw, LV_ALIGN_RIGHT_MID, 0, 0);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw, event_handler_switch, LV_EVENT_VALUE_CHANGED, NULL);

    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 0}, {480, 0}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    lv_style_set_line_width(&style_line, 3);
    // lv_style_set_line_dash_width(&style_line, 10);
    // lv_style_set_line_dash_gap(&style_line, 3);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(background);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);
    lv_obj_align_to(line1, panel, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 0);

    device = lv_img_create(page);
    lv_img_set_src(device, &icon_light_white); //设置图片源
    lv_obj_align_to(device, panel, LV_ALIGN_OUT_BOTTOM_MID, 0, 50);

    /*Create a transition*/
    static const lv_style_prop_t props[] = {LV_STYLE_BG_COLOR, 0};
    static lv_style_transition_dsc_t transition_dsc;
    lv_style_transition_dsc_init(&transition_dsc, props, lv_anim_path_linear, 300, 0, NULL);

    lv_style_init(&style_main);
    lv_style_set_bg_opa(&style_main, LV_OPA_COVER);
    lv_style_set_radius(&style_main, LV_RADIUS_CIRCLE);
    lv_style_set_pad_ver(&style_main, -2); /*Makes the indicator larger*/

    lv_style_init(&style_indicator);
    lv_style_set_bg_opa(&style_indicator, LV_OPA_COVER);
    lv_style_set_radius(&style_indicator, LV_RADIUS_CIRCLE);
    lv_style_set_transition(&style_indicator, &transition_dsc);

    lv_style_init(&style_knob);
    lv_style_set_bg_opa(&style_knob, LV_OPA_COVER);
    lv_style_set_border_width(&style_knob, 1);
    lv_style_set_radius(&style_knob, LV_RADIUS_CIRCLE);
    lv_style_set_pad_all(&style_knob, 6); /*Makes the knob larger*/
    lv_style_set_transition(&style_knob, &transition_dsc);

    // lv_style_init(&style_pressed_color);
    // lv_style_set_bg_color(&style_pressed_color, lv_palette_darken(LV_PALETTE_CYAN, 2));

    // lv_obj_add_style(slider, &style_pressed_color, LV_PART_INDICATOR | LV_STATE_PRESSED);
    // lv_obj_add_style(slider, &style_pressed_color, LV_PART_KNOB | LV_STATE_PRESSED);

    /*Create a slider and add the style*/
    slider = lv_slider_create(page);
    // int slider_value = (int)lv_slider_get_value(slider);

    if (device33_switch_state)
    {
        lv_img_set_src(device, &icon_light_yellow); //设置图片源
        lv_style_set_bg_color(&style_main, lv_color_white());
        lv_style_set_bg_color(&style_indicator, lv_color_hex(0xffb400));
        lv_style_set_bg_color(&style_knob, lv_color_white());
        lv_style_set_border_color(&style_knob, lv_color_white());
        lv_obj_add_state(sw, LV_STATE_CHECKED);
    }
    else
    {
        lv_img_set_src(device, &icon_light_white); //设置图片源
        lv_style_set_bg_color(&style_main, lv_color_hex(0x80878c));
        lv_style_set_bg_color(&style_indicator, lv_color_hex(0x80878c));
        lv_style_set_bg_color(&style_knob, lv_color_hex(0x80878c));
        lv_style_set_border_color(&style_knob, lv_color_hex(0x454c52));
        lv_obj_clear_state(sw, LV_STATE_CHECKED);
    }

    lv_obj_remove_style_all(slider); /*Remove the styles coming from the theme*/
    lv_obj_add_style(slider, &style_main, LV_PART_MAIN);
    lv_obj_add_style(slider, &style_indicator, LV_PART_INDICATOR);
    lv_obj_add_style(slider, &style_knob, LV_PART_KNOB);
    lv_obj_align_to(slider, device, LV_ALIGN_OUT_BOTTOM_MID, 0, 50);
}
