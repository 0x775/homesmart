/**
 * @file devices1.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "devices1.h"
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>
#include <fcntl.h>

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *bg;
lv_obj_t *page_sleep;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *time_label;
static lv_obj_t *time_label1;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *date_label;
static lv_obj_t *week_label;
static lv_obj_t *temp_label;
static uint32_t user_data = 0;
extern lv_timer_t *sleep_task;
extern lv_timer_t *change_task;
extern lv_obj_t *page_display;
static lv_timer_t * task_time;
lv_timer_t *Unlock_task;
int f0 = 1;
extern int flag;
extern int flag_sleep;
extern int flag_sleep1;
int value;

char stk3332_data[2] = {0,0};
int stk3332_unlock = 0;
int stk3332_unlock_count = 0;
int sleep_timeout = 180000; //ms

void task_sleep(lv_timer_t *task);
/**********************
 *      MACROS
 **********************/
LV_IMG_DECLARE(icon_fresh_y); //声明图片
LV_IMG_DECLARE(bg_loading1);
LV_IMG_DECLARE(icon_return);
LV_IMG_DECLARE(icon_fresh_white);

LV_FONT_DECLARE(font_system_chs_20);
void task_cb0(lv_timer_t *task);
/**********************
 *   GLOBAL FUNCTIONS
 **********************/

static void read_stk3332() {
    char stk3332_buf[2];
    int n;
    int stk3332_fd = open("/dev/stk3332", O_RDWR);
    //int stk3332_fd = fopen("/dev/stk3332", "r");
    if(stk3332_fd < 0)
    {
        printf("open file %s failed!\n", "/dev/stk3332");
        return -1;
    }
	
	//read
    read(stk3332_fd, stk3332_buf, 2);
    //printf("stk3332_unlock--->%d,stk3332_data--->%d,%d,%d,%d\n",stk3332_unlock,stk3332_data[0],stk3332_buf[0],stk3332_data[1],stk3332_buf[1]);
    if(stk3332_data[0] != 0 && stk3332_data[1] != 0) {
        if((stk3332_data[0] - stk3332_buf[0] >= 5) || (stk3332_buf[0] - stk3332_data[0] >= 5)) {
            stk3332_unlock = 1;
            stk3332_buf[0] = 0;
            stk3332_buf[1] = 0;
        }
        if((stk3332_data[1] - stk3332_buf[1] >= 5) || (stk3332_buf[1] - stk3332_data[1] >= 5)) {
            stk3332_unlock = 1;
            stk3332_buf[0] = 0;
            stk3332_buf[1] = 0;
        }
    }
    stk3332_data[0] = stk3332_buf[0];
    stk3332_data[1] = stk3332_buf[1];
    
    //while(fgets(stk3332_buf, 2, fp) != NULL){
    //    for(n=0;n<2;n++) {
    //        printf("stk3332_buf[%d]--->0x%02x ", n, stk3332_buf[n]);
    //    }
    //    printf("\n");
    //}
    close(stk3332_fd);
    //fclose(stk3332_fd);
}

static void event_handler_close(lv_event_t *e)
{
    lv_obj_clean(bg);
    lv_obj_del(bg);
}
static void event_handler_network(lv_event_t *e)
{
    network();
}


void task_stk3332_unlock(lv_timer_t *task) {
    //printf("stk3332_unlock-->%d,stk3332_unlock_count-->%d\n",stk3332_unlock,stk3332_unlock_count);
    if(stk3332_unlock == 1) {
        if(stk3332_unlock_count >= sleep_timeout/1000) {
            stk3332_unlock = 0;
            stk3332_unlock_count = 0;
        } else {
            stk3332_unlock_count++;
        }
    } else {
        if(stk3332_unlock_count >= sleep_timeout/1000) {
            stk3332_unlock_count = 0;
        }
    }
}

void task_change(lv_timer_t *task){
	flag_sleep1=1;
/**
if(flag==1){
	flag_sleep1=0;	
}else {
	flag_sleep1=1;
}
printf("task_change=%d\n",flag_sleep1);
printf("task_change=%d\n",flag_sleep1);
printf("task_change=%d\n",flag_sleep1);
printf("task_change=%d\n",flag_sleep1);**/
}
void task_Unlock(lv_timer_t *task)
{
	/**int a=0;
	if (a==0){
	a=1;
	printf("aaaaaaaaaaaaaaaaaaa\n");
	change_task = lv_timer_create(task_change, 1000, NULL);
	}**/
  //flag=0;
 flag=1;
//printf("flag_sleep0000=%d\n",flag_sleep1);
    read_stk3332();
if(stk3332_unlock == 1 || (lv_disp_get_inactive_time(NULL) < 1000 && flag==1)) {
	char buf1[400];
//    printf("mainwindow\n");
    // lv_obj_del(page_sleep);
    //lv_timer_del(task_time);
    // mainwindow();
    lv_timer_del(Unlock_task);

    sleep_task = lv_timer_create(task_sleep, 100, NULL);
    
//    printf("del_Unlock_task\n");
    //lv_obj_clean(page_sleep);
    //lv_obj_del(page_sleep);
    sprintf(buf1, "echo %d > /sys/devices/platform/backlight/backlight/backlight/brightness",value);
//    printf("value=%d\n",value);	
// printf("flag_unlock=%d\n",flag);
// printf("flag_unlock=%d\n",flag);
// printf("flag_unlock=%d\n",flag);
// printf("flag_unlock=%d\n",flag);
    system(buf1);
	flag=0;
    //stk3332_unlock = 0;
  change_task = lv_timer_create(task_change, 1000, NULL);
   // change_flag();
  }else {
//    printf("test2222\n");
//    printf("flag=%d\n",flag);
  }

}

void task_cb0(lv_timer_t *task)
{
    // Unlock_task = lv_timer_create(task_Unlock, 100, NULL);
    time_t nowtime;
    struct tm *p;
    time(&nowtime);
    p = localtime(&nowtime);
    if (f0)
    {
        lv_label_set_text_fmt(time_label, "%02d", p->tm_hour);
        lv_label_set_text_fmt(label, ":");
        lv_label_set_text_fmt(time_label1, "%02d", p->tm_min);
        f0 = 0;
    }
    else
    {
        lv_label_set_text_fmt(time_label, "%02d", p->tm_hour);
        lv_label_set_text_fmt(label, " ");
        lv_label_set_text_fmt(time_label1, "%02d", p->tm_min);
        f0 = 1;
    }
    lv_label_set_text_fmt(date_label, "%4d/%02d/%02d", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);
    switch (p->tm_wday)
    {
    case 0:
        lv_label_set_text_fmt(week_label, "星期日");
        break;
    case 1:
        lv_label_set_text_fmt(week_label, "星期一");
        break;
    case 2:
        lv_label_set_text_fmt(week_label, "星期二");
        break;
    case 3:
        lv_label_set_text_fmt(week_label, "星期三");
        break;
    case 4:
        lv_label_set_text_fmt(week_label, "星期四");
        break;
    case 5:
        lv_label_set_text_fmt(week_label, "星期五");
        break;
    case 6:
        lv_label_set_text_fmt(week_label, "星期六");
        break;
    }	
}
void screen_sleep(void)
{   

    lv_style_init(&page_style);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_radius(&page_style, 10);
    lv_style_set_shadow_width(&page_style, 0);
    // lv_style_set_bg_opa(&page_style, LV_OPA_50); // 设置背景的透明度


    page_sleep = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page_sleep, 480, 480);
    lv_obj_add_style(page_sleep, &page_style, 0);
    lv_obj_set_scroll_dir(page_sleep, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page_sleep, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条


    lv_obj_t *sleep_btn = lv_btn_create(page_sleep);
    LV_IMG_DECLARE(bg_loading1); //声明图片
    lv_obj_add_style(sleep_btn, &style_btn, 0);
    lv_obj_t *sleep_img = lv_img_create(page_sleep);
    lv_img_set_src(sleep_img, &bg_loading1); //设置图片源
    lv_obj_align(sleep_img, LV_ALIGN_LEFT_MID, -15, 0);
    lv_obj_add_event_cb(sleep_btn, event_handler_network, LV_EVENT_CLICKED, NULL);

    time_t nowtime;
     //首先创建一个time_t 类型的变量nowtime
    struct tm *p;
    //然后创建一个新时间结构体指针 p
    time(&nowtime);
    //使用该函数就可得到当前系统时间，使用该函数需要将传入time_t类型变量nowtime的地址值。
    p = localtime(&nowtime);
    ////由于此时变量nowtime中的系统时间值为日历时间，我们需要调用本地时间函数p=localtime（time_t* nowtime）将nowtime变量中的日历时间转化为本地时间，存入到指针为p的时间结构体中。不改的话，可以参照注意事项手动改。
    // printf("%02d:%02d:%02d\n", p->tm_hour, p->tm_min, p->tm_sec);
    // hour
    time_label = lv_label_create(page_sleep);
    lv_obj_set_height(time_label, LV_SIZE_CONTENT);
    lv_obj_set_align(time_label, LV_ALIGN_TOP_LEFT);
    lv_label_set_text_fmt(time_label, "%02d", p->tm_hour);
    LV_FONT_DECLARE(font_time_65);
    lv_obj_set_style_text_font(time_label, &font_time_65, 0);
    lv_obj_set_style_text_color(time_label, lv_color_hex(0xffffff), 0);
    lv_obj_align(time_label, LV_ALIGN_TOP_LEFT, 80, 70);
    // min
    time_label1 = lv_label_create(page_sleep);
    lv_obj_set_height(time_label1, LV_SIZE_CONTENT);
    lv_obj_set_align(time_label1, LV_ALIGN_TOP_LEFT);
    lv_obj_align(time_label1, LV_ALIGN_TOP_LEFT, 240, 70);
    lv_label_set_text_fmt(time_label1, "%02d", p->tm_min);
    LV_FONT_DECLARE(font_time_65);
    lv_obj_set_style_text_font(time_label1, &font_time_65, 0);
    lv_obj_set_style_text_color(time_label1, lv_color_hex(0xffffff), 0);
    // // date
    date_label = lv_label_create(page_sleep);
    lv_obj_align(date_label, LV_ALIGN_TOP_LEFT, 0, 130);
    LV_FONT_DECLARE(font_date_16);
    lv_label_set_text_fmt(date_label, "%4d/%02d/%02d", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);
    lv_obj_set_style_text_font(date_label, &font_date_16, 0);
    lv_obj_set_style_text_color(date_label, lv_color_hex(0xffffff), 0);

    label = lv_label_create(page_sleep);
    lv_obj_set_height(label, LV_SIZE_CONTENT);
    lv_obj_align(label, LV_ALIGN_TOP_LEFT, 210, 63);
    lv_label_set_text_fmt(label, ":");
    task_time = lv_timer_create(task_cb0, 500, &user_data);
    LV_FONT_DECLARE(font_time_65);
    lv_obj_set_style_text_font(label, &font_time_65, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(0xffffff), 0);
    // //
    week_label = lv_label_create(page_sleep);
    lv_obj_align(date_label, LV_ALIGN_TOP_LEFT, 90, 190);
    lv_obj_align(week_label, LV_ALIGN_TOP_LEFT, 260, 190);
    // LV_FONT_DECLARE(font_date_16);
    switch (p->tm_wday)
    {
    case 0:
        lv_label_set_text_fmt(week_label, "星期日");
        break;
    case 1:
        lv_label_set_text_fmt(week_label, "星期一");
        break;
    case 2:
        lv_label_set_text_fmt(week_label, "星期二");
        break;
    case 3:
        lv_label_set_text_fmt(week_label, "星期三");
        break;
    case 4:
        lv_label_set_text_fmt(week_label, "星期四");
        break;
    case 5:
        lv_label_set_text_fmt(week_label, "星期五");
        break;
    case 6:
        lv_label_set_text_fmt(week_label, "星期六");
        break;
    }
    LV_FONT_DECLARE(font_date_16);
    lv_obj_set_style_text_font(week_label, &font_date_16, 0);
    lv_obj_set_style_text_color(week_label, lv_color_hex(0xffffff), 0);

    label2 = lv_label_create(page_sleep);
    lv_label_set_text(label2, "触屏解锁");
    LV_FONT_DECLARE(font_sleep_chs_8);
    lv_obj_set_style_text_font(label2, &font_sleep_chs_8, 0);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 190, 10);

}

