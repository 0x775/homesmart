/**
 * @file wifi.h
 *
 */

#ifndef LV_WIFI_H
#define LV_WIFI_H

#ifdef __cplusplus
extern "C"
{
#endif

    /*********************
     *      INCLUDES
     *********************/

    /*********************
     *      DEFINES
     *********************/

    /**********************
     *      TYPEDEFS
     **********************/
    /**********************
     * GLOBAL PROTOTYPES
     **********************/
    void wifi(void);
    void disp_connect(char name[]);
    void wifi_readconfig(char wifiname[],char password[]);
    //void task_cb_sw2();
    /**********************
     *      MACROS
     **********************/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*LV_WIFI_H*/
