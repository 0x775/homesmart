/**
 * @file mainwindow.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "mainwindow.h"
#include "add_scene.h"
#include "wifi.h"
#include "voice.h"
#include "date.h"
#include "wifi.h"
#include "../../../lvgl/lvgl.h"
#include <time.h>
#include "lvgl/src/misc/lv_timer.h"
#include <string.h>
#include <stdio.h>
#include "wifi_connect.h"
#include "cJSON.h"
#include <sys/stat.h>
#include <fcntl.h>
// #include "./lv_drv_conf.h.h"
lv_timer_t *task_sw3;
void task_cb_sw3(lv_timer_t * task);
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/
typedef enum
{
    DISP_SMALL,
    DISP_MEDIUM,
    DISP_LARGE,
} disp_size_t;

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static disp_size_t disp_size;
static lv_style_t style_btn;

static lv_obj_t *tv;
static lv_obj_t *tb;
static lv_obj_t *new_scr;

static lv_style_t style_text_muted;
static lv_style_t style_title;
static lv_style_t style_icon;
static lv_style_t style_bullet;

static const lv_font_t *font_large;
static const lv_font_t *font_normal;

static lv_obj_t *tab1_btn;
static lv_obj_t *set_img;
static lv_obj_t *equipment_img;
static lv_obj_t *scenes_img;
static lv_obj_t *style_img;

static lv_obj_t *sw11;
static lv_obj_t *sw12;
static lv_obj_t *sw13;

static lv_obj_t *t1;
static lv_obj_t *t2;
int device31_switch_state;
int device32_switch_state;
int device33_switch_state;
int chg_device_switch;
static int flag_sleep=0;
//int flag=1;
int flag_sleep1=1;
extern lv_obj_t *label_wifi_mainwindow;
extern lv_obj_t *label_sound_mainwindow;
extern lv_obj_t *label_date_mainwindow;
extern lv_obj_t *label_system_mainwindow;
extern lv_obj_t *label_response_mainwindow;
extern lv_obj_t *label_display_mainwindow;
extern lv_obj_t *label_set;
extern lv_obj_t *label_equipment;
extern lv_obj_t *label_scenes;
extern lv_obj_t *label_style;
static lv_obj_t *label_type;
extern lv_obj_t *type_btn;
static lv_obj_t *scenes_btn;
static lv_obj_t *label_scenes11;
static lv_obj_t *devices_btn;
static lv_obj_t *label_devices;
extern lv_obj_t *label_theme1;
extern lv_obj_t *label_theme2;
extern lv_obj_t *label_lamp1;
extern lv_obj_t *label_lamp22;
extern lv_obj_t *label_lamp33;
extern lv_obj_t *label_door;
extern lv_obj_t *label_AC;
extern lv_obj_t *label_infrared;
extern lv_obj_t *label_float;
extern lv_obj_t *label_curtain;
extern lv_obj_t *label_wind;
static lv_obj_t *slider_gray_img1;
static lv_obj_t *slider_yellow_img;
static lv_obj_t *slider_gray_img2;
static lv_obj_t *label_slider;
LV_FONT_DECLARE(font_mainwindowtb_chs_10);



LV_IMG_DECLARE(icon_set_y);
LV_IMG_DECLARE(icon_style_y);
LV_IMG_DECLARE(icon_scenes_y);
LV_IMG_DECLARE(icon_equipment_y);
LV_IMG_DECLARE(icon_set_white);
LV_IMG_DECLARE(icon_style_white);
LV_IMG_DECLARE(icon_scenes_white);
LV_IMG_DECLARE(icon_equipment_white);
LV_IMG_DECLARE(icon_lignt_s_black);

extern lv_obj_t *tab_btns;
char temp[100]="-";
char weather[100]="- ";
extern char sw_flag[5];
//extern int is_checked_wifi;
lv_obj_t *sw2;
lv_obj_t *sw3;
lv_obj_t *sw4;
lv_obj_t *sw5;
lv_obj_t *sw6;
lv_obj_t *sw7;

int is_checked_sw2;
int is_checked_sw3;
int is_checked_sw4;
int is_checked_sw5;
int is_checked_sw6;
int is_checked_sw7;

extern bool is_checked_sleep = 1;
extern lv_timer_t *sleep_task;
extern lv_timer_t *change_task;
void task_sleep(lv_timer_t *task);
void task_change(lv_timer_t *task);
void task_stk3332_unlock(lv_timer_t *task);

//char stk3332_data[2] = {0,0};

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

/*static void read_stk3332() {
    char stk3332_buf[2];
    int n;
    int stk3332_fd = open("/dev/stk3332", O_RDWR);
    //int stk3332_fd = fopen("/dev/stk3332", "r");
    if(stk3332_fd < 0)
    {
        printf("open file %s failed!\n", "/dev/stk3332");
        return -1;
    }
	
	//read
    read(stk3332_fd, stk3332_buf, 2);
    if(stk3332_data[0] != 0 && stk3332_data[1] != 0) {
        if((stk3332_data[0] - stk3332_buf[0] >= 5) || (stk3332_buf[0] - stk3332_data[0] >= 5)) {
            flag = 0;
        }
        if((stk3332_data[1] - stk3332_buf[1] >= 5) || (stk3332_buf[1] - stk3332_data[1] >= 5)) {
            flag = 0;
        }
    }
    stk3332_data[0] = stk3332_buf[0];
    stk3332_data[1] = stk3332_buf[1];
    
    //while(fgets(stk3332_buf, 2, fp) != NULL){
    //    for(n=0;n<2;n++) {
    //        printf("stk3332_buf[%d]--->0x%02x ", n, stk3332_buf[n]);
    //    }
    //    printf("\n");
    //}
    close(stk3332_fd);
    //fclose(stk3332_fd);
}*/

static void event_handler_add_scenes(lv_event_t *e)
{
    if(flag_sleep1==1){
    add_scene();
    }    
 
}

static void event_handler_add_devices(lv_event_t *e)
{
    if(flag_sleep1==1){
    add_device();
    }    

}

static void event_handler_wifi(lv_event_t *e)
{
if(flag_sleep1==1){
wifi();
}    

}
static void event_handler_voice(lv_event_t *e)
{
  if(flag_sleep1==1){
voice();
}     
}
static void event_handler_date(lv_event_t *e)
{
   if(flag_sleep1==1){
 date();
printf("flag_sleepdate=%d\n",flag_sleep1);
}   
}
static void event_handler_display(lv_event_t *e)
{
   if(flag_sleep1==1){
 display();
}   
}
static void event_handler_system(lv_event_t *e)
{
    if(flag_sleep1==1){
systemset();
}   
}
static void event_handler_response(lv_event_t *e)
{
  if(flag_sleep1==1){
 response();
}    
}
static void event_handler_devices(lv_event_t *e)
{
  if(flag_sleep1==1){
 devices();
}    
}
static void event_handler_devices1(lv_event_t *e)
{
      if(flag_sleep1==1){
 devices1();
}    
}
// static void event_handler_devices2(lv_event_t *e)
// {
//     devices2();
// }
static void event_handler_devices31(lv_event_t *e)
{
    if(flag_sleep1==1){
    devices31();
    }    
}
static void event_handler_devices32(lv_event_t *e)
{
    if(flag_sleep1==1){
    devices32();
    }   
}
static void event_handler_devices33(lv_event_t *e)
{
    if(flag_sleep1==1){
    devices33();
    }   
}
static void event_handler_sw2(lv_event_t *e)
{
  is_checked_sw2 = lv_obj_has_state(sw2, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
}
static void event_handler_devices31_switch(lv_event_t *e)
{
    printf("----------event_handler_devices31_switch-----------------\n");
    bool is_checked = lv_obj_has_state(sw11, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
    if (is_checked)
    {
        printf("-------------------");
        printf("echo 0 > /sys/class/gpio/gpio66/value");
        printf("-------------------\n");
        system("echo 0 > /sys/class/gpio/gpio66/value");
        device31_switch_state = 1;
    }else{
        printf("-------------------");
        printf("echo 1 > /sys/class/gpio/gpio66/value");
        printf("-------------------\n");
        system("echo 1 > /sys/class/gpio/gpio66/value");
        device31_switch_state = 0;
    }  
}
static void event_handler_devices32_switch(lv_event_t *e)
{
    printf("----------event_handler_devices32_switch-----------------\n");
    bool is_checked = lv_obj_has_state(sw12, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
    if (is_checked)
    {
        printf("-------------------");
        printf("echo 0 > /sys/class/gpio/gpio67/value");
        printf("-------------------\n");
        system("echo 0 > /sys/class/gpio/gpio67/value");
        device32_switch_state = 1;
    }else{
        printf("-------------------");
        printf("echo 1 > /sys/class/gpio/gpio67/value");
        printf("-------------------\n");
        system("echo 1 > /sys/class/gpio/gpio67/value");
        device32_switch_state = 0;
    }
}
static void event_handler_devices33_switch(lv_event_t *e)
{
    printf("----------event_handler_devices33_switch-----------------\n");
    bool is_checked = lv_obj_has_state(sw13, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
    if (is_checked)
    {
        printf("-------------------");
        printf("echo 0 > /sys/class/gpio/gpio65/value");
        printf("-------------------\n");
        system("echo 0 > /sys/class/gpio/gpio65/value");
        device33_switch_state = 1;
    }else{
        printf("-------------------");
        printf("echo 1 > /sys/class/gpio/gpio65/value");
        printf("-------------------\n");
        system("echo 1 > /sys/class/gpio/gpio65/value");
        device33_switch_state = 0;
    }  
}
static void event_handler_devices4(lv_event_t *e)
{
       if(flag_sleep1==1){
      devices4();
    }    
}
static void event_handler_devices5(lv_event_t *e)
{
        if(flag_sleep1==1){
     devices5();
    }  
}
static void event_handler_devices6(lv_event_t *e)
{
       if(flag_sleep1==1){
     devices6();
    }   
}
static void event_handler_devices7(lv_event_t *e)
{
       if(flag_sleep1==1){
    devices7();
    }    
}
static void event_handler_close(lv_event_t *e)
{
    lv_obj_clean(new_scr);
    lv_obj_del(new_scr);
}
static void event_handler_sleep(lv_event_t *e)
{

}

static void event_handler_tb(lv_event_t *e)
{
    int i;
    i = lv_tabview_get_tab_act(tb);
    tab1_btn = lv_tabview_get_tab_btns(tab_btns);
    set_img = lv_img_create(tab_btns);
    equipment_img = lv_img_create(tab_btns);
    scenes_img = lv_img_create(tab_btns);
    style_img = lv_img_create(tab_btns);
    if (i == 0)
    {
        lv_img_set_src(set_img, &icon_set_y);
        lv_obj_align(set_img, LV_ALIGN_TOP_LEFT, 23, 12);
        lv_obj_set_style_text_color(label_set, lv_color_hex(0xffb400), 0);
        lv_img_set_src(equipment_img, &icon_equipment_white); //设置图片源
        lv_obj_align(equipment_img, LV_ALIGN_TOP_LEFT, 145, 12);
        lv_obj_set_style_text_color(label_equipment, lv_color_white(), 0);
        lv_img_set_src(scenes_img, &icon_scenes_white); //设置图片源
        lv_obj_align(scenes_img, LV_ALIGN_TOP_LEFT, 265, 12);
        lv_obj_set_style_text_color(label_scenes, lv_color_white(), 0);
        lv_img_set_src(style_img, &icon_style_white); //设置图片源
        lv_obj_align(style_img, LV_ALIGN_TOP_LEFT, 385, 12);
        lv_obj_set_style_text_color(label_style, lv_color_white(), 0);
        lv_obj_align_to(slider_gray_img1, label_slider, LV_ALIGN_BOTTOM_MID, 0, -20);
        lv_obj_align_to(slider_yellow_img, slider_gray_img1, LV_ALIGN_OUT_LEFT_MID, -10, 0);
        lv_obj_align_to(slider_gray_img2, slider_gray_img1, LV_ALIGN_OUT_RIGHT_MID, 10, 0);

    }
    else if (i == 1)
    {
        lv_img_set_src(set_img, &icon_set_white);
        lv_obj_align(set_img, LV_ALIGN_TOP_LEFT, 23, 12);
        lv_obj_set_style_text_color(label_set, lv_color_white(), 0);
        lv_img_set_src(equipment_img, &icon_equipment_y); //设置图片源
        lv_obj_align(equipment_img, LV_ALIGN_TOP_LEFT, 145, 12);
        lv_obj_set_style_text_color(label_equipment, lv_color_hex(0xffb400), 0);
        lv_img_set_src(scenes_img, &icon_scenes_white); //设置图片源
        lv_obj_align(scenes_img, LV_ALIGN_TOP_LEFT, 265, 12);
        lv_obj_set_style_text_color(label_scenes, lv_color_white(), 0);
        lv_img_set_src(style_img, &icon_style_white); //设置图片源
        lv_obj_align(style_img, LV_ALIGN_TOP_LEFT, 385, 12);
        lv_obj_align_to(slider_gray_img1, label_slider, LV_ALIGN_BOTTOM_MID, -10, -20);
        lv_obj_align_to(slider_yellow_img, slider_gray_img1, LV_ALIGN_OUT_RIGHT_MID, 10, 0);
        lv_obj_align_to(slider_gray_img2, slider_yellow_img, LV_ALIGN_OUT_RIGHT_MID, 10, 0);
    }
    else if (i == 2)
    {
        lv_img_set_src(set_img, &icon_set_white);
        lv_obj_align(set_img, LV_ALIGN_TOP_LEFT, 23, 12);
        lv_obj_set_style_text_color(label_set, lv_color_white(), 0);
        lv_img_set_src(equipment_img, &icon_equipment_white); //设置图片源
        lv_obj_align(equipment_img, LV_ALIGN_TOP_LEFT, 145, 12);
        lv_obj_set_style_text_color(label_equipment, lv_color_white(), 0);
        lv_img_set_src(scenes_img, &icon_scenes_y); //设置图片源
        lv_obj_align(scenes_img, LV_ALIGN_TOP_LEFT, 265, 12);
        lv_obj_set_style_text_color(label_scenes, lv_color_hex(0xffb400), 0);
        lv_img_set_src(style_img, &icon_style_white); //设置图片源
        lv_obj_align(style_img, LV_ALIGN_TOP_LEFT, 385, 12);
        lv_obj_set_style_text_color(label_style, lv_color_white(), 0);
        lv_obj_align_to(slider_gray_img1, label_slider, LV_ALIGN_BOTTOM_MID, -10, -20);
        lv_obj_align_to(slider_yellow_img, slider_gray_img2, LV_ALIGN_OUT_RIGHT_MID, 10, 0);
        lv_obj_align_to(slider_gray_img2, slider_gray_img1, LV_ALIGN_OUT_RIGHT_MID, 10, 0);
    }
    else if (i == 3)
    {
        lv_img_set_src(set_img, &icon_set_white);
        lv_obj_align(set_img, LV_ALIGN_TOP_LEFT, 23, 12);
        lv_obj_set_style_text_color(label_set, lv_color_white(), 0);
        lv_img_set_src(equipment_img, &icon_equipment_white); //设置图片源
        lv_obj_align(equipment_img, LV_ALIGN_TOP_LEFT, 145, 12);
        lv_obj_set_style_text_color(label_equipment, lv_color_white(), 0);
        lv_img_set_src(scenes_img, &icon_scenes_white); //设置图片源
        lv_obj_align(scenes_img, LV_ALIGN_TOP_LEFT, 265, 12);
        lv_obj_set_style_text_color(label_scenes, lv_color_white(), 0);
        lv_img_set_src(style_img, &icon_style_y); //设置图片源
        lv_obj_align(style_img, LV_ALIGN_TOP_LEFT, 385, 12);
        lv_obj_set_style_text_color(label_style, lv_color_hex(0xffb400), 0);
    }
}

static void event_handler_add(lv_event_t *e)
{
    // 创建新屏幕
    new_scr = lv_obj_create(lv_scr_act());
    lv_obj_set_size(new_scr, lv_pct(40), lv_pct(100));
    lv_obj_set_style_bg_color(new_scr, lv_color_hex(0x2F3338), 0);
    lv_obj_set_style_border_width(new_scr, 0, 0);
    lv_obj_set_style_radius(new_scr, 0, 0);
    lv_obj_set_style_pad_all(new_scr, 0, 0);
    lv_obj_add_event_cb(new_scr, event_handler_close, LV_EVENT_PRESSED, NULL);

    // 动画加载新屏幕
    // lv_scr_load_anim(new_scr, LV_SCR_LOAD_ANIM_MOVE_RIGHT, 1000, 1000, true);

    LV_FONT_DECLARE(font_chose_12);
    // label_type = lv_label_create(new_scr);
    // lv_obj_align(label_type, LV_ALIGN_TOP_LEFT, 20, 30);
    // lv_obj_set_style_text_font(label_type, &font_chose_12, 0);
    // lv_obj_set_style_text_color(label_type, lv_color_white(), 0);

    label_type = lv_label_create(new_scr);
    lv_obj_align(label_type, LV_ALIGN_TOP_LEFT, 20, 30);
    lv_obj_set_style_text_font(label_type, &font_chose_12, 0);
    lv_obj_set_style_text_color(label_type, lv_color_white(), 0);
    // lv_label_set_text(label_type, "选择添加类型");
    lv_label_set_text(label_type,language_setting[mainwindow_label_type]);


    lv_obj_t *list_btn = lv_list_create(new_scr);
    lv_obj_set_size(list_btn, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_align(list_btn, LV_ALIGN_TOP_LEFT, 0, 80);
    lv_obj_set_style_pad_all(list_btn, 0, 0);
    lv_obj_set_style_radius(list_btn, 0, 0);
    lv_obj_set_style_border_width(list_btn, 0, 0);

    LV_FONT_DECLARE(font_chs_16);

    static lv_style_t type_btn_style;
    lv_style_init(&type_btn_style);
    lv_style_set_text_color(&type_btn_style, lv_color_white());
    lv_style_set_text_font(&type_btn_style, &font_chs_16);
    lv_style_set_border_width(&type_btn_style, 0);
    lv_style_set_radius(&type_btn_style, 0);
    lv_style_set_bg_color(&type_btn_style, lv_color_hex(0x2F3338));
    lv_style_set_pad_left(&type_btn_style, 20);
    lv_style_set_text_color(&type_btn_style, lv_color_white());

    static lv_style_t type_btn_pres;
    lv_style_init(&type_btn_pres);
    lv_style_set_bg_color(&type_btn_pres, lv_color_hex(0x454C52));

    // type_btn = lv_list_add_btn(list_btn, NULL, "场景");
    // lv_obj_add_style(type_btn, &type_btn_style, LV_STATE_DEFAULT);
    // lv_obj_add_style(type_btn, &type_btn_pres, LV_STATE_PRESSED);
    // lv_obj_add_event_cb(type_btn, event_handler_add_scenes, LV_EVENT_CLICKED, NULL);
    // type_btn = lv_list_add_btn(list_btn, NULL, "设备开关");
    // lv_obj_add_style(type_btn, &type_btn_style, LV_STATE_DEFAULT);
    // lv_obj_add_style(type_btn, &type_btn_pres, LV_STATE_PRESSED);
    // lv_obj_add_event_cb(type_btn, event_handler_add_devices, LV_EVENT_CLICKED, NULL);

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);

    LV_FONT_DECLARE(font_type_chs_16);
    scenes_btn=lv_btn_create(new_scr);
    lv_obj_add_style(scenes_btn, &style_btn, 0);
    label_scenes11 = lv_label_create(scenes_btn);
    // lv_label_set_text(label_scenes, "场景");
    lv_label_set_text(label_scenes11, language_setting[mainwindow_label_scenes11]);
    lv_obj_set_style_text_font(label_scenes11, &font_type_chs_16, 0);
    lv_obj_align(scenes_btn, LV_ALIGN_TOP_LEFT,15,80);
    lv_obj_set_style_text_color(label_scenes11, lv_color_white(), 0);
    lv_obj_add_event_cb(scenes_btn, event_handler_add_scenes, LV_EVENT_CLICKED, NULL);

    devices_btn=lv_btn_create(new_scr);
    lv_obj_add_style(devices_btn, &style_btn, 0);
    label_devices = lv_label_create(devices_btn);
    // lv_label_set_text(label_devices ,"设备开关");
    lv_label_set_text(label_devices ,language_setting[mainwindow_label_devices]);
    lv_obj_set_style_text_font(label_devices, &font_type_chs_16, 0);
    lv_obj_align(devices_btn, LV_ALIGN_TOP_LEFT, 15, 120);
    lv_obj_set_style_text_color(label_devices, lv_color_white(), 0);
    lv_obj_add_event_cb(devices_btn, event_handler_add_devices, LV_EVENT_CLICKED, NULL);
}
static uint32_t user_data = 0;
int f = 1;
static lv_obj_t *time_label;
static lv_obj_t *time_label1;
static lv_obj_t *label;
static lv_obj_t *date_label11;
static lv_obj_t *week_label;
static lv_obj_t *temp_label;
int setting_time_hour;
int setting_time_min;
int i=0;
void task_cb(lv_timer_t *task)
{   
    time_t nowtime;
    struct tm *p;
    time(&nowtime);
    p = localtime(&nowtime);
    // printf("3time=%s\r\n",time2);
    if (f)
        {
            lv_label_set_text_fmt(time_label, "%02d", p->tm_hour);
            lv_label_set_text_fmt(label, ":");
            lv_label_set_text_fmt(time_label1, "%02d", p->tm_min);
            f = 0;
        }
        else
        {
            lv_label_set_text_fmt(time_label, "%02d", p->tm_hour);
            lv_label_set_text_fmt(label, " ");
            lv_label_set_text_fmt(time_label1, "%02d", p->tm_min);
            f = 1;
        }
    lv_label_set_text_fmt(date_label11, "%4d/%02d/%02d", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);
    switch (p->tm_wday)
    {
    case 0:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期日");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Sunday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Sunday");
        }
        break;
    case 1:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期一");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Monday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Monday");
        }
        break;
    case 2:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期二");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Tuesday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Tuesday");
        }
        break;
    case 3:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期三");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Wednesday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Wednesday");
        }
        break;
    case 4:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期四");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Thursday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Thursday");
        }
        break;
    case 5:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期五");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Friday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Friday");
        }
        break;
    case 6:
        if(setting_language==0){
        lv_label_set_text_fmt(week_label, "星期六");
        }else if (setting_language==1)
        {
        lv_label_set_text_fmt(week_label, "Saturday");
        }else if (setting_language==2)
        {
        lv_label_set_text_fmt(week_label, "Saturday");
        }
        break;
    }
    lv_label_set_text_fmt(temp_label, "%s %s℃",weather,temp);
    
    // sleep(1);
}


 void weather_task_cb(lv_timer_t *task)
 {
    getweather(temp,weather);//获取天气
    printf("\ntemp:%s\nweather:%s\n",temp,weather);    
    
 }

void switch_task_cb(lv_timer_t *task)
{  
    if(chg_device_switch) {
        if (device31_switch_state) {
            lv_obj_add_state(sw11, LV_STATE_CHECKED);
        } else {
            lv_obj_clear_state(sw11, LV_STATE_CHECKED);
        }
        if (device32_switch_state) {
            lv_obj_add_state(sw12, LV_STATE_CHECKED);
        } else {
            lv_obj_clear_state(sw12, LV_STATE_CHECKED);
        }
        if (device33_switch_state) {
            lv_obj_add_state(sw13, LV_STATE_CHECKED);
        } else {
            lv_obj_clear_state(sw13, LV_STATE_CHECKED);
        }
        if (is_checked_sw2)
        {
            lv_obj_add_state(sw2, LV_STATE_CHECKED);
        }
        else{
            lv_obj_clear_state(sw2, LV_STATE_CHECKED);
        }
        if (is_checked_sw3)
        {
            lv_obj_add_state(sw3, LV_STATE_CHECKED);
        }
        else{
            lv_obj_clear_state(sw3, LV_STATE_CHECKED);
        }
        if (is_checked_sw4)
        {
            lv_obj_add_state(sw4, LV_STATE_CHECKED);
        }
        else{
            lv_obj_clear_state(sw4, LV_STATE_CHECKED);
        }
        if (is_checked_sw5)
        {
            lv_obj_add_state(sw5, LV_STATE_CHECKED);
        }
        else{
            lv_obj_clear_state(sw5, LV_STATE_CHECKED);
        }
        if (is_checked_sw6)
        {
            lv_obj_add_state(sw6, LV_STATE_CHECKED);
        }
        else{
            lv_obj_clear_state(sw6, LV_STATE_CHECKED);
        }
        if (is_checked_sw7)
        {
            lv_obj_add_state(sw7, LV_STATE_CHECKED);
        }
        else{
            lv_obj_clear_state(sw7, LV_STATE_CHECKED);
        }
        chg_device_switch = 0;
    } else {
        bool is_checked = lv_obj_has_state(sw11, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!device31_switch_state) {
            printf("-------------------");
            printf("echo 0 > /sys/class/gpio/gpio66/value");
            printf("-------------------\n");
            system("echo 0 > /sys/class/gpio/gpio66/value");
            device31_switch_state = 1;
            }
        }else{
            if(device31_switch_state) {
            printf("-------------------");
            printf("echo 1 > /sys/class/gpio/gpio66/value");
            printf("-------------------\n");
            system("echo 1 > /sys/class/gpio/gpio66/value");
            device31_switch_state = 0;
            }
        }  
        is_checked = lv_obj_has_state(sw12, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!device32_switch_state) {
            printf("-------------------");
            printf("echo 0 > /sys/class/gpio/gpio67/value");
            printf("-------------------\n");
            system("echo 0 > /sys/class/gpio/gpio67/value");
            device32_switch_state = 1;
            }
        }else{
            if(device32_switch_state) {
            printf("-------------------");
            printf("echo 1 > /sys/class/gpio/gpio67/value");
            printf("-------------------\n");
            system("echo 1 > /sys/class/gpio/gpio67/value");
            device32_switch_state = 0;
            }
        }  
        is_checked = lv_obj_has_state(sw13, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!device33_switch_state) {
            printf("-------------------");
            printf("echo 0 > /sys/class/gpio/gpio65/value");
            printf("-------------------\n");
            system("echo 0 > /sys/class/gpio/gpio65/value");
            device33_switch_state = 1;
            }
        }else{
            if(device33_switch_state) {
            printf("-------------------");
            printf("echo 1 > /sys/class/gpio/gpio65/value");
            printf("-------------------\n");
            system("echo 1 > /sys/class/gpio/gpio65/value");
            device33_switch_state = 0;
            }
        }
        is_checked = lv_obj_has_state(sw2, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!is_checked_sw2) {
            is_checked_sw2 = 1;
            }
        }else{
            if(is_checked_sw2) {
            is_checked_sw2 = 0;
            }
        }
        is_checked = lv_obj_has_state(sw3, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!is_checked_sw3) {
            is_checked_sw3 = 1;
            }
        }else{
            if(is_checked_sw3) {
            is_checked_sw3 = 0;
            }
        } 
        is_checked = lv_obj_has_state(sw4, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!is_checked_sw4) {
            is_checked_sw4 = 1;
            }
        }else{
            if(is_checked_sw4) {
            is_checked_sw4 = 0;
            }
        } 
        is_checked = lv_obj_has_state(sw5, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!is_checked_sw5) {
            is_checked_sw5 = 1;
            }
        }else{
            if(is_checked_sw5) {
            is_checked_sw5 = 0;
            }
        } 
        is_checked = lv_obj_has_state(sw6, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!is_checked_sw6) {
            is_checked_sw6 = 1;
            }
        }else{
            if(is_checked_sw6) {
            is_checked_sw6 = 0;
            }
        } 
        is_checked = lv_obj_has_state(sw7, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
        if (is_checked)
        {
            if(!is_checked_sw7) {
            is_checked_sw7 = 1;
            }
        }else{
            if(is_checked_sw7) {
            is_checked_sw7 = 0;
            }
        } 
    }
}

static void profile_create(lv_obj_t *parent)
{
    device31_switch_state = 0;
    device32_switch_state = 0;
    device33_switch_state = 0;
    system("wpa_cli -i wlan0 scan");
    time_t nowtime;
    //首先创建一个time_t 类型的变量nowtime
    struct tm *p;
    //然后创建一个新时间结构体指针 p
    time(&nowtime);
    //使用该函数就可得到当前系统时间，使用该函数需要将传入time_t类型变量nowtime的地址值。
    p = localtime(&nowtime);
    ////由于此时变量nowtime中的系统时间值为日历时间，我们需要调用本地时间函数p=localtime（time_t* nowtime）将nowtime变量中的日历时间转化为本地时间，存入到指针为p的时间结构体中。不改的话，可以参照注意事项手动改。
    // printf("%02d:%02d:%02d\n", p->tm_hour, p->tm_min, p->tm_sec);
    // hour
    time_label = lv_label_create(parent);
    lv_obj_set_height(time_label, LV_SIZE_CONTENT);
    lv_obj_set_align(time_label, LV_ALIGN_TOP_LEFT);
    lv_label_set_text_fmt(time_label, "%02d", p->tm_hour);
    LV_FONT_DECLARE(font_time_65);
    lv_obj_set_style_text_font(time_label, &font_time_65, 0);
    lv_obj_set_style_text_color(time_label, lv_color_hex(0xffffff), 0);
    // min
    time_label1 = lv_label_create(parent);
    lv_obj_set_height(time_label1, LV_SIZE_CONTENT);
    lv_obj_set_align(time_label1, LV_ALIGN_TOP_LEFT);
    lv_obj_align(time_label1, LV_ALIGN_TOP_LEFT, 150, 0);
    lv_label_set_text_fmt(time_label1, "%02d", p->tm_min);
    LV_FONT_DECLARE(font_time_65);
    lv_obj_set_style_text_font(time_label1, &font_time_65, 0);
    lv_obj_set_style_text_color(time_label1, lv_color_hex(0xffffff), 0);
    // date
    date_label11 = lv_label_create(parent);
    lv_obj_align(date_label11, LV_ALIGN_TOP_LEFT, 0, 130);
    LV_FONT_DECLARE(font_date_16);
    lv_label_set_text_fmt(date_label11, "%4d/%02d/%02d", p->tm_year + 1900, p->tm_mon + 1, p->tm_mday);
    lv_obj_set_style_text_font(date_label11, &font_date_16, 0);
    lv_obj_set_style_text_color(date_label11, lv_color_hex(0xffffff), 0);
    // label
    label = lv_label_create(parent);
    lv_obj_set_height(label, LV_SIZE_CONTENT);
    lv_obj_align(label, LV_ALIGN_TOP_LEFT, 123, -10);
    lv_label_set_text_fmt(label, ":");
    if (flag_sleep==0){
    lv_timer_t *task = lv_timer_create(task_cb, 500, &user_data);
    flag_sleep=1;
    }
    lv_timer_t *task = lv_timer_create(weather_task_cb, (30*60*1000), &user_data);
    // lv_timer_t *task = lv_timer_create(task_cb, 500, &user_data);
    lv_timer_t *sw_task = lv_timer_create(switch_task_cb, 50, NULL);
    LV_FONT_DECLARE(font_time_65);
    lv_obj_set_style_text_font(label, &font_time_65, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(0xffffff), 0);
    //
    week_label = lv_label_create(parent);
    lv_obj_align(week_label, LV_ALIGN_TOP_LEFT, 165, 130);
    // LV_FONT_DECLARE(font_date_16);
    switch (p->tm_wday)
    {
    case 0:
        lv_label_set_text_fmt(week_label, "星期日");
        break;
    case 1:
        lv_label_set_text_fmt(week_label, "星期一");
        break;
    case 2:
        lv_label_set_text_fmt(week_label, "星期二");
        break;
    case 3:
        lv_label_set_text_fmt(week_label, "星期三");
        break;
    case 4:
        lv_label_set_text_fmt(week_label, "星期四");
        break;
    case 5:
        lv_label_set_text_fmt(week_label, "星期五");
        break;
    case 6:
        lv_label_set_text_fmt(week_label, "星期六");
        break;
    }
    LV_FONT_DECLARE(font_date_16);
    lv_obj_set_style_text_font(week_label, &font_date_16, 0);
    lv_obj_set_style_text_color(week_label, lv_color_hex(0xffffff), 0);

    temp_label = lv_label_create(parent);
    lv_obj_align(temp_label, LV_ALIGN_TOP_RIGHT, 0, 130);
    lv_label_set_text_fmt(temp_label, "%s %s℃",weather,temp);
    LV_FONT_DECLARE(font_chs_temp_16);
    lv_obj_set_style_text_font(temp_label, &font_chs_temp_16, 0);
    lv_obj_set_style_text_color(temp_label, lv_color_hex(0xffffff), 0);

    lv_obj_t *btn_panel = lv_obj_create(parent);
    lv_obj_set_height(btn_panel, LV_SIZE_CONTENT);
    lv_obj_set_width(btn_panel, 446);
    lv_obj_set_pos(btn_panel, 0, 200);
    lv_obj_set_style_pad_all(btn_panel, 0, 0);
    lv_obj_set_style_bg_opa(btn_panel, LV_OPA_0, 0);
    lv_obj_set_style_border_width(btn_panel, 0, 0);

    static lv_style_t style_add;
    lv_style_init(&style_add);
    lv_style_set_bg_color(&style_add, lv_color_hex(0xE3E6E8));
    lv_style_set_border_color(&style_add, lv_palette_darken(LV_PALETTE_LIGHT_BLUE, 3));
    lv_style_set_border_width(&style_add, 0);
    lv_style_set_radius(&style_add, 10);
    lv_style_set_shadow_width(&style_add, 0);
    lv_style_set_shadow_ofs_y(&style_add, 5);
    lv_style_set_shadow_opa(&style_add, LV_OPA_50);
    lv_style_set_text_color(&style_add, lv_color_white());
    lv_style_set_width(&style_add, 100);
    // lv_style_set_height(&style_add, LV_SIZE_CONTENT);

    static lv_style_t style_btn;
    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x80878C));
    lv_style_set_border_color(&style_btn, lv_palette_darken(LV_PALETTE_LIGHT_BLUE, 3));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    lv_style_set_shadow_ofs_y(&style_btn, 5);
    lv_style_set_shadow_opa(&style_btn, LV_OPA_50);
    lv_style_set_text_color(&style_btn, lv_color_white());
    lv_style_set_width(&style_btn, 100);

    lv_obj_t *add_btn;
    LV_IMG_DECLARE(icon_add);
    add_btn = lv_btn_create(btn_panel);
    lv_obj_add_style(add_btn, &style_add, 0);
    lv_obj_set_size(add_btn, 210, 100);
    lv_obj_add_event_cb(add_btn, event_handler_add, LV_EVENT_CLICKED, NULL);
    lv_obj_t *add_img = lv_img_create(add_btn);
    lv_img_set_src(add_img, &icon_add); //设置图片源
    lv_obj_align(add_img, LV_ALIGN_CENTER, 0, 0);
    // lv_obj_set_pos(add_btn, 50, 300);

    lv_obj_t *add_btn2;
    LV_IMG_DECLARE(icon_party);
    add_btn2 = lv_btn_create(btn_panel);
    lv_obj_add_style(add_btn2, &style_btn, 0);
    lv_obj_set_size(add_btn2, 210, 100);
    lv_obj_t *add_img2 = lv_img_create(add_btn2);
    lv_img_set_src(add_img2, &icon_party); //设置图片源
    lv_obj_align(add_img2, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_t *label_party = lv_label_create(add_btn2);
    lv_obj_set_style_text_font(label_party, &lv_font_montserrat_18, 0);
    lv_label_set_text(label_party, "Party");
    lv_obj_align(label_party, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *add_btn3;
    LV_IMG_DECLARE(icon_home);
    add_btn3 = lv_btn_create(btn_panel);
    lv_obj_add_style(add_btn3, &style_btn, 0);
    lv_obj_set_size(add_btn3, 210, 100);
    lv_obj_t *add_img3 = lv_img_create(add_btn3);
    lv_img_set_src(add_img3, &icon_home); //设置图片源
    lv_obj_align(add_img3, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_t *label_home = lv_label_create(add_btn3);
    lv_obj_set_style_text_font(label_home, &lv_font_montserrat_18, 0);
    lv_label_set_text(label_home, "Home");
    lv_obj_align(label_home, LV_ALIGN_CENTER, 0, 0);
    // lv_obj_set_pos(add_btn, 50, 300);

    lv_obj_t *add_btn4;
    LV_IMG_DECLARE(icon_home);
    add_btn4 = lv_btn_create(btn_panel);
    lv_obj_add_style(add_btn4, &style_btn, 0);
    lv_obj_set_size(add_btn4, 210, 100);
    lv_obj_t *add_img4 = lv_img_create(add_btn4);
    lv_img_set_src(add_img4, &icon_home); //设置图片源
    lv_obj_align(add_img4, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_t *label_away = lv_label_create(add_btn4);
    lv_obj_set_style_text_font(label_away, &lv_font_montserrat_18, 0);
    lv_label_set_text(label_away, "Away");
    lv_obj_align(label_away, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *cloud_img = lv_img_create(parent);
    LV_IMG_DECLARE(icon_cloud);
    lv_img_set_src(cloud_img, &icon_cloud); //设置图片源
    lv_obj_align(cloud_img, LV_ALIGN_CENTER, 140, -140);

    /*Create the top panel*/
    static lv_coord_t grid_1_col_dsc[] = {LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST};
    static lv_coord_t grid_1_row_dsc[] = {100, 100, LV_GRID_TEMPLATE_LAST};

    // lv_obj_set_grid_dsc_array(parent, grid_main_col_dsc, grid_main_row_dsc);

    // lv_obj_set_grid_cell(btn_panel, LV_GRID_ALIGN_STRETCH, 0, 2, LV_GRID_ALIGN_CENTER, 0, 1);

    lv_obj_set_grid_dsc_array(btn_panel, grid_1_col_dsc, grid_1_row_dsc);
    lv_obj_set_grid_align(btn_panel, LV_GRID_ALIGN_SPACE_BETWEEN, LV_GRID_ALIGN_END);
    lv_obj_set_grid_cell(add_btn, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_CENTER, 1, 1);
    lv_obj_set_grid_cell(add_btn2, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 0, 1);
    lv_obj_set_grid_cell(add_btn3, LV_GRID_ALIGN_STRETCH, 0, 1, LV_GRID_ALIGN_CENTER, 1, 1);
    lv_obj_set_grid_cell(add_btn4, LV_GRID_ALIGN_STRETCH, 1, 1, LV_GRID_ALIGN_CENTER, 0, 1);
}

static void analytics_create(lv_obj_t *parent)
{
    if (i<=strlen(language_setting))
    {
    strcpy(language_setting[i],language_Chinese[i]);
    printf("i=%d\n",i);
    i++;
    }
    tb = lv_tabview_create(parent, LV_DIR_TOP, 100);
    lv_obj_set_size(tb, 480, 450);

    // lv_obj_t *tab_btns = lv_tabview_get_tab_btns(tb);
    tab_btns = lv_tabview_get_tab_btns(tb);
    lv_obj_set_style_bg_color(tab_btns, lv_color_hex(0x2f3338), 0);
    lv_obj_set_style_bg_color(tab_btns, lv_color_white(), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_text_color(tab_btns, lv_color_white(), 0);
    lv_obj_set_style_text_color(tab_btns, lv_color_hex(0xffb400), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_border_color(tab_btns, lv_color_hex(0xffb400), LV_PART_ITEMS | LV_STATE_CHECKED);
    // lv_obj_set_style_bg_opa(tab_btns, LV_OPA_0, LV_PART_ITEMS | LV_STATE_CHECKED);
    // lv_obj_set_style_bg_img_src();
    LV_FONT_DECLARE(font_tabview_10);
    lv_obj_t *tb1 = lv_tabview_add_tab(tb, "设置");
    lv_obj_add_event_cb(tb, event_handler_tb, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_t *tab1_btn = lv_tabview_get_tab_btns(tab_btns);

    set_img = lv_img_create(tab_btns);
    lv_img_set_src(set_img, &icon_set_y);
    lv_obj_align(set_img, LV_ALIGN_TOP_LEFT, 23, 12);

    lv_obj_t *tb2 = lv_tabview_add_tab(tb, "设备");
    equipment_img = lv_img_create(tab_btns);
    lv_img_set_src(equipment_img, &icon_equipment_white); //设置图片源
    lv_obj_align(equipment_img, LV_ALIGN_TOP_LEFT, 145, 12);

    lv_obj_t *tb3 = lv_tabview_add_tab(tb, "场景");
    scenes_img = lv_img_create(tab_btns);
    lv_img_set_src(scenes_img, &icon_scenes_white); //设置图片源
    lv_obj_align(scenes_img, LV_ALIGN_TOP_LEFT, 265, 12);

    lv_obj_t *tb4 = lv_tabview_add_tab(tb, "主题");
    style_img = lv_img_create(tab_btns);
    lv_img_set_src(style_img, &icon_style_white); //设置图片源
    lv_obj_align(style_img, LV_ALIGN_TOP_LEFT, 385, 12);

    // setting
    LV_FONT_DECLARE(font_tabview_10);
    label_set = lv_label_create(tab_btns);
    lv_label_set_text(label_set, "设置");
    lv_obj_align_to(label_set, tab_btns, LV_ALIGN_LEFT_MID, 38, 35);
    // lv_obj_set_style_text_font(label_set, &font_tabview_10, 0);
    lv_obj_set_style_text_font(label_set, &font_mainwindowtb_chs_10, 0);
    lv_obj_set_style_text_color(label_set, lv_color_hex(0xffb400), 0);

    // equipment
    label_equipment = lv_label_create(tab_btns);
    lv_label_set_text(label_equipment, "设备");
    lv_obj_align_to(label_equipment, tab_btns, LV_ALIGN_LEFT_MID, 161, 35);
    // lv_obj_set_style_text_font(label_equipment, &font_tabview_10, 0);
    lv_obj_set_style_text_font(label_equipment, &font_mainwindowtb_chs_10, 0);
    // scenes
    label_scenes = lv_label_create(tab_btns);
    lv_label_set_text(label_scenes, "场景");
    lv_obj_align_to(label_scenes, tab_btns, LV_ALIGN_LEFT_MID, 283, 35);
    // lv_obj_set_style_text_font(label_scenes, &font_tabview_10, 0);
    lv_obj_set_style_text_font(label_scenes, &font_mainwindowtb_chs_10, 0);
    // style
    label_style = lv_label_create(tab_btns);
    lv_label_set_text(label_style, "主题");
    lv_obj_align_to(label_style, tab_btns, LV_ALIGN_LEFT_MID, 402, 35);
    // lv_obj_set_style_text_font(label_style, &font_tabview_10, 0);
    lv_obj_set_style_text_font(label_style, &font_mainwindowtb_chs_10, 0);
    

    lv_obj_set_style_bg_opa(tb, LV_OPA_0, 0);
    LV_FONT_DECLARE(font_chose_12);
    lv_obj_set_style_text_font(lv_scr_act(), &font_chose_12, 0);
    lv_obj_align(tb, LV_ALIGN_TOP_LEFT, -16, -16);

    // tb1
    static lv_style_t tb1_style;
    lv_style_init(&tb1_style);
    lv_style_set_bg_color(&tb1_style, lv_color_hex(0x80878c));
    lv_style_set_border_width(&tb1_style, 0);
    lv_style_set_radius(&tb1_style, 10);
    lv_style_set_shadow_width(&tb1_style, 0);
    lv_style_set_bg_opa(&tb1_style, LV_OPA_50); // 设置背景的透明度
    lv_obj_t *wifi_btn = lv_btn_create(tb1);
    lv_obj_add_style(wifi_btn, &tb1_style, 0);
    lv_obj_set_size(wifi_btn, 440, 60);
    lv_obj_align_to(wifi_btn, tb1, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_add_event_cb(wifi_btn, event_handler_wifi, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img1 = lv_img_create(wifi_btn);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(next_img1, &icon_next_white); //设置图片源
    lv_obj_align(next_img1, LV_ALIGN_RIGHT_MID, 0, 0);
    label_wifi_mainwindow = lv_label_create(wifi_btn);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_wifi_mainwindow, &font_chs_16, 0);
    lv_label_set_text(label_wifi_mainwindow, "网络设置");
    // lv_label_set_text(label_wifi_mainwindow,language_setting[0]);
    lv_obj_align_to(label_wifi_mainwindow, wifi_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *sound_btn = lv_btn_create(tb1);
    lv_obj_add_style(sound_btn, &tb1_style, 0);
    lv_obj_set_size(sound_btn, 440, 60);
    lv_obj_align_to(sound_btn, wifi_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(sound_btn, event_handler_voice, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img2 = lv_img_create(sound_btn);
    lv_img_set_src(next_img2, &icon_next_white); //设置图片源
    lv_obj_align(next_img2, LV_ALIGN_RIGHT_MID, 0, 0);
    label_sound_mainwindow = lv_label_create(sound_btn);
    lv_obj_set_style_text_font(label_sound_mainwindow, &font_chs_16, 0);
    lv_label_set_text(label_sound_mainwindow, "语音控制与音量");
    lv_obj_align_to(label_sound_mainwindow, sound_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *date_btn = lv_btn_create(tb1);
    lv_obj_add_style(date_btn, &tb1_style, 0);
    lv_obj_set_size(date_btn, 440, 60);
    lv_obj_align_to(date_btn, sound_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(date_btn, event_handler_date, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img3 = lv_img_create(date_btn);
    lv_img_set_src(next_img3, &icon_next_white); //设置图片源
    lv_obj_align(next_img3, LV_ALIGN_RIGHT_MID, 0, 0);
    label_date_mainwindow = lv_label_create(date_btn);
    lv_obj_set_style_text_font(label_date_mainwindow, &font_chs_16, 0);
    lv_label_set_text(label_date_mainwindow, "语言与日期");
    lv_obj_align_to(label_date_mainwindow, date_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *display_btn = lv_btn_create(tb1);
    lv_obj_add_style(display_btn, &tb1_style, 0);
    lv_obj_set_size(display_btn, 440, 60);
    lv_obj_align_to(display_btn, date_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(display_btn, event_handler_display, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img4 = lv_img_create(display_btn);
    lv_img_set_src(next_img4, &icon_next_white); //设置图片源
    lv_obj_align(next_img4, LV_ALIGN_RIGHT_MID, 0, 0);
    label_display_mainwindow = lv_label_create(display_btn);
    lv_obj_set_style_text_font(label_display_mainwindow, &font_chs_16, 0);
    lv_label_set_text(label_display_mainwindow, "显示调节");
    lv_obj_align_to(label_display_mainwindow, display_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *system_btn = lv_btn_create(tb1);
    lv_obj_add_style(system_btn, &tb1_style, 0);
    lv_obj_set_size(system_btn, 440, 60);
    lv_obj_align_to(system_btn, display_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(system_btn, event_handler_system, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img5 = lv_img_create(system_btn);
    lv_img_set_src(next_img5, &icon_next_white); //设置图片源
    lv_obj_align(next_img5, LV_ALIGN_RIGHT_MID, 0, 0);
    label_system_mainwindow = lv_label_create(system_btn);
    lv_obj_set_style_text_font(label_system_mainwindow, &font_chs_16, 0);
    lv_label_set_text(label_system_mainwindow, "设备与系统");
    lv_obj_align_to(label_system_mainwindow, system_btn, LV_ALIGN_LEFT_MID, 0, 0);

    lv_obj_t *response_btn = lv_btn_create(tb1);
    lv_obj_add_style(response_btn, &tb1_style, 0);
    lv_obj_set_size(response_btn, 440, 60);
    lv_obj_align_to(response_btn, system_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(response_btn, event_handler_response, LV_EVENT_CLICKED, NULL);
    lv_obj_t *next_img55 = lv_img_create(response_btn);
    lv_img_set_src(next_img55, &icon_next_white); //设置图片源
    lv_obj_align(next_img55, LV_ALIGN_RIGHT_MID, 0, 0);
    label_response_mainwindow = lv_label_create(response_btn);
    lv_obj_set_style_text_font(label_response_mainwindow, &font_chs_16, 0);
    lv_label_set_text(label_response_mainwindow, "语音响应");
    lv_obj_align_to(label_response_mainwindow,response_btn, LV_ALIGN_LEFT_MID, 0, 0);

    // tb2
    // static lv_style_t drag_style;
    // lv_style_init(&drag_style);
    // lv_style_set_bg_color(&drag_style, lv_color_hex(0xe3e6e8));
    // lv_style_set_border_width(&drag_style, 0);
    // lv_style_set_radius(&drag_style, 10);
    // lv_style_set_shadow_width(&drag_style, 0);
    // lv_style_set_text_color(&drag_style, lv_color_hex(0x2f3338));
    // lv_style_set_bg_opa(&drag_style, LV_OPA_70); // 设置背景的透明度
    static lv_style_t drag_style;
    lv_style_init(&drag_style);
    lv_style_set_bg_color(&drag_style, lv_color_hex(0x80878c));
    lv_style_set_border_width(&drag_style, 0);
    lv_style_set_radius(&drag_style, 10);
    lv_style_set_shadow_width(&drag_style, 0);
    lv_style_set_bg_opa(&drag_style, LV_OPA_50); // 设置背景的透明度
    // LED1
    lv_obj_t *lamp_btn1 = lv_btn_create(tb2);
    lv_obj_add_style(lamp_btn1, &drag_style, 0);
    lv_obj_set_size(lamp_btn1, 440, 60);
    lv_obj_align_to(lamp_btn1, tb2, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_add_event_cb(lamp_btn1, event_handler_devices31, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img1 = lv_img_create(lamp_btn1);
    LV_IMG_DECLARE(icon_drag);
    lv_img_set_src(drag_img1, &icon_drag); //设置图片源
    lv_obj_align(drag_img1, LV_ALIGN_LEFT_MID, 0, 0);
    label_lamp1 = lv_label_create(lamp_btn1);
    lv_obj_set_style_text_font(label_lamp1, &font_chs_16, 0);
    // LV_FONT_DECLARE(font_emb_chs_16);
    // lv_obj_set_style_text_font(label_lamp1, &font_emb_chs_16, 0);
    lv_label_set_text(label_lamp1, "吸顶灯1");
    lv_obj_align_to(label_lamp1, drag_img1, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw11 = lv_switch_create(lamp_btn1);
    lv_obj_align(sw11, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw11, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw11, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw11, LV_ALIGN_RIGHT_MID, -10, 0);
    lv_obj_add_event_cb(sw11, event_handler_devices31_switch, LV_EVENT_VALUE_CHANGED, NULL);
    // lv_obj_add_event_cb(sw1, event_handler_switch, LV_EVENT_RELEASED, NULL);

    lv_obj_t *lamp_btn2 = lv_btn_create(tb2);
    lv_obj_add_style(lamp_btn2, &drag_style, 0);
    lv_obj_set_size(lamp_btn2, 440, 60);
    lv_obj_align_to(lamp_btn2, lamp_btn1, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(lamp_btn2, event_handler_devices32, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img22 = lv_img_create(lamp_btn2);
    LV_IMG_DECLARE(icon_drag);
    lv_img_set_src(drag_img22, &icon_drag); //设置图片源
    lv_obj_align(drag_img22, LV_ALIGN_LEFT_MID, 0, 0);
    label_lamp22 = lv_label_create(lamp_btn2);
    lv_obj_set_style_text_font(label_lamp22, &font_chs_16, 0);
    lv_label_set_text(label_lamp22, "吸顶灯2");
    lv_obj_align_to(label_lamp22, drag_img22, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw12 = lv_switch_create(lamp_btn2);
    lv_obj_align(sw12, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw12, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw12, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw12, event_handler_devices32_switch, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_align(sw12, LV_ALIGN_RIGHT_MID, -10, 0);

    lv_obj_t *lamp_btn3 = lv_btn_create(tb2);
    lv_obj_add_style(lamp_btn3, &drag_style, 0);
    lv_obj_set_size(lamp_btn3, 440, 60);
    lv_obj_align_to(lamp_btn3, lamp_btn2, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(lamp_btn3, event_handler_devices33, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img33 = lv_img_create(lamp_btn3);
    LV_IMG_DECLARE(icon_drag);
    lv_img_set_src(drag_img33, &icon_drag); //设置图片源
    lv_obj_align(drag_img33, LV_ALIGN_LEFT_MID, 0, 0);
    label_lamp33 = lv_label_create(lamp_btn3);
    lv_obj_set_style_text_font(label_lamp33, &font_chs_16, 0);
    lv_label_set_text(label_lamp33, "吸顶灯3");
    lv_obj_align_to(label_lamp33, drag_img33, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw13 = lv_switch_create(lamp_btn3);
    lv_obj_align(sw13, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw13, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw13, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw13, event_handler_devices33_switch, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_align(sw13, LV_ALIGN_RIGHT_MID, -10, 0);

    lv_obj_t *door_btn = lv_btn_create(tb2);
    lv_obj_add_style(door_btn, &drag_style, 0);
    lv_obj_set_size(door_btn, 440, 60);
    lv_obj_align_to(door_btn, lamp_btn3, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(door_btn, event_handler_devices4, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img2 = lv_img_create(door_btn);
    lv_img_set_src(drag_img2, &icon_drag); //设置图片源
    lv_obj_align(drag_img2, LV_ALIGN_LEFT_MID, 0, 0);
    label_door = lv_label_create(door_btn);
    lv_obj_set_style_text_font(label_door, &font_chs_16, 0);
    lv_label_set_text(label_door, "门磁");
    lv_obj_align_to(label_door, drag_img2, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw2 = lv_switch_create(door_btn);
    lv_obj_align(sw2, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw2, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw2, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw2, LV_ALIGN_RIGHT_MID, -10, 0);
    lv_obj_add_event_cb(sw2, event_handler_sw2, LV_EVENT_RELEASED, NULL);

    lv_obj_t *AC_btn = lv_btn_create(tb2);
    lv_obj_add_style(AC_btn, &drag_style, 0);
    lv_obj_set_size(AC_btn, 440, 60);
    lv_obj_align_to(AC_btn, door_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(AC_btn, event_handler_devices5, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img3 = lv_img_create(AC_btn);
    lv_img_set_src(drag_img3, &icon_drag); //设置图片源
    lv_obj_align(drag_img3, LV_ALIGN_LEFT_MID, 0, 0);
    label_AC = lv_label_create(AC_btn);
    lv_obj_set_style_text_font(label_AC, &font_chs_16, 0);
    lv_label_set_text(label_AC, "空调");
    lv_obj_align_to(label_AC, drag_img3, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw3 = lv_switch_create(AC_btn);
    lv_obj_align(sw3, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw3, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw3, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw3, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw3, event_handler_switch, LV_EVENT_RELEASED, NULL);

    lv_obj_t *infrared_btn = lv_btn_create(tb2);
    lv_obj_add_style(infrared_btn, &drag_style, 0);
    lv_obj_set_size(infrared_btn, 440, 60);
    lv_obj_align_to(infrared_btn, AC_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(infrared_btn, event_handler_devices6, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img4 = lv_img_create(infrared_btn);
    lv_img_set_src(drag_img4, &icon_drag); //设置图片源
    lv_obj_align(drag_img4, LV_ALIGN_LEFT_MID, 0, 0);
    label_infrared = lv_label_create(infrared_btn);
    lv_obj_set_style_text_font(label_infrared, &font_chs_16, 0);
    lv_label_set_text(label_infrared, "红外感应");
    lv_obj_align_to(label_infrared, drag_img4, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw4 = lv_switch_create(infrared_btn);
    lv_obj_align(sw4, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw4, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw4, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw4, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw4, event_handler_switch, LV_EVENT_RELEASED, NULL);

    lv_obj_t *float_btn = lv_btn_create(tb2);
    lv_obj_add_style(float_btn, &drag_style, 0);
    lv_obj_set_size(float_btn, 440, 60);
    lv_obj_align_to(float_btn, infrared_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(float_btn, event_handler_devices7, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img5 = lv_img_create(float_btn);
    lv_img_set_src(drag_img5, &icon_drag); //设置图片源
    lv_obj_align(drag_img5, LV_ALIGN_LEFT_MID, 0, 0);
    label_float = lv_label_create(float_btn);
    lv_obj_set_style_text_font(label_float, &font_chs_16, 0);
    lv_label_set_text(label_float, "地暖");
    lv_obj_align_to(label_float, drag_img5, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw5 = lv_switch_create(float_btn);
    lv_obj_align(sw5, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw5, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw5, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw5, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw5, event_handler_switch, LV_EVENT_RELEASED, NULL);

    lv_obj_t *curtain_btn = lv_btn_create(tb2);
    lv_obj_add_style(curtain_btn, &drag_style, 0);
    lv_obj_set_size(curtain_btn, 440, 60);
    lv_obj_align_to(curtain_btn, float_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(curtain_btn, event_handler_devices, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img6 = lv_img_create(curtain_btn);
    lv_img_set_src(drag_img6, &icon_drag); //设置图片源
    lv_obj_align(drag_img6, LV_ALIGN_LEFT_MID, 0, 0);
    label_curtain = lv_label_create(curtain_btn);
    lv_obj_set_style_text_font(label_curtain, &font_chs_16, 0);
    lv_label_set_text(label_curtain, "窗帘");
    lv_obj_align_to(label_curtain, drag_img6, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw6 = lv_switch_create(curtain_btn);
    lv_obj_align(sw6, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw6, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw6, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw6, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw6, event_handler_switch, LV_EVENT_RELEASED, NULL);

    lv_obj_t *wind_btn = lv_btn_create(tb2);
    lv_obj_add_style(wind_btn, &drag_style, 0);
    lv_obj_set_size(wind_btn, 440, 60);
    lv_obj_align_to(wind_btn, curtain_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(wind_btn, event_handler_devices1, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img7 = lv_img_create(wind_btn);
    lv_img_set_src(drag_img7, &icon_drag); //设置图片源
    lv_obj_align(drag_img7, LV_ALIGN_LEFT_MID, 0, 0);
    label_wind = lv_label_create(wind_btn);
    lv_obj_set_style_text_font(label_wind, &font_chs_16, 0);
    lv_label_set_text(label_wind, "新风");
    lv_obj_align_to(label_wind, drag_img7, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    sw7 = lv_switch_create(wind_btn);
    lv_obj_align(sw7, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw7, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw7, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw7, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw7, event_handler_switch, LV_EVENT_RELEASED, NULL);

    // tb3
    lv_obj_t *theme1_btn = lv_btn_create(tb3);
    lv_obj_add_style(theme1_btn, &drag_style, 0);
    lv_obj_set_size(theme1_btn, 440, 60);
    lv_obj_align_to(theme1_btn, tb3, LV_ALIGN_TOP_LEFT, 0, 0);
    // lv_obj_add_event_cb(theme1_btn, event_handler_wifi, LV_EVENT_CLICKED, NULL);
    lv_obj_t *drag_img8 = lv_img_create(theme1_btn);
    lv_img_set_src(drag_img8, &icon_drag); //设置图片源
    lv_obj_align(drag_img8, LV_ALIGN_LEFT_MID, 0, 0);
    label_theme1 = lv_label_create(theme1_btn);
    lv_obj_set_style_text_font(label_theme1, &font_chs_16, 0);
    lv_label_set_text(label_theme1, "主题1");
    lv_obj_align_to(label_theme1, drag_img8, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    lv_obj_t *sw8 = lv_switch_create(theme1_btn);
    lv_obj_align(sw8, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw8, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw8, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw8, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw8, event_handler_switch, LV_EVENT_CLICKED, NULL);

    lv_obj_t *theme2_btn = lv_btn_create(tb3);
    lv_obj_add_style(theme2_btn, &drag_style, 0);
    lv_obj_set_size(theme2_btn, 440, 60);
    lv_obj_align_to(theme2_btn, theme1_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_t *drag_img9 = lv_img_create(theme2_btn);
    lv_img_set_src(drag_img9, &icon_drag); //设置图片源
    lv_obj_align(drag_img9, LV_ALIGN_LEFT_MID, 0, 0);
    label_theme2 = lv_label_create(theme2_btn);
    lv_obj_set_style_text_font(label_theme2, &font_chs_16, 0);
    lv_label_set_text(label_theme2, "主题2");
    lv_obj_align_to(label_theme2, drag_img9, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    lv_obj_t *sw9 = lv_switch_create(theme2_btn);
    lv_obj_align(sw9, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw9, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw9, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_align(sw9, LV_ALIGN_RIGHT_MID, -10, 0);
    // lv_obj_add_event_cb(sw9, event_handler_switch, LV_EVENT_CLICKED, NULL);
}

void getweather(char temp[],char weather[]){
    FILE *fp;
    int i=0;
    int wifi_status = 0;
    char buf[1024];
    char buft[1024];
    system("touch /userdata/weather.json");

    //判断是否有网
    system("wpa_cli -i wlan0 status > /userdata/wpa_status");
    FILE* fp1;
    char bufstatus[1000];
    memset(bufstatus, 0, 1000);

    if ((fp1 = fopen("/userdata/wpa_status", "r")) == NULL)
    {
        printf("fopen error-------------\n");
        perror("fail to read wpa_status");
        //exit(1);
    }
    
    while (fp1> 0 && fgets(bufstatus, 1024, fp1) != NULL)
    {
        printf("line:%s\n",bufstatus);
        if(strlen(bufstatus) > 0) {
            if(strstr(bufstatus,"wpa_state=") != NULL) {
                if(strstr(bufstatus,"COMPLETED") != NULL) {
                    wifi_status = 1;
                }
            }
        }
    }
    if(fp1 > 0) fclose(fp1);
    if(wifi_status) {
        system("wget https://weather.cma.cn/api/weather/view?stationid= -O /userdata/weather.json");
    } else {
        return;
    }
    
    // 获得文件大小
    //struct stat statbuf;
    int fileSize = 5000;
    //char* jsonStr;
    //jsonStr = (char*)malloc(fileSize);
    char jsonStr[5000];
    memset(jsonStr, 0, fileSize);
    system("touch /userdata/weather.json");
    if ((fp = fopen("/userdata/weather.json", "r")) == NULL)
    {
        printf("fopen error-------------\n");
        //perror("fail to open");
    }
    //printf("stat start\n");
    //int ret = stat("/userdata/weather.json", &statbuf);
    //printf("stat end\n");
    //if(ret == 0) {
    //    printf("fp>0\n");
    //    fileSize = statbuf.st_size;
    //    printf("文件大小：%d", fileSize);
    //    if(fileSize > 0) {
    //        // 分配符合文件大小的内存
    //        *jsonStr = (char *)malloc(sizeof(char) * fileSize + 1);
    //        memset(jsonStr, 0, fileSize + 1);
    //    }
    //}
    if (fp > 0) {
        //fseek(fp,0,SEEK_END);
        //fileSize = ftell(fp);
        //printf("fileSize-->%d\n",fileSize);
        //if(fileSize > 0) {
        //    // 分配符合文件大小的内存
        //    *jsonStr = (char *)malloc(sizeof(char) * fileSize + 1);
        //    memset(jsonStr, 0, fileSize + 1);
        //    fseek(fp,0,SEEK_SET);
        while (fgets(buf, 1024, fp) != NULL) {
            //printf("%s\n",buf);
            //memcpy(jsonStr+i, buf, sizeof(buf));
            strcpy(jsonStr + i, buf);
            i = i + strlen(buf);
            //for(i=0;i<strlen(buf);i++){
            //    if(buf[i]=='X'&&buf[i+12]=='Y'){
            //        if(buf[i+3]=='2'&&buf[i+4]=='8'&&buf[i+5]=='9')
            //            if(buf[i+15]=='2'&&buf[i+16]=='5'&&buf[i+17]=='5')
            //                strcpy(buft,buf);
            //    }
            //}

        }
        printf("%s\n", jsonStr);
    }
    fclose(fp);

    // 将读取到的json字符串转换成json变量指针
    cJSON* root = cJSON_Parse(jsonStr);
    if (!root) {
        printf("fileSize 0\n");
        //const char* err = cJSON_GetErrorPtr();
        printf("Error json parse!\n");
        //free((void*)err);
    }
    else {
        printf("fileSize %d\n", fileSize);
        cJSON* data = NULL;
        //cJSON *location = NULL;
        cJSON* daily = NULL;
        cJSON* now = NULL;
        data = cJSON_GetObjectItem(root, "data");
        if (data != NULL) {
            //location = cJSON_GetObjectItem(data, "location");
            //if (location != NULL) {
            //    cJSON *item = cJSON_GetObjectItem(now, "name");	
            //    if (item != NULL && item->type == cJSON_String) {
            //        sprintf(temp,"%.1f",t->valuedouble);
            //    }
            //    free(item);
            //}
            printf("get data\n");
            daily = cJSON_GetObjectItem(data, "daily");
            printf("data->now\n");
            now = cJSON_GetObjectItem(data, "now");
            printf("data->now ok\n");
            if (daily != NULL) {
                printf("get daily\n");
                int size = cJSON_GetArraySize(daily);
                if (size > 0) {
                    printf("daily size-->%d\n", size);
                    cJSON* arr = cJSON_GetArrayItem(daily, 0);
                    if (arr != NULL) {
                        printf("get arr\n");
                        cJSON* w = cJSON_GetObjectItem(arr, "dayText");
                        if (w != NULL && w->type == cJSON_String) {
                            printf("arr value-->%s\n", w->valuestring);
                            strcpy(weather, w->valuestring);
                        }
                        printf("free w\n");
                        //free(w);
                    }
                    printf("free arr\n");
                    //free(arr);
                }
                printf("free daily\n");
                //free(daily);
            }
            if (now != NULL) {
                printf("get now\n");
                cJSON* item = cJSON_GetObjectItem(now, "temperature");
                if (item != NULL && item->type == cJSON_Number) {
                    printf("get temp-->%f\n", item->valuedouble);
                    sprintf(temp, "%.1f", item->valuedouble);
                    //free(item);
                }
                printf("free now\n");
                //free(now);
            }
            else {
                printf("get now null\n");
            }
        }
        //printf("free daily\n");
        //if (daily != NULL) free(daily);
        //printf("free now\n");
        //if (now != NULL) free(now);
        //printf("free data\n");
        //if (data != NULL) free(data);
    }
    cJSON_Delete(root);
    printf("free jsonStr\n");
    //if (jsonStr != NULL) free(jsonStr);

/*
    //printf("\nnew  %s\n",buft);
    int ii,j,a,b,n,k,n1,k1;
    a=b=0;
    n1=k1=0;
     for(j=0;j<strlen(buft)-2;j++){
                        if((buft[j])=='t'&&buft[j+3]=='1'){//wifi=
                            n=j+6;//起始下标
                            n1=n;
                            //printf(" n%d",n);
                        while((buft[n1++])!='\"'){a++;}//printf(" a%d",a);
                        }
                        }
                        
    for(ii=0;ii<strlen(buft)-2;ii++){
                        if((buft[ii])=='D'&&buft[ii+7]=='d'){//passwd=
                            k=ii+10;//起始下标
                            k1=k;
                            //printf(" k%d",k);
                        while((buft[k1++])!='\"'){b++;}//printf(" b%d",b);
                        }
                        }
                        memcpy(temp,&buft[n],a);
                        memcpy(weather,&buft[k],b);
                        temp[a]='\0';
                        weather[b]='\0';
                        
    */
}
void mainwindow(void)
{


    FILE* fp;
    int i = 0;
    char buf[1024];
    // 获得文件大小
    //struct stat statbuf;
    int fileSize = 5000;
    //char* jsonStr;
    //jsonStr = (char*)malloc(fileSize);
    char jsonStr[5000];
    memset(jsonStr, 0, fileSize);
    system("touch /userdata/weather.json");
    if ((fp = fopen("/userdata/weather.json", "r")) == NULL)
    {
        printf("fopen error-------------\n");
        //perror("fail to open");
    }
    //printf("stat start\n");
    //int ret = stat("/userdata/weather.json", &statbuf);
    //printf("stat end\n");
    //if(ret == 0) {
    //    printf("fp>0\n");
    //    fileSize = statbuf.st_size;
    //    printf("文件大小：%d", fileSize);
    //    if(fileSize > 0) {
    //        // 分配符合文件大小的内存
    //        *jsonStr = (char *)malloc(sizeof(char) * fileSize + 1);
    //        memset(jsonStr, 0, fileSize + 1);
    //    }
    //}
    if (fp > 0) {
        //fseek(fp,0,SEEK_END);
        //fileSize = ftell(fp);
        //printf("fileSize-->%d\n",fileSize);
        //if(fileSize > 0) {
        //    // 分配符合文件大小的内存
        //    *jsonStr = (char *)malloc(sizeof(char) * fileSize + 1);
        //    memset(jsonStr, 0, fileSize + 1);
        //    fseek(fp,0,SEEK_SET);
        while (fgets(buf, 1024, fp) != NULL) {
            //printf("%s\n",buf);
            //memcpy(jsonStr+i, buf, sizeof(buf));
            strcpy(jsonStr + i, buf);
            i = i + strlen(buf);
            //for(i=0;i<strlen(buf);i++){
            //    if(buf[i]=='X'&&buf[i+12]=='Y'){
            //        if(buf[i+3]=='2'&&buf[i+4]=='8'&&buf[i+5]=='9')
            //            if(buf[i+15]=='2'&&buf[i+16]=='5'&&buf[i+17]=='5')
            //                strcpy(buft,buf);
            //    }
            //}

        }
        printf("%s\n", jsonStr);
    }
    fclose(fp);

    // 将读取到的json字符串转换成json变量指针
    cJSON* root = cJSON_Parse(jsonStr);
    if (!root) {
        printf("fileSize 0\n");
        //const char* err = cJSON_GetErrorPtr();
        printf("Error json parse!\n");
        //free((void*)err);
    }
    else {
        printf("fileSize %d\n", fileSize);
        cJSON* data = NULL;
        //cJSON *location = NULL;
        cJSON* daily = NULL;
        cJSON* now = NULL;
        data = cJSON_GetObjectItem(root, "data");
        if (data != NULL) {
            //location = cJSON_GetObjectItem(data, "location");
            //if (location != NULL) {
            //    cJSON *item = cJSON_GetObjectItem(now, "name");	
            //    if (item != NULL && item->type == cJSON_String) {
            //        sprintf(temp,"%.1f",t->valuedouble);
            //    }
            //    free(item);
            //}
            printf("get data\n");
            daily = cJSON_GetObjectItem(data, "daily");
            printf("data->now\n");
            now = cJSON_GetObjectItem(data, "now");
            printf("data->now ok\n");
            if (daily != NULL) {
                printf("get daily\n");
                int size = cJSON_GetArraySize(daily);
                if (size > 0) {
                    printf("daily size-->%d\n", size);
                    cJSON* arr = cJSON_GetArrayItem(daily, 0);
                    if (arr != NULL) {
                        printf("get arr\n");
                        cJSON* w = cJSON_GetObjectItem(arr, "dayText");
                        if (w != NULL && w->type == cJSON_String) {
                            printf("arr value-->%s\n", w->valuestring);
                            strcpy(weather, w->valuestring);
                        }
                        printf("free w\n");
                        //free(w);
                    }
                    printf("free arr\n");
                    //free(arr);
                }
                printf("free daily\n");
                //free(daily);
            }
            if (now != NULL) {
                printf("get now\n");
                cJSON* item = cJSON_GetObjectItem(now, "temperature");
                if (item != NULL && item->type == cJSON_Number) {
                    printf("get temp-->%f\n", item->valuedouble);
                    sprintf(temp, "%.1f", item->valuedouble);
                    //free(item);
                }
                printf("free now\n");
                //free(now);
            }
            else {
                printf("get now null\n");
            }
        }
        //printf("free daily\n");
        //if (daily != NULL) free(daily);
        //printf("free now\n");
        //if (now != NULL) free(now);
        //printf("free data\n");
        //if (data != NULL) free(data);
    }
    cJSON_Delete(root);
    printf("free jsonStr\n");
    //if (jsonStr != NULL) free(jsonStr);
    //while(true){usleep(100000);}*/




    /*Initialize and register a input driver*/
    // evdev_init();
    // lv_indev_drv_t indev_drv;
    // lv_indev_drv_init(&indev_drv);
    // indev_drv.type = LV_INDEV_TYPE_POINTER;
    // indev_drv.read_cb = evdev_read;
    // lv_indev_drv_register(&indev_drv);


    // screen_protection();
    if (LV_HOR_RES <= 320)
        disp_size = DISP_SMALL;
    else if (LV_HOR_RES < 720)
        disp_size = DISP_MEDIUM;
    else
        disp_size = DISP_LARGE;

    font_large = LV_FONT_DEFAULT;
    font_normal = LV_FONT_DEFAULT;

    lv_coord_t tab_h;
    if (disp_size == DISP_LARGE)
    {
        tab_h = 70;
#if LV_FONT_MONTSERRAT_24
        font_large = &lv_font_montserrat_24;
#else
        LV_LOG_WARN("LV_FONT_MONTSERRAT_24 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
#if LV_FONT_MONTSERRAT_16
        font_normal = &lv_font_montserrat_16;
#else
        LV_LOG_WARN("LV_FONT_MONTSERRAT_16 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
    }
    else if (disp_size == DISP_MEDIUM)
    {
        tab_h = 0;
#if LV_FONT_MONTSERRAT_20
        font_large = &lv_font_montserrat_20;
#else
        LV_LOG_WARN("LV_FONT_MONTSERRAT_20 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
#if LV_FONT_MONTSERRAT_14
        font_normal = &lv_font_montserrat_14;
#else
        LV_LOG_WARN("LV_FONT_MONTSERRAT_14 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
    }
    else
    { /* disp_size == DISP_SMALL */
        tab_h = 45;
#if LV_FONT_MONTSERRAT_18
        font_large = &lv_font_montserrat_18;
#else
        LV_LOG_WARN("LV_FONT_MONTSERRAT_18 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
#if LV_FONT_MONTSERRAT_12
        font_normal = &lv_font_montserrat_12;
#else
        LV_LOG_WARN("LV_FONT_MONTSERRAT_12 is not enabled for the widgets demo. Using LV_FONT_DEFAULT instead.")
#endif
    }

#if LV_USE_THEME_DEFAULT
    lv_theme_default_init(NULL, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED), LV_THEME_DEFAULT_DARK, font_normal);
#endif

    lv_style_init(&style_text_muted);
    lv_style_set_text_opa(&style_text_muted, LV_OPA_50);

    lv_style_init(&style_title);
    lv_style_set_text_font(&style_title, font_large);

    lv_style_init(&style_icon);
    lv_style_set_text_color(&style_icon, lv_theme_get_color_primary(NULL));
    lv_style_set_text_font(&style_icon, font_large);

    lv_style_init(&style_bullet);
    lv_style_set_border_width(&style_bullet, 0);
    lv_style_set_radius(&style_bullet, LV_RADIUS_CIRCLE);

    tv = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, tab_h);
    // lv_obj_set_size(tv, LV_HOR_RES, LV_VER_RES); //设置大小
    // lv_obj_align(tv, NULL, LV_ALIGN_TOP_LEFT, 0, 0);//对齐
    LV_IMG_DECLARE(bg_loading1); //声明图片
    lv_obj_set_style_bg_img_src(tv, &bg_loading1, 0);
    lv_obj_center(tv);
    lv_obj_set_scrollbar_mode(tv, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条
    // lv_tabview_set_btns_pos(tv); //不显示btns
    lv_obj_set_style_text_font(lv_scr_act(), font_normal, 0);

    label_slider = lv_label_create(tv);
    lv_obj_set_size(label_slider, 480, 30); //设置大小
    lv_label_set_text(label_slider, "");
    lv_obj_move_foreground(label_slider);
    lv_obj_align_to(label_slider, tv, LV_ALIGN_BOTTOM_MID, 0, -20);

    LV_IMG_DECLARE(slider_gray);
    slider_gray_img1 = lv_img_create(label_slider);
    lv_img_set_src(slider_gray_img1, &slider_gray); //设置图片源
    lv_obj_align_to(slider_gray_img1, label_slider, LV_ALIGN_BOTTOM_MID, 0, -20);

    LV_IMG_DECLARE(icon_slider_yellow);
    slider_yellow_img = lv_img_create(label_slider);
    lv_img_set_src(slider_yellow_img, &icon_slider_yellow); //设置图片源
    lv_obj_align_to(slider_yellow_img, slider_gray_img1, LV_ALIGN_OUT_LEFT_MID, -10, 0);

    slider_gray_img2 = lv_img_create(label_slider);
    lv_img_set_src(slider_gray_img2, &slider_gray); //设置图片源
    lv_obj_align_to(slider_gray_img2, slider_gray_img1, LV_ALIGN_OUT_RIGHT_MID, 10, 0);

    t1 = lv_tabview_add_tab(tv, "Profile");
    t2 = lv_tabview_add_tab(tv, "Analytics");
    lv_obj_set_scrollbar_mode(t2, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条
    lv_obj_clear_flag(t2, LV_OBJ_FLAG_SCROLLABLE);
    // lv_obj_t *t3 = lv_tabview_add_tab(tv, "Shop");
    profile_create(t1);
    analytics_create(t2);
    printf("\n开始从配置文件连接wifi\n");
    task_sw3 = lv_timer_create(task_cb_sw3, 50, NULL);                                          


    sleep_task = lv_timer_create(task_sleep, 100, NULL);
    change_task = lv_timer_create(task_change, 1000, NULL);
    lv_timer_create(task_stk3332_unlock, 1000, NULL);

}

void task_cb_sw3(lv_timer_t * task)
{
    FILE* fpflag;/*文件指针*/ 
    //char sw_flag[5];
    memset(sw_flag, 0, sizeof(sw_flag));
    if ((fpflag = fopen("/userdata/sw_flag", "r")) == NULL){ 
        perror("fail to read flag");}
    else{
        fgets(sw_flag, 5, fpflag);fclose(fpflag);}
    //判断是否有网
    printf("sw_flag---------%s\n",sw_flag);
    if(sw_flag[0]=='y'){
    //is_checked_wifi=1;
 
    printf("3333333333333333\n");
    //system("wpa_cli -i wlan0 status > /userdata/wpa_status");
    FILE* fp1;
    char bufstatus[100];
    memset(bufstatus, 0, 100);
    char buf1[400];
    system();
    if ((fp1 = fopen("/userdata/wifi_save", "r")) == NULL)
    {
        printf("fopen error-------------\n");
        perror("3 fail to read wifi_save");
        //exit(1);
    }
    while (fp1> 0 && fgets(bufstatus, 100, fp1) != NULL);
    fclose(fp1);
    printf("line3:%s\n",bufstatus);
        if(strlen(bufstatus) > 0) {
           //1.读文件获取上一次连接的wifi
            char wifiname[50]={};
            char wifipasswd[50]={};
            wifi_readconfig(wifiname,wifipasswd);
            printf("\n%s %s\n",wifiname,wifipasswd);
            //2.连接wifi
            sprintf(buf1,"ctrl_interface=/var/run/wpa_supplicant\nap_scan=1\nnetwork={\nssid=\"%s\"\nkey_mgmt=WPA-PSK\npsk=\"%s\"\n}",wifiname,wifipasswd);
            FILE* fptt;
            printf("fopen start-------------\n");
            if ((fptt = fopen("/userdata/wpa_supplicant.conf", "w")) == NULL)
            {
                printf("fopen error-------------\n");
                perror("fail to read");
                //exit(1);
            }
            
            printf("\n%s\n\n",buf1);
            fputs(buf1,fptt); 
            fclose(fptt);
            system("killall -9 wpa_supplicant && wpa_supplicant -B -i wlan0 -c /userdata/wpa_supplicant.conf");
            memset(connected_wifi,0,50);
            strcpy(connected_wifi,wifiname);
            system("/etc/init.d/S49ntp restart");
            printf("\ntask3结束\n");
        }
    }
    lv_timer_del(task_sw3);
}

