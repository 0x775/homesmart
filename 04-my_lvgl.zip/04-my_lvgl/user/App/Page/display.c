/**tabview
 * @file display.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
#include "../../../lvgl/src/misc/lv_timer.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "lvgl/src/misc/lv_timer.h"
#include <time.h>
#include "date.h"
#define MAX_LINE 1024
lv_obj_t *page_display;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *sw1;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label5;
static lv_obj_t *label6;
static lv_obj_t *label7;
static lv_obj_t *label_date0;
static lv_obj_t *label_date1;
static lv_obj_t *label_date2;
static lv_obj_t *label_date3;
static lv_obj_t *label_date4;
static lv_obj_t *label_date5;
static lv_obj_t *label_date6;
static lv_obj_t *label_date7;
static lv_obj_t *label_date8;
static lv_obj_t *label_date9;
static lv_obj_t *date_img;
static lv_obj_t *label_date;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
bool is_checked_sleep;
bool is_checked_sw;
static lv_obj_t * brightness;
lv_obj_t *slider;
int brightness_flag=0;
int value=45;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static lv_obj_t * slider_label;
static lv_obj_t * slider_label2;
int flag;
int flag_sleep=0;
int flag_sleep1;
extern int sleep_timeout;
extern int stk3332_unlock;
extern lv_timer_t *Unlock_task;
// extern lv_timer_t *task_time;
lv_timer_t *sleep_task;
lv_timer_t *change_task;



extern lv_obj_t *page_sleep;
void task_Unlock(lv_timer_t *task);
void task_cb0(lv_timer_t *task);
int date_flag;
/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);
LV_FONT_DECLARE(font_chs_16);
LV_FONT_DECLARE(font_display_chs_10);
LV_FONT_DECLARE(font_display_chs_6);
LV_IMG_DECLARE(bg_loading1);
void task_sleep(lv_timer_t *task);
void task_change(lv_timer_t *task);
void task_stk3332_unlock(lv_timer_t *task);
static void event_handler_sw(lv_event_t *e)
{
  is_checked_sw = lv_obj_has_state(sw, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0

}
static void event_handler_switch(lv_event_t *e)
{
  flag=0;
  is_checked_sleep = lv_obj_has_state(sw1, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
  // lv_obj_add_state(sw1, LV_STATE_CHECKED);
  if ( is_checked_sleep)
  {
    //printf("-----pingbao start-----\n");
    sleep_task = lv_timer_create(task_sleep, 100, NULL);
    change_task = lv_timer_create(task_change, 1000, NULL);	
  }
  else
  {
    lv_timer_del(sleep_task);
  }
 
}
void task_sleep(lv_timer_t *task)
{

  //printf("test11 stk3332_unlock-->%d\n",stk3332_unlock);
//printf("is_checke=%d\n",is_checked_sleep);
//if(lv_disp_get_inactive_time(NULL) < 3000 | flag==1) {
if(lv_disp_get_inactive_time(NULL) < 3000) {
  //printf("test4444 stk3332_unlock-->%d\n",stk3332_unlock);
//printf("flag_sleep1111111=%d\n",flag_sleep1);
  }
else if(stk3332_unlock == 0 && lv_disp_get_inactive_time(NULL)>sleep_timeout && date_flag==0)
{
    //printf("test3333\n");
    //screen_sleep();
    system("echo 0 > /sys/devices/platform/backlight/backlight/backlight/brightness");
    flag_sleep1=0;
    flag=1;
    Unlock_task = lv_timer_create(task_Unlock, 100, NULL);
    lv_timer_del(sleep_task);
    lv_timer_del(change_task);

    //printf("del_sleep_task\n");
}
    //lv_timer_del(change_task);
// elif(lv_disp_get_inactive_time(NULL) >=3000){
//     // lv_obj_del(page_sleep);
//     printf("test3333\n");
//     screen_sleep();
//     flag=1;
//     Unlock_task = lv_timer_create(task_Unlock, 100, NULL);
//     lv_timer_del(sleep_task);
//     printf("del_sleep_task\n");
//   }

  // lv_timer_del(sleep_task);
}
static void slider_show_event_cb(lv_event_t * e)
{
   char buf1[400];
   int a;
   brightness = lv_event_get_target(e);
  //  lv_snprintf(buf,sizeof(buf),"%d",(int)lv_slider_get_value(slider));
   printf("value=%d\n",(int)lv_slider_get_value(brightness));
   value=(int)lv_slider_get_value(brightness);
  //  lv_label_set_text(slider_label,buf);
  //  lv_obj_align_to(slider_label,slider,LV_ALIGN_OUT_BOTTOM_MID,-160,-68);
  //  lv_obj_set_style_text_color(slider_label, lv_color_hex(0xffb400), 0);
  //  lv_label_set_text(slider_label2,"%");                 //设置label内容
  //  lv_obj_align_to(slider_label2,slider,LV_ALIGN_OUT_BOTTOM_MID,-135,-68);
  //  lv_obj_set_style_text_color(slider_label2, lv_color_hex(0xffb400), 0);
   sprintf(buf1, "echo %d > /sys/devices/platform/backlight/backlight/backlight/brightness",(int)lv_slider_get_value(brightness));
   system(buf1);
}
static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page_display);
    lv_obj_del(page_display);
}

void display(void){
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page_display = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page_display, 480, 480);
    lv_obj_add_style(page_display, &page_style, 0);
    lv_obj_set_scroll_dir(page_display, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page_display, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page_display);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);
    label = lv_label_create(page_display);
    // lv_label_set_text(label, "显示调节");
    lv_label_set_text(label,language_setting[display_label]);
    // lv_obj_set_size(label, 200, 50);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);
    // lv_obj_set_pos(label, 60, 20);

    label2 = lv_label_create(page_display);
    // lv_label_set_text(label2, "本地开关");
    lv_label_set_text(label2,language_setting[display_label2]);
    LV_FONT_DECLARE(font_display_chs_10);
    lv_obj_set_style_text_font(label2, &font_display_chs_10, 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 10, 70);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);
    sw = lv_switch_create(page_display);
    lv_obj_align(sw, LV_ALIGN_TOP_RIGHT, -10, 70);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw, event_handler_sw, LV_EVENT_RELEASED, NULL);
    label5 = lv_label_create(page_display);
    // lv_label_set_text(label5, "关闭时，本地开关隐藏");
    lv_label_set_text(label5,language_setting[display_label5]);
    LV_FONT_DECLARE(font_display_chs_6);
    lv_obj_set_style_text_font(label5, &font_display_chs_6, 0);
    lv_obj_align(label5, LV_ALIGN_TOP_LEFT, 12, 95);
    lv_obj_set_style_text_color(label5, lv_color_hex(0x999999), 0);

      /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{10, 130}, {440, 130}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_dash_width(&style_line, 10);
    lv_style_set_line_dash_gap(&style_line, 3);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(page_display);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);



    label3 = lv_label_create(page_display);
    // lv_label_set_text(label3, "亮度调节");
    lv_label_set_text(label3,language_setting[display_label3]);
    LV_FONT_DECLARE(font_display_chs_10);
    lv_obj_set_style_text_font(label3, &font_display_chs_10, 0);
    lv_obj_align(label3, LV_ALIGN_TOP_LEFT, 10, 170);
    lv_obj_set_style_text_color(label3, lv_color_white(), 0);


    /*Create a transition*/
    static const lv_style_prop_t props[] = {LV_STYLE_BG_COLOR, 0};
    static lv_style_transition_dsc_t transition_dsc;
    lv_style_transition_dsc_init(&transition_dsc, props, lv_anim_path_linear, 300, 0, NULL);

    lv_style_init(&style_main);
    lv_style_set_bg_opa(&style_main, LV_OPA_COVER);
    lv_style_set_radius(&style_main, LV_RADIUS_CIRCLE);
    lv_style_set_pad_ver(&style_main, -2); /*Makes the indicator larger*/

    lv_style_init(&style_indicator);
    lv_style_set_bg_opa(&style_indicator, LV_OPA_COVER);
    lv_style_set_radius(&style_indicator, LV_RADIUS_CIRCLE);
    lv_style_set_transition(&style_indicator, &transition_dsc);

    lv_style_init(&style_knob);
    lv_style_set_bg_opa(&style_knob, LV_OPA_COVER);
    lv_style_set_border_width(&style_knob, 1);
    lv_style_set_radius(&style_knob, LV_RADIUS_CIRCLE);
    lv_style_set_pad_all(&style_knob, 8); /*Makes the knob larger*/
    lv_style_set_transition(&style_knob, &transition_dsc);

    /*Create a slider and add the style*/
    slider = lv_slider_create(page_display);
    lv_obj_remove_style_all(slider); /*Remove the styles coming from the theme*/
    lv_obj_add_style(slider, &style_main, LV_PART_MAIN);
    lv_obj_set_size(slider, 415, 10);
    lv_obj_add_style(slider, &style_indicator, LV_PART_INDICATOR);
    lv_obj_add_style(slider, &style_knob, LV_PART_KNOB);
    lv_obj_align(slider, LV_ALIGN_TOP_LEFT, 20, 230);
    lv_style_set_bg_color(&style_indicator, lv_color_hex(0xffb400));
    // slider_label = lv_label_create(page);         //创建Label
    // // lv_label_set_text(slider_label,"0%");                 //设置label内容
    lv_obj_add_event_cb(slider,slider_show_event_cb,LV_EVENT_VALUE_CHANGED,NULL); //设置回调显示
    // slider_label2 = lv_label_create(page);         //创建Label
    //lv_label_set_text(slider_label2,"");                 //设置label内容
    //lv_obj_align_to(slider_label,slider,LV_ALIGN_OUT_BOTTOM_MID,-150,-68);
    //lv_obj_set_style_text_color(slider_label, lv_color_hex(0xffb400), 0);
    lv_slider_set_range(slider, 0 , 45);
    lv_slider_set_value(slider, value, LV_ANIM_ON);

    label4 = lv_label_create(page_display);
    // lv_label_set_text(label4, "屏保功能");
    lv_label_set_text(label4,language_setting[display_label4]);
    LV_FONT_DECLARE(font_display_chs_10);
    lv_obj_set_style_text_font(label4, &font_display_chs_10, 0);
    lv_obj_align(label4, LV_ALIGN_TOP_LEFT, 10, 285);
    lv_obj_set_style_text_color(label4, lv_color_white(), 0);
    
    
     sw1 = lv_switch_create(page_display);
    lv_obj_align(sw1, LV_ALIGN_TOP_RIGHT, -10, 285);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw1, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw1, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw1, event_handler_switch, LV_EVENT_RELEASED, NULL);
    if (is_checked_sw)
    {
      lv_obj_add_state(sw, LV_STATE_CHECKED);
    }
    else
    {
      lv_obj_add_state(sw, LV_STATE_DEFAULT);
    }

    if (is_checked_sleep)
    {
      lv_obj_add_state(sw1, LV_STATE_CHECKED);
    //sleep_task = lv_timer_create(task_sleep, 100, NULL);
    //change_task = lv_timer_create(task_change, 1000, NULL);
    //lv_timer_create(task_stk3332_unlock,1000,NULL);
    }
    else
    {
      lv_obj_add_state(sw1, LV_STATE_DEFAULT);
    }
   
}

