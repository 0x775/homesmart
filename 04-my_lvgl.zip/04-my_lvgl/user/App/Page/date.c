/**tabview
 * @file date.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
#include "../../../lvgl/src/misc/lv_timer.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include <stdio.h>
#include "date.h"
#include <stdlib.h>
#include <unistd.h>
#define MAX_LINE 1024
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label5;
static lv_obj_t *label6;
static lv_obj_t *label7;
static lv_obj_t *label8;
static lv_obj_t *label9_1;
static lv_obj_t *label9_2;
static lv_obj_t *label9_3;
static lv_obj_t *label10_1;
static lv_obj_t *label10_2;
static lv_obj_t *label10_3;
static lv_obj_t *label10_4;
static lv_obj_t *label10_5;
static lv_obj_t *label10_6;
int label9_flag=0;
int setting_time_hour=0;
int setting_time_min=0;
int setting_date_year=2022;
int setting_date_mon=06;
int setting_date_day=29;
int setting_language=0;
static lv_obj_t *label10;
static lv_obj_t *label_date0;
static lv_obj_t *label_date1;
static lv_obj_t *label_date2;
static lv_obj_t *label_date3;
static lv_obj_t *label_date4;
static lv_obj_t *label_date5;
static lv_obj_t *label_date6;
static lv_obj_t *label_date7;
static lv_obj_t *label_date8;
static lv_obj_t *label_date9;
static lv_obj_t *date_img;
static lv_obj_t *label_date;
static lv_obj_t *bg;
static lv_obj_t *date_btn;
static lv_obj_t *time_btn;
static lv_obj_t *return_btn1;
bool is_checked=1;
int date_flag=0;
lv_obj_t* time_roller1;
lv_obj_t* time_roller2;
lv_obj_t* date_roller1;
lv_obj_t* date_roller2;
lv_obj_t* date_roller3;
lv_obj_t *language_roller;
// lv_obj_t *label_scenes_mainwindow;
// lv_obj_t *label_devices_mainwindow;
lv_obj_t *label_theme1;
lv_obj_t *label_theme2;
lv_obj_t *label_lamp1;
lv_obj_t *label_lamp22;
lv_obj_t *label_lamp33;
lv_obj_t *label_door;
lv_obj_t *label_AC;
lv_obj_t *label_infrared;
lv_obj_t *label_float;
lv_obj_t *label_curtain;
lv_obj_t *label_wind;
int len=65;
char language_setting[100][256];
char language_Chinese[100][256]={"网络设置","语音控制与音量","语言与日期","设备与系统","语音响应","显示调节","设置","设备","场景","主题","吸顶灯1","吸顶灯2","吸顶灯3","门磁","空调","红外感应","地暖","窗帘","新风","主题1","主题2"
,"连接无线网络","选取附近的WLAN","连接的WLAN","语音控制与音量","语音状态","已启动","语音控制","静音勿扰","音量","开启后，可用语音控制设备","语言与日期","本地开关","中文","自动同步日期与时间","手动设置日期","手动设置时间","显示调节","本地开关","亮度调节"
,"屏保功能","关闭时，本地开关隐藏","设备与系统","SN","系统升级","设备重启","恢复出厂设置","是否确定恢复出厂设置并重启?","是否确定重启设备?","取消","确定","密码错误，连接失败。","知道了","选择添加类型","场景","设备开关","添加场景","您可以选择场景添加到主屏","添加设备开关","您可以选择设备添加到主屏"
,"年","月","日","手动设置语言","时","分"};
char language_English[100][256]={"Network settings","Voice control with volume","Language and Date","Equipment and Systems","Voice response","Display adjustment","set","equipment","scenes","style","ceiling light one",
"ceiling light two","ceiling light three","door sensor","air conditioner","infrared induction","underfloor heating","curtain","new trend","style one","style two","wireless network","Select a nearby WLAN","Connection of the WLAN"
,"Voice control with volume","voice status","Started","Voice control","silent mode","volume","Voice Controlled Devices","Language and Date","Local switch","English","Auto-Sync","Set date manually","Set time manually"
,"Display adjustment","Local switch","Brightness adjustment","Screen saver","local switch is hidden","Equipment and system","SN","System upgrade","Device restart","Factory data reset","Are you sure you to restart?"
,"Are you sure?","cancel","sure","Connection failed","know","Select add Type","scene","Equipment","Add a scene","You can select scenes to add to the screen","Add device switch","You can select devices to add to the screen"
,"year","mon","day","setting language","hour","min"};
char language_Ebrima[100][256]={"Configuración de red","control de voz y volumen","idioma y fecha ","dispositivo y sistema ","respuesta de voz ","Ajustes de pantalla ","ajustes","dispositivos","escenas","temas","Lámpara de techo 1"
,"lámpara de techo 2","lámpara de techo 3","Puerta magnética ","aire acondicionado","sensor infrarrojo ","calefacción por suelo radiante","cortinas","aire fresco","tema1","tema 2"
,"conectar a una red inalámbrica ","seleccionar una WLAN cercana "," una WLAN conectada ","Control de voz y volumen "," estado de voz "," activado "," control de voz "," silencio no molesta "," volumen ","Después de la apertura,dispositivo de control de voz disponible"
,"idioma y fecha ","interruptor local","chino","Sincronización automática","fecha y hora", "configurar manualmente la fecha", "configurar manualmente el tiempo", "regular", "interruptor locales","brillo regular"
,"salvapantallas", "al cierre del interruptor, oculta ","dispositivos y sistemas", "SN", "actualización del sistema", "reiniciar el dispositivo", "restaurar la configuración de fábrica", "si restaurar la configuración de fábrica y reiniciar.","¿Está seguro de reiniciar el dispositivo?" 
,"cancelar","ok ","contraseña incorrecta, conexión fallida ","se seleccione agregar tipo", "escena", "dispositivo interruptor", "añadir escenarios", "escena puede optar por añadir a pantalla de inicio", "agregar dispositivo interruptor", "equipo puede optar por añadir a pantalla de inicio" 
,"año","mes"," día","configuración manual de idioma","hora","minuto"};

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
LV_IMG_DECLARE(icon_next_white);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);
LV_FONT_DECLARE(font_chs_10);
LV_FONT_DECLARE(font_network_ebrima_16);
lv_obj_t *label_wifi_mainwindow;
lv_obj_t *label_sound_mainwindow;
lv_obj_t *label_date_mainwindow;
lv_obj_t *label_system_mainwindow;
lv_obj_t *label_response_mainwindow;
lv_obj_t *label_display_mainwindow;
lv_obj_t *label_set;
lv_obj_t *label_equipment;
lv_obj_t *label_scenes;
lv_obj_t *label_style;
lv_obj_t *tab_btns;
// lv_obj_t *label_type;
lv_obj_t *type_btn;
static void event_handler_switch(lv_event_t *e)
{
   is_checked=lv_obj_has_state(sw, LV_STATE_CHECKED); 
   if (is_checked)
   {
    system("/etc/init.d/S49ntp start");
   }
   else
   {
    system("/etc/init.d/S49ntp stop");
    char buf_time[100];
    sprintf(buf_time,"date -s \"%04d-%02d-%02d %02d:%02d\"",setting_date_year,setting_date_mon,setting_date_day,setting_time_hour,setting_time_min);
	usleep(10000);
    system(buf_time);
   }
   
}
static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}
static void event_handler_year(lv_event_t *e)
{
        char buf[32];
        lv_roller_get_selected_str(date_roller1, buf, sizeof(buf));
        sscanf(buf,"%04d",&setting_date_year);
}
static void event_handler_mon(lv_event_t *e)
{
        char buf[32];
        lv_roller_get_selected_str(date_roller2, buf, sizeof(buf));
        sscanf(buf,"%02d",&setting_date_mon);
        if (setting_date_mon==4 || setting_date_mon==6 || setting_date_mon==9 || setting_date_mon==11)
        {
           lv_roller_set_options(date_roller3,
		"01\n"
		"02\n"
		"03\n"
		"04\n"
		"05\n"
		"06\n"
		"07\n"
		"08\n"
		"09\n"
		"10\n"
		"11\n"
        "12\n"
        "13\n"
        "14\n"
        "15\n"
        "16\n"
        "17\n"
        "18\n"
        "19\n"
        "20\n"
        "21\n"
        "22\n"
        "23\n"
        "24\n"
        "25\n"
        "26\n"
        "27\n"
        "28\n"
        "29\n"
		"30",
		LV_ROLLER_MODE_NORMAL);
        }else if (setting_date_mon==1 || setting_date_mon==3 || setting_date_mon==5 || setting_date_mon==7 || setting_date_mon==8 || setting_date_mon==10 || setting_date_mon==12 )
        {
            lv_roller_set_options(date_roller3,
		"01\n"
		"02\n"
		"03\n"
		"04\n"
		"05\n"
		"06\n"
		"07\n"
		"08\n"
		"09\n"
		"10\n"
		"11\n"
        "12\n"
        "13\n"
        "14\n"
        "15\n"
        "16\n"
        "17\n"
        "18\n"
        "19\n"
        "20\n"
        "21\n"
        "22\n"
        "23\n"
        "24\n"
        "25\n"
        "26\n"
        "27\n"
        "28\n"
        "29\n"
        "30\n"
		"31",
		LV_ROLLER_MODE_NORMAL);
        }else if (setting_date_mon==2 && setting_date_year%4!=0)
        {
            lv_roller_set_options(date_roller3,
		"01\n"
		"02\n"
		"03\n"
		"04\n"
		"05\n"
		"06\n"
		"07\n"
		"08\n"
		"09\n"
		"10\n"
		"11\n"
        "12\n"
        "13\n"
        "14\n"
        "15\n"
        "16\n"
        "17\n"
        "18\n"
        "19\n"
        "20\n"
        "21\n"
        "22\n"
        "23\n"
        "24\n"
        "25\n"
        "26\n"
        "27\n"
		"28",
		LV_ROLLER_MODE_NORMAL);
        }else if (setting_date_mon==2 && setting_date_year%4==0)
        {
            lv_roller_set_options(date_roller3,
		"01\n"
		"02\n"
		"03\n"
		"04\n"
		"05\n"
		"06\n"
		"07\n"
		"08\n"
		"09\n"
		"10\n"
		"11\n"
        "12\n"
        "13\n"
        "14\n"
        "15\n"
        "16\n"
        "17\n"
        "18\n"
        "19\n"
        "20\n"
        "21\n"
        "22\n"
        "23\n"
        "24\n"
        "25\n"
        "26\n"
        "27\n"
        "28\n"
		"29",
		LV_ROLLER_MODE_NORMAL);
        }
        
        
}
static void event_handler_day(lv_event_t *e)
{
        char buf[32];
        lv_roller_get_selected_str(date_roller3, buf, sizeof(buf));
        sscanf(buf,"%02d",&setting_date_day);
}
static void event_handler_hour(lv_event_t *e)
{
        char buf[32];
        lv_roller_get_selected_str(time_roller1, buf, sizeof(buf));
        // setting_time_hour=atoi(buf);
        sscanf(buf,"%02d",&setting_time_hour);
        printf("Selected hour: %s\n", buf);
        printf("Selected hour: %d\n", setting_time_hour);
}
static void event_handler_min(lv_event_t *e)
{
        char buf[32];
        lv_roller_get_selected_str(time_roller2, buf, sizeof(buf));
        // setting_time_hour=atoi(buf);
        sscanf(buf,"%02d",&setting_time_min);
        printf("Selected hour: %s\n", buf);
        printf("Selected hour: %d\n", setting_time_min);
}
static void event_handler_set_language(lv_event_t *e)
{
        char buf[32];
        lv_roller_get_selected_str(language_roller, buf, sizeof(buf));
        printf("Selected language: %s\n", buf);
        // sscanf(buf,"%02d",&setting_language);
        if(strcmp(buf,"中文")==0){
            setting_language=0;
        }else if (strcmp(buf,"English")==0)
        {
            setting_language=1;
        }else if (strcmp(buf,"Ebrima")==0)
        {
            setting_language=2;
        }
        lv_label_set_text(label3, buf);
        printf("Selected language: %d\n", setting_language);

}
static void event_handler_close(lv_event_t *e)
{
    lv_obj_clean(bg);
    lv_obj_del(bg);
}
static void event_handler_close_language(lv_event_t *e)
{
    setting_language=0;
    lv_obj_clean(bg);
    lv_obj_del(bg);
}
static void event_handler_ready1(lv_event_t *e)
{
    date_flag=1;
    char buf[32],buf1[32],buf2[32];
     //year
    sprintf(buf, "%04d", setting_date_year);
    printf("%s\n",buf);
    lv_label_set_text(label10_1, buf);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label10_1, &font_chs_10, 0);
    lv_obj_align(label10_1, LV_ALIGN_TOP_LEFT, 270, 215);
    lv_obj_set_style_text_color(label10_1, lv_color_white(), 0);

    // lv_label_set_text(label10_2, "年");
    LV_FONT_DECLARE(font_date_chs_10);
    lv_obj_set_style_text_font(label10_2, &font_date_chs_10, 0);
    lv_obj_align(label10_2, LV_ALIGN_TOP_LEFT, 312, 209);
    lv_obj_set_style_text_color(label10_2, lv_color_white(), 0);
    //mon
    sprintf(buf1, "%02d", setting_date_mon);
    lv_label_set_text(label10_3, buf1);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label10_3, &font_chs_10, 0);
    lv_obj_align(label10_3, LV_ALIGN_TOP_LEFT, 330, 215);
    lv_obj_set_style_text_color(label10_3, lv_color_white(), 0);
    //月
    // lv_label_set_text(label10_4, "月");
    LV_FONT_DECLARE(font_date_chs_10);
    lv_obj_set_style_text_font(label10_4, &font_date_chs_10, 0);
    lv_obj_align(label10_4, LV_ALIGN_TOP_LEFT, 353, 209);
    lv_obj_set_style_text_color(label10_4, lv_color_white(), 0);
    //day
    sprintf(buf2, "%02d", setting_date_day);
    lv_label_set_text(label10_5, buf2);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label10_5, &font_chs_10, 0);
    lv_obj_align(label10_5, LV_ALIGN_TOP_LEFT, 370, 215);
    lv_obj_set_style_text_color(label10_5, lv_color_white(), 0);
    //日
    // lv_label_set_text(label10_6, "日");
    LV_FONT_DECLARE(font_date_chs_10);
    lv_obj_set_style_text_font(label10_6, &font_date_chs_10, 0);
    lv_obj_align(label10_6, LV_ALIGN_TOP_LEFT, 390, 209);
    lv_obj_set_style_text_color(label10_6, lv_color_white(), 0);
     if(setting_language==0){
    lv_label_set_text(label10_2, "年"); 
    lv_label_set_text(label10_4, "月");
    lv_label_set_text(label10_6, "日");
    }else if (setting_language==1)
    {
    lv_label_set_text(label10_2, "/"); 
    lv_label_set_text(label10_4, "/");
    lv_label_set_text(label10_6, "/");
    }else if (setting_language==2)
    {
    lv_label_set_text(label10_2, "/"); 
    lv_label_set_text(label10_4, "/");
    lv_label_set_text(label10_6, "/");
    }

    lv_obj_clean(bg);
    lv_obj_del(bg);
    char buf_time[100];
    sprintf(buf_time,"date -s %04d-%02d-%02d",setting_date_year,setting_date_mon,setting_date_day);
    system(buf_time);
	usleep(1000);
    date_flag=0;
}
static void event_handler_ready2(lv_event_t *e)
{
    date_flag=1;
    char buf[32],buf1[32];
    //hour
    // label9_1 = lv_label_create(page);
    sprintf(buf, "%02d", setting_time_hour);
    printf("%s\n",buf);
    lv_label_set_text(label9_1, buf);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label9_1, &font_chs_10, 0);
    lv_obj_align(label9_1, LV_ALIGN_TOP_LEFT, 355, 268);
    lv_obj_set_style_text_color(label9_1, lv_color_white(), 0);
    lv_obj_clean(bg);
    lv_obj_del(bg);
    // //:
    // label9_2 = lv_label_create(page);
    lv_label_set_text(label9_2, ":");
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label9_2, &font_chs_10, 0);
    lv_obj_align(label9_2, LV_ALIGN_TOP_LEFT, 375, 266);
    lv_obj_set_style_text_color(label9_2, lv_color_white(), 0);
    //min
    // label9_3= lv_label_create(page);
    sprintf(buf1, "%02d", setting_time_min);
    lv_label_set_text(label9_3, buf1);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label9_3, &font_chs_10, 0);
    lv_obj_align(label9_3, LV_ALIGN_TOP_LEFT, 385, 268);
    lv_obj_set_style_text_color(label9_3, lv_color_white(), 0);
    char buf_time[100];
    sprintf(buf_time,"date -s %d:%d",setting_time_hour,setting_time_min);
    system(buf_time);
    usleep(1000);
    date_flag=0;
}
static void event_handler_ready_language(lv_event_t *e)
{
    switch (setting_language)
    {
    case 0:
        for (size_t i = 0; i <=len; )
        {
            strcpy(language_setting[i],language_Chinese[i]); 
            printf("language_setting=%s\n",language_setting[i]);
            i++;
            printf("i=%d",i);
        }
        lv_label_set_text(label_wifi_mainwindow,language_setting[mainwindow_label_wifi]);
        lv_label_set_text(label_sound_mainwindow,language_setting[mainwindow_label_sound]);
        lv_label_set_text(label_date_mainwindow,language_setting[mainwindow_label_date]);
        lv_label_set_text(label_system_mainwindow,language_setting[mainwindow_label_system]);
        lv_label_set_text(label_response_mainwindow,language_setting[mainwindow_label_response]);
        lv_label_set_text(label_display_mainwindow,language_setting[mainwindow_label_display]);
        lv_label_set_text(label_set, language_setting[mainwindow_label_set]);
        lv_obj_align_to(label_set, tab_btns, LV_ALIGN_LEFT_MID, 40, 35);
        lv_label_set_text(label_equipment,language_setting[mainwindow_label_equipment]);  
        lv_obj_align_to(label_equipment, tab_btns, LV_ALIGN_LEFT_MID, 161, 35);
        lv_label_set_text(label_scenes, language_setting[mainwindow_label_scenes]);
        lv_obj_align_to(label_scenes, tab_btns, LV_ALIGN_LEFT_MID, 283, 35);
        lv_label_set_text(label_style, language_setting[mainwindow_label_style]);
        lv_obj_align_to(label_style, tab_btns, LV_ALIGN_LEFT_MID, 402, 35);
        lv_label_set_text(label_lamp1,language_setting[mainwindow_label_lamp1]);
        lv_label_set_text(label_lamp22, language_setting[mainwindow_label_lamp22]);
        lv_label_set_text(label_lamp33, language_setting[mainwindow_label_lamp33]);
        lv_label_set_text(label_door, language_setting[mainwindow_label_door]);
        lv_label_set_text(label_AC, language_setting[mainwindow_label_AC]);
        lv_label_set_text(label_infrared, language_setting[mainwindow_label_infrared]);
        lv_label_set_text(label_float, language_setting[mainwindow_label_float]);
        lv_label_set_text(label_curtain, language_setting[mainwindow_label_curtain]);
        lv_label_set_text(label_wind, language_setting[mainwindow_label_wind]);
        lv_label_set_text(label_theme1, language_setting[mainwindow_label_theme1]);
        lv_label_set_text(label_theme2, language_setting[mainwindow_label_theme2]);
        //date
        lv_label_set_text(label, language_setting[date_label]);
        lv_label_set_text(label2, language_setting[date_label2]);
        lv_label_set_text(label3, language_setting[date_label3]);
        lv_label_set_text(label4, language_setting[date_label4]);
        lv_label_set_text(label5, language_setting[date_label5]);
        lv_label_set_text(label6, language_setting[date_label6]);
        // lv_label_set_text(label3_wifi, "连接的WLAN");
        // lv_label_set_text(label4_wifi, "选取附近的WLAN");
        // lv_label_set_text(label, "连接无线网络");
        // lv_label_set_text(label_voice, "语音控制与音量");
        // lv_label_set_text(label2_voice, "语音状态");
        // lv_label_set_text(label3_voice, "已启动");
        // lv_label_set_text(label4_voice,"语音控制");
        // lv_label_set_text(label7_voice, "开启后，可用语音控制设备");
        // lv_label_set_text(label5_voice, "静音勿扰");
        // lv_label_set_text(label6_voice, "音量");
        // strcpy(language_setting,language_Chinese);
        // lv_label_set_text(label_wifi_mainwindow, "网络设置");
        // lv_label_set_text(label_sound_mainwindow, "语音控制与音量");
        // lv_label_set_text(label_date_mainwindow, "语言与日期");
        // lv_label_set_text(label_system_mainwindow, "设备与系统");
        // lv_label_set_text(label_response_mainwindow, "语音响应");
        // lv_label_set_text(label_display_mainwindow, "显示调节");
        // lv_label_set_text(label_set, "设置");
        // lv_obj_align_to(label_set, tab_btns, LV_ALIGN_LEFT_MID, 40, 35);
        // lv_label_set_text(label_equipment, "设备");  
        // lv_obj_align_to(label_equipment, tab_btns, LV_ALIGN_LEFT_MID, 161, 35);
        // lv_label_set_text(label_scenes, "场景");
        // lv_obj_align_to(label_scenes, tab_btns, LV_ALIGN_LEFT_MID, 283, 35);
        // lv_label_set_text(label_style, "主题");
        // lv_obj_align_to(label_style, tab_btns, LV_ALIGN_LEFT_MID, 402, 35);
        // // lv_label_set_text(label_type, "选择添加类型");
        // // lv_label_set_text(label_scenes_mainwindow, "场景");
        // // lv_label_set_text(label_devices_mainwindow, "设备开关");
        // lv_label_set_text(label_lamp1, "吸顶灯1");
        // lv_label_set_text(label_lamp22, "吸顶灯2");
        // lv_label_set_text(label_lamp33, "吸顶灯3");
        // lv_label_set_text(label_door, "门磁");
        // lv_label_set_text(label_AC, "空调");
        // lv_label_set_text(label_infrared, "红外感应");
        // lv_label_set_text(label_float, "地暖");
        // lv_label_set_text(label_curtain, "窗帘");
        // lv_label_set_text(label_wind, "新风");
        // lv_label_set_text(label_theme1, "主题1");
        // lv_label_set_text(label_theme2, "主题2");
        // // lv_label_set_text(label3_wifi, "连接的WLAN");
        // // lv_label_set_text(label4_wifi, "选取附近的WLAN");
        // // lv_label_set_text(label, "连接无线网络");
        // // lv_label_set_text(label_voice, "语音控制与音量");
        // // lv_label_set_text(label2_voice, "语音状态");
        // // lv_label_set_text(label3_voice, "已启动");
        // // lv_label_set_text(label4_voice,"语音控制");
        // // lv_label_set_text(label7_voice, "开启后，可用语音控制设备");
        // // lv_label_set_text(label5_voice, "静音勿扰");
        // // lv_label_set_text(label6_voice, "音量");
        break;
    case 1:
        for (size_t i = 0; i <= len; )
        {
            strcpy(language_setting[i],language_English[i]); 
            printf("language_setting=%s\n",language_setting[i]);
            i++;
        }
        lv_label_set_text(label_wifi_mainwindow,language_setting[mainwindow_label_wifi]);
        lv_label_set_text(label_sound_mainwindow,language_setting[mainwindow_label_sound]);
        lv_label_set_text(label_date_mainwindow,language_setting[mainwindow_label_date]);
        lv_label_set_text(label_system_mainwindow,language_setting[mainwindow_label_system]);
        lv_label_set_text(label_response_mainwindow,language_setting[mainwindow_label_response]);
        lv_label_set_text(label_display_mainwindow,language_setting[mainwindow_label_display]);
        lv_label_set_text(label_set, language_setting[mainwindow_label_set]);
        lv_obj_align_to(label_set, tab_btns, LV_ALIGN_LEFT_MID, 42, 35);
        lv_label_set_text(label_equipment,language_setting[mainwindow_label_equipment]);  
        lv_obj_align_to(label_equipment, tab_btns, LV_ALIGN_LEFT_MID, 142, 35);
        lv_label_set_text(label_scenes, language_setting[mainwindow_label_scenes]);
        lv_obj_align_to(label_scenes, tab_btns, LV_ALIGN_LEFT_MID, 273, 35);
        lv_label_set_text(label_style, language_setting[mainwindow_label_style]);
        lv_obj_align_to(label_style, tab_btns, LV_ALIGN_LEFT_MID, 398, 35);
        lv_label_set_text(label_lamp1,language_setting[mainwindow_label_lamp1]);
        lv_label_set_text(label_lamp22, language_setting[mainwindow_label_lamp22]);
        lv_label_set_text(label_lamp33, language_setting[mainwindow_label_lamp33]);
        lv_label_set_text(label_door, language_setting[mainwindow_label_door]);
        lv_label_set_text(label_AC, language_setting[mainwindow_label_AC]);
        lv_label_set_text(label_infrared, language_setting[mainwindow_label_infrared]);
        lv_label_set_text(label_float, language_setting[mainwindow_label_float]);
        lv_label_set_text(label_curtain, language_setting[mainwindow_label_curtain]);
        lv_label_set_text(label_wind, language_setting[mainwindow_label_wind]);
        lv_label_set_text(label_theme1, language_setting[mainwindow_label_theme1]);
        lv_label_set_text(label_theme2, language_setting[mainwindow_label_theme2]);
        //date
        lv_label_set_text(label, language_setting[date_label]);
        lv_label_set_text(label2, language_setting[date_label2]);
        lv_label_set_text(label3, language_setting[date_label3]);
        lv_label_set_text(label4, language_setting[date_label4]);
        lv_label_set_text(label5, language_setting[date_label5]);
        lv_label_set_text(label6, language_setting[date_label6]);
        // strcpy(language_setting,language_English);
        // lv_label_set_text(label_wifi_mainwindow, "Network settings");
        // lv_label_set_text(label_sound_mainwindow, "Voice control with volume");
        // lv_label_set_text(label_date_mainwindow, "Language and Date");
        // lv_label_set_text(label_system_mainwindow, "Equipment and Systems");
        // lv_label_set_text(label_response_mainwindow, "Voice response");
        // lv_label_set_text(label_display_mainwindow, "Display adjustment");
        // lv_label_set_text(label_set, "set");
        // lv_obj_align_to(label_set, tab_btns, LV_ALIGN_LEFT_MID, 42, 35);
        // lv_label_set_text(label_equipment, "equipment");  
        // lv_obj_align_to(label_equipment, tab_btns, LV_ALIGN_LEFT_MID, 142, 35); 
        // lv_label_set_text(label_scenes, "scenes");
        // lv_obj_align_to(label_scenes, tab_btns, LV_ALIGN_LEFT_MID, 273, 35);
        // lv_label_set_text(label_style, "style");
        // lv_obj_align_to(label_style, tab_btns, LV_ALIGN_LEFT_MID, 398, 35);
        // // lv_label_set_text(label_type, "1");
        // // lv_label_set_text(label_scenes_mainwindow, "scenes");
        // // lv_label_set_text(label_devices_mainwindow, "devices");
        // lv_label_set_text(label_lamp1, "ceiling light one");
        // lv_label_set_text(label_lamp22, "ceiling light two");
        // lv_label_set_text(label_lamp33, "ceiling light three");
        // lv_label_set_text(label_door, "door sensor");
        // lv_label_set_text(label_AC, "air conditioner");
        // lv_label_set_text(label_infrared, "infrared induction");
        // lv_label_set_text(label_float, "underfloor heating");
        // lv_label_set_text(label_curtain, "curtain");
        // lv_label_set_text(label_wind, "new trend");
        // lv_label_set_text(label_theme1, "style one");
        // lv_label_set_text(label_theme2, "style two");
        // // lv_label_set_text(label3_wifi, "Connection of the WLAN");
        // // lv_label_set_text(label4_wifi, "Select a nearby WLAN ");
        // // lv_label_set_text(label_wifi, "Connect to a wireless network");
        // // lv_label_set_text(label_voice, "Voice control with volume");
        // // lv_label_set_text(label2_voice, "voice status");
        // // lv_label_set_text(label3_voice, "Started");
        // // lv_label_set_text(label4_voice, "Voice control");
        // // lv_label_set_text(label7_voice, "Voice Controlled Devices");
        // // lv_label_set_text(label5_voice, "silent mode");
        // // lv_label_set_text(label6_voice, "volume");

        break;
    case 2:
            for (size_t i = 0; i <= len; )
        {
            strcpy(language_setting[i],language_Ebrima[i]); 
            printf("language_setting=%s\n",language_setting[i]);
            i++;
        }
        lv_label_set_text(label_wifi_mainwindow,language_setting[mainwindow_label_wifi]);
        lv_label_set_text(label_sound_mainwindow,language_setting[mainwindow_label_sound]);
        lv_label_set_text(label_date_mainwindow,language_setting[mainwindow_label_date]);
        lv_label_set_text(label_system_mainwindow,language_setting[mainwindow_label_system]);
        lv_label_set_text(label_response_mainwindow,language_setting[mainwindow_label_response]);
        lv_label_set_text(label_display_mainwindow,language_setting[mainwindow_label_display]);
        lv_label_set_text(label_set, language_setting[mainwindow_label_set]);
        lv_obj_align_to(label_set, tab_btns, LV_ALIGN_LEFT_MID, 28, 35);
        lv_label_set_text(label_equipment,language_setting[mainwindow_label_equipment]);  
        lv_obj_align_to(label_equipment, tab_btns, LV_ALIGN_LEFT_MID, 133, 35);
        lv_label_set_text(label_scenes, language_setting[mainwindow_label_scenes]);
        lv_obj_align_to(label_scenes, tab_btns, LV_ALIGN_LEFT_MID, 270, 35);
        lv_label_set_text(label_style, language_setting[mainwindow_label_style]);
        lv_obj_align_to(label_style, tab_btns, LV_ALIGN_LEFT_MID, 398, 35);
        lv_label_set_text(label_lamp1,language_setting[mainwindow_label_lamp1]);
        lv_label_set_text(label_lamp22, language_setting[mainwindow_label_lamp22]);
        lv_label_set_text(label_lamp33, language_setting[mainwindow_label_lamp33]);
        lv_label_set_text(label_door, language_setting[mainwindow_label_door]);
        lv_label_set_text(label_AC, language_setting[mainwindow_label_AC]);
        lv_label_set_text(label_infrared, language_setting[mainwindow_label_infrared]);
        lv_label_set_text(label_float, language_setting[mainwindow_label_float]);
        lv_label_set_text(label_curtain, language_setting[mainwindow_label_curtain]);
        lv_label_set_text(label_wind, language_setting[mainwindow_label_wind]);
        lv_label_set_text(label_theme1, language_setting[mainwindow_label_theme1]);
        lv_label_set_text(label_theme2, language_setting[mainwindow_label_theme2]);
        //date
        lv_label_set_text(label, language_setting[date_label]);
        lv_label_set_text(label2, language_setting[date_label2]);
        lv_label_set_text(label3, language_setting[date_label3]);
        lv_label_set_text(label4, language_setting[date_label4]);
        lv_label_set_text(label5, language_setting[date_label5]);
        lv_label_set_text(label6, language_setting[date_label6]);
        break;
    default:
        break;
    }
     if(setting_language==0){
    lv_label_set_text(label10_2, "年"); 
    lv_label_set_text(label10_4, "月");
    lv_label_set_text(label10_6, "日");
    }else if (setting_language==1)
    {
    lv_label_set_text(label10_2, "/"); 
    lv_label_set_text(label10_4, "/");
    lv_label_set_text(label10_6, "/");
    }else if (setting_language==2)
    {
    lv_label_set_text(label10_2, "/"); 
    lv_label_set_text(label10_4, "/");
    lv_label_set_text(label10_6, "/");
    }

    lv_obj_clean(bg);
    lv_obj_del(bg);
}
static void event_handler_language(lv_event_t *e)
{
     msgbox_create_language();
}
static void event_handler_date(lv_event_t *e)
{
     msgbox_create_date();
}
static void event_handler_time(lv_event_t *e)
{
     msgbox_create_time();
}
void msgbox_create_language(void)
{
    bg = lv_obj_create(lv_scr_act());
    lv_obj_set_size(bg, 480, 480);
    lv_obj_add_style(bg, &page_style, 0);
    lv_obj_set_style_bg_opa(bg, LV_OPA_70, 0);
    lv_obj_set_style_bg_color(bg, lv_color_hex(0x000000), 0);

    lv_obj_t *mbox = lv_obj_create(bg);
    lv_obj_clear_flag(mbox, LV_OBJ_FLAG_SCROLLABLE); //禁止滚动
    lv_obj_align(mbox, LV_ALIGN_CENTER, 0, 80);
    lv_obj_add_style(mbox, &style_btn, 0);
    lv_obj_set_size(mbox, 480, 280);

    lv_obj_t *label_mbox = lv_label_create(mbox);
    // lv_label_set_text(label_mbox, "手动设置语言");
    lv_label_set_text(label_mbox,language_setting[date_label_mbox]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_mbox, &font_chs_16, 0);
    lv_obj_align_to(label_mbox, mbox, LV_ALIGN_TOP_MID, 0, 10);
    lv_obj_set_style_text_color(label_mbox, lv_color_white(), 0);
    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 100}, {550, 100}};

    /*Create style*/
    static lv_style_t style_line1;
    lv_style_init(&style_line1);
    lv_style_set_line_color(&style_line1, lv_color_white());
    lv_style_set_line_dash_width(&style_line1, 1);

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(mbox);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line1, 0);
    lv_obj_align_to(line1, mbox, LV_ALIGN_TOP_LEFT, 0, -35);

    LV_FONT_DECLARE(font_settime_chs_12);
    lv_obj_t *btn = lv_btn_create(mbox);
    lv_obj_add_style(btn, &style_btn, 0);
    lv_obj_align_to(btn, mbox, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_add_event_cb(btn, event_handler_close_language, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn = lv_label_create(btn);
    // lv_label_set_text(label_btn, "取消");
    lv_label_set_text(label_btn, language_setting[system_label_btn]);

    lv_obj_set_style_text_font(label_btn, &font_settime_chs_12, 0);
    lv_obj_align_to(label_btn, btn, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_white(), 0);

    lv_obj_t *btn2 = lv_btn_create(mbox);
    lv_obj_add_style(btn2, &style_btn, 0);
    lv_obj_align_to(btn2, mbox, LV_ALIGN_TOP_RIGHT, -45, 0);
    lv_obj_add_event_cb(btn2, event_handler_ready_language, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn2 = lv_label_create(btn2);
    // lv_label_set_text(label_btn2, "确定");
    lv_label_set_text(label_btn2, language_setting[system_label_btn2]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_btn2, &font_settime_chs_12, 0);
    lv_obj_align_to(label_btn2, btn2, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn2, lv_color_hex(0xffb400), 0);

    static lv_style_t roller_style;                       //创建style
    lv_style_init(&roller_style);                         //初始化style

    lv_style_set_radius(&roller_style,5);                 //设置样式的圆角
    lv_style_set_opa(&roller_style,LV_OPA_50);            //设置样式背景透明度
    lv_style_set_bg_color(&roller_style,lv_palette_lighten(LV_PALETTE_BLUE_GREY,1));  //设置样式背景颜色
   
    lv_style_set_border_color(&roller_style,lv_palette_main(LV_PALETTE_BLUE));        //设置样式边框颜色
    lv_style_set_border_width(&roller_style,5);                  //设置样式边框宽度
    lv_style_set_border_opa(&roller_style,LV_OPA_30);            //设置样式边框透明度
    lv_style_set_border_side(&roller_style,LV_BORDER_SIDE_NONE); //设置样式边框显示范围
    
    language_roller = lv_roller_create(mbox);
    lv_roller_set_options(language_roller,
                        "中文\n"
                        "English\n"
                        "Ebrima"
                        ,
                       LV_ROLLER_MODE_NORMAL);
    lv_obj_align(language_roller,LV_ALIGN_CENTER,0, 35);
    // lv_obj_set_style_text_color(roller1,  lv_color_hex(0xffb400), 0);
    lv_obj_set_style_text_color(language_roller,lv_color_white(), 0);
    lv_obj_set_style_bg_color(language_roller, lv_color_hex(0x2f3338), 0);
    lv_roller_set_visible_row_count(language_roller,2);
    lv_obj_add_style(language_roller,&roller_style, 0);
    lv_obj_add_event_cb(language_roller, event_handler_set_language, LV_EVENT_RELEASED, NULL);
    LV_FONT_DECLARE(font_language_chs_12);
    lv_obj_set_style_text_font(language_roller, &font_language_chs_12, 0);
}
void msgbox_create_date(void){
    bg = lv_obj_create(lv_scr_act());
    lv_obj_set_size(bg, 480, 480);
    lv_obj_add_style(bg, &page_style, 0);
    lv_obj_set_style_bg_opa(bg, LV_OPA_70, 0);
    lv_obj_set_style_bg_color(bg, lv_color_hex(0x000000), 0);

    lv_obj_t *mbox = lv_obj_create(bg);
    lv_obj_clear_flag(mbox, LV_OBJ_FLAG_SCROLLABLE); //禁止滚动
    lv_obj_align(mbox, LV_ALIGN_CENTER, 0, 80);
    lv_obj_add_style(mbox, &style_btn, 0);
    lv_obj_set_size(mbox, 480, 280);

    lv_obj_t *label_mbox = lv_label_create(mbox);
    // lv_label_set_text(label_mbox, "手动设置日期");
    lv_label_set_text(label_mbox, language_setting[date_label5]);
    LV_FONT_DECLARE(font_date_chs_16);
    lv_obj_set_style_text_font(label_mbox, &font_date_chs_16, 0);
    lv_obj_align_to(label_mbox, mbox, LV_ALIGN_TOP_MID, 0, 10);
    lv_obj_set_style_text_color(label_mbox, lv_color_white(), 0);
    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 100}, {550, 100}};

    /*Create style*/
    static lv_style_t style_line1;
    lv_style_init(&style_line1);
    lv_style_set_line_color(&style_line1, lv_color_white());
    lv_style_set_line_dash_width(&style_line1, 1);

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(mbox);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line1, 0);
    lv_obj_align_to(line1, mbox, LV_ALIGN_TOP_LEFT, 0, -35);

    LV_FONT_DECLARE(font_settime_chs_12);
    lv_obj_t *btn = lv_btn_create(mbox);
    lv_obj_add_style(btn, &style_btn, 0);
    lv_obj_align_to(btn, mbox, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_add_event_cb(btn, event_handler_close, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn = lv_label_create(btn);
    // lv_label_set_text(label_btn, "取消");
    lv_label_set_text(label_btn, language_setting[system_label_btn]);
    lv_obj_set_style_text_font(label_btn, &font_settime_chs_12, 0);
    lv_obj_align_to(label_btn, btn, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_white(), 0);

    lv_obj_t *btn2 = lv_btn_create(mbox);
    lv_obj_add_style(btn2, &style_btn, 0);
    lv_obj_align_to(btn2, mbox, LV_ALIGN_TOP_RIGHT, -45, 0);
    lv_obj_add_event_cb(btn2, event_handler_ready1, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn2 = lv_label_create(btn2);
    // lv_label_set_text(label_btn2, "确定");
    lv_label_set_text(label_btn2, language_setting[system_label_btn2]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_btn2, &font_settime_chs_12, 0);
    lv_obj_align_to(label_btn2, btn2, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn2, lv_color_hex(0xffb400), 0);

    static lv_style_t roller_style;                       //创建style
    lv_style_init(&roller_style);                         //初始化style

    lv_style_set_radius(&roller_style,5);                 //设置样式的圆角
    lv_style_set_opa(&roller_style,LV_OPA_50);            //设置样式背景透明度
    lv_style_set_bg_color(&roller_style,lv_palette_lighten(LV_PALETTE_BLUE_GREY,1));  //设置样式背景颜色
   
    lv_style_set_border_color(&roller_style,lv_palette_main(LV_PALETTE_BLUE));        //设置样式边框颜色
    lv_style_set_border_width(&roller_style,5);                  //设置样式边框宽度
    lv_style_set_border_opa(&roller_style,LV_OPA_30);            //设置样式边框透明度
    lv_style_set_border_side(&roller_style,LV_BORDER_SIDE_NONE); //设置样式边框显示范围
    
    date_roller1 = lv_roller_create(mbox);
    lv_roller_set_options(date_roller1,
                        "2018\n"
                        "2019\n"
                        "2020\n"
                        "2021\n"
                        "2022\n"
                        "2023\n"
                                                "2018\n"
                        "2019\n"
                        "2020\n"
                        "2021\n"
                        "2022\n"
                        "2023\n"
                        "2024\n"
                        "2025\n"
                        "2026\n"
                        "2027\n"
                        "2028\n"
                        "2029\n"
                        "2030\n"
                        "2031\n"
                        "2032\n"
                        "2033\n"
                        "2034\n"
                        "2035\n"
                        "2036\n"
                        "2037\n"
                        "2038\n"
                        "2039\n"
                        "2040\n"
                        "2041\n"
                        "2042",
                        LV_ROLLER_MODE_NORMAL);
    date_roller2 = lv_roller_create(mbox);
    lv_roller_set_options(date_roller2,
        "01\n"
        "02\n"
        "03\n"
        "04\n"
        "05\n"
        "06\n"
        "07\n"
        "08\n"
        "09\n"
        "10\n"
        "11\n"
        "12",
        LV_ROLLER_MODE_NORMAL);
    date_roller3 = lv_roller_create(mbox);
    lv_roller_set_options(date_roller3,
		"01\n"
		"02\n"
		"03\n"
		"04\n"
		"05\n"
		"06\n"
		"07\n"
		"08\n"
		"09\n"
		"10\n"
		"11\n"
        "12\n"
        "13\n"
        "14\n"
        "15\n"
        "16\n"
        "17\n"
        "18\n"
        "19\n"
        "20\n"
        "21\n"
        "22\n"
        "23\n"
        "24\n"
        "25\n"
        "26\n"
        "17\n"
        "28\n"
        "29\n"
        "30\n"
		"31",
		LV_ROLLER_MODE_NORMAL);
    lv_obj_align(date_roller1,LV_ALIGN_CENTER,-145, 45);
    // lv_obj_set_style_text_color(date_roller1,  lv_color_hex(0xffb400), 0);
    lv_obj_set_style_text_color(date_roller1,  lv_color_white(), 0);
    lv_obj_set_style_bg_color(date_roller1, lv_color_hex(0x2f3338), 0);
    lv_roller_set_visible_row_count(date_roller1,4);
    lv_obj_add_style(date_roller1,&roller_style, 0);
    lv_obj_add_event_cb(date_roller1, event_handler_year, LV_EVENT_CLICKED, NULL);

    lv_obj_align(date_roller2,LV_ALIGN_CENTER,5, 45);
    // lv_obj_set_style_text_color(date_roller2,  lv_color_hex(0xffb400), 0);
    lv_obj_set_style_text_color(date_roller2,  lv_color_white(), 0);
    lv_obj_set_style_bg_color(date_roller2, lv_color_hex(0x2f3338), 0);
    lv_roller_set_visible_row_count(date_roller2,4);
    lv_obj_add_style(date_roller2,&roller_style, 0);  
    lv_obj_add_event_cb(date_roller2, event_handler_mon, LV_EVENT_CLICKED, NULL);

    lv_obj_align(date_roller3,LV_ALIGN_CENTER,125, 45);
    lv_obj_set_style_text_color(date_roller3,  lv_color_white(), 0);
    lv_obj_set_style_bg_color(date_roller3, lv_color_hex(0x2f3338), 0);
    lv_roller_set_visible_row_count(date_roller3,4);
    lv_obj_add_style(date_roller3,&roller_style, 0);  
    lv_obj_add_event_cb(date_roller3, event_handler_day, LV_EVENT_CLICKED, NULL);

    lv_obj_t *label_year = lv_label_create(mbox);
    // lv_label_set_text(label_year, "年"); 
    LV_FONT_DECLARE(font_setdate_chs_12);
    lv_obj_set_style_text_font(label_year, &font_setdate_chs_12, 0);
    lv_obj_set_style_text_color(label_year, lv_color_white(), 0);

    lv_obj_t *label_mon = lv_label_create(mbox);
    // lv_label_set_text(label_mon, "月");
    LV_FONT_DECLARE(font_setdate_chs_12);
    lv_obj_set_style_text_font(label_mon, &font_setdate_chs_12, 0);
    lv_obj_set_style_text_color(label_mon, lv_color_white(), 0);

    lv_obj_t *label_day = lv_label_create(mbox);
    lv_label_set_text(label_year,language_setting[date_label_year]);
    lv_label_set_text(label_mon,language_setting[date_label_mon]);
    lv_label_set_text(label_day,language_setting[date_label_day]);



    LV_FONT_DECLARE(font_setdate_chs_12);
    lv_obj_set_style_text_font(label_day, &font_setdate_chs_12, 0);
    lv_obj_align_to(label_year, date_roller1, LV_ALIGN_BOTTOM_LEFT, 80, -40);
    lv_obj_align_to(label_mon, date_roller2, LV_ALIGN_BOTTOM_LEFT, 65, -40);
    lv_obj_align_to(label_day, date_roller3, LV_ALIGN_BOTTOM_LEFT, 65, -40);
    lv_obj_set_style_text_color(label_day, lv_color_white(), 0);
}
void msgbox_create_time(void)
{
    bg = lv_obj_create(lv_scr_act());
    lv_obj_set_size(bg, 480, 480);
    lv_obj_add_style(bg, &page_style, 0);
    lv_obj_set_style_bg_opa(bg, LV_OPA_70, 0);
    lv_obj_set_style_bg_color(bg, lv_color_hex(0x000000), 0);

    lv_obj_t *mbox = lv_obj_create(bg);
    lv_obj_clear_flag(mbox, LV_OBJ_FLAG_SCROLLABLE); //禁止滚动
    lv_obj_align(mbox, LV_ALIGN_CENTER, 0, 80);
    lv_obj_add_style(mbox, &style_btn, 0);
    lv_obj_set_size(mbox, 480, 280);

    lv_obj_t *label_mbox = lv_label_create(mbox);
    // lv_label_set_text(label_mbox, "手动设置时间");
    lv_label_set_text(label_mbox, language_setting[date_label6]);
    LV_FONT_DECLARE(font_date_chs_16);
    lv_obj_set_style_text_font(label_mbox, &font_date_chs_16, 0);
    lv_obj_align_to(label_mbox, mbox, LV_ALIGN_TOP_MID, 0, 10);
    lv_obj_set_style_text_color(label_mbox, lv_color_white(), 0);
    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 100}, {550, 100}};

    /*Create style*/
    static lv_style_t style_line1;
    lv_style_init(&style_line1);
    lv_style_set_line_color(&style_line1, lv_color_white());
    lv_style_set_line_dash_width(&style_line1, 1);

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(mbox);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line1, 0);
    lv_obj_align_to(line1, mbox, LV_ALIGN_TOP_LEFT, 0, -35);

    LV_FONT_DECLARE(font_settime_chs_12);
    lv_obj_t *btn = lv_btn_create(mbox);
    lv_obj_add_style(btn, &style_btn, 0);
    lv_obj_align_to(btn, mbox, LV_ALIGN_TOP_LEFT, 0, 0);
    lv_obj_add_event_cb(btn, event_handler_close, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn = lv_label_create(btn);
    // lv_label_set_text(label_btn, "取消");
    lv_label_set_text(label_btn, language_setting[system_label_btn]);
    lv_obj_set_style_text_font(label_btn, &font_settime_chs_12, 0);
    lv_obj_align_to(label_btn, btn, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_white(), 0);

    lv_obj_t *btn2 = lv_btn_create(mbox);
    lv_obj_add_style(btn2, &style_btn, 0);
    lv_obj_align_to(btn2, mbox, LV_ALIGN_TOP_RIGHT, -45, 0);
    lv_obj_add_event_cb(btn2, event_handler_ready2, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn2 = lv_label_create(btn2);
    // lv_label_set_text(label_btn2, "确定");
    lv_label_set_text(label_btn2, language_setting[system_label_btn2]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_btn2, &font_settime_chs_12, 0);
    lv_obj_align_to(label_btn2, btn2, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn2, lv_color_hex(0xffb400), 0);

    static lv_style_t roller_style;                       //创建style
    lv_style_init(&roller_style);                         //初始化style

    lv_style_set_radius(&roller_style,5);                 //设置样式的圆角
    lv_style_set_opa(&roller_style,LV_OPA_50);            //设置样式背景透明度
    lv_style_set_bg_color(&roller_style,lv_palette_lighten(LV_PALETTE_BLUE_GREY,1));  //设置样式背景颜色
   
    lv_style_set_border_color(&roller_style,lv_palette_main(LV_PALETTE_BLUE));        //设置样式边框颜色
    lv_style_set_border_width(&roller_style,5);                  //设置样式边框宽度
    lv_style_set_border_opa(&roller_style,LV_OPA_30);            //设置样式边框透明度
    lv_style_set_border_side(&roller_style,LV_BORDER_SIDE_NONE); //设置样式边框显示范围


    
    time_roller1 = lv_roller_create(mbox);
    lv_roller_set_options(time_roller1,
                        "01\n"
                        "02\n"
                        "03\n"
                        "04\n"
                        "05\n"
                        "06\n"
                        "07\n"
                        "08\n"
                        "09\n"
                        "10\n"
                        "11\n"
                        "12\n"
                        "13\n"
                        "14\n"
                        "15\n"
                        "16\n"
                        "17\n"
                        "18\n"
                        "19\n"
                        "20\n"
                        "21\n"
                        "22\n"
                        "23",
                        LV_ROLLER_MODE_NORMAL);
    time_roller2 = lv_roller_create(mbox);
    lv_roller_set_options(time_roller2,
        "01\n"
        "02\n"
        "03\n"
        "04\n"
        "05\n"
        "06\n"
        "07\n"
        "08\n"
        "09\n"
        "10\n"
        "11\n"
        "12\n"
        "13\n"
        "14\n"
        "15\n"
        "16\n"
        "17\n"
        "18\n"
        "19\n"
        "20\n"
        "21\n"
        "22\n"
        "23\n"
        "24\n"
        "25\n"
        "26\n"
        "27\n"
        "28\n"
        "29\n"
        "30\n"
        "31\n"
        "32\n"
        "33\n"
        "34\n"
        "35\n"
        "36\n"
        "37\n"
        "38\n"
        "39\n"
        "40\n"
        "41\n"
        "42\n"
        "43\n"
        "44\n"
        "45\n"
        "46\n"
        "47\n"
        "48\n"
        "49\n"
        "50\n"
        "51\n"
        "52\n"
        "53\n"
        "54\n"
        "55\n"
        "56\n"
        "57\n"
        "58\n"
        "59",
       LV_ROLLER_MODE_NORMAL);
    lv_obj_align(time_roller1,LV_ALIGN_CENTER,-85, 45);
    // lv_obj_set_style_text_color(time_roller1,  lv_color_hex(0xffb400), 0);
    lv_obj_set_style_text_color(time_roller1,  lv_color_white(), 0);
    lv_obj_set_style_bg_color(time_roller1, lv_color_hex(0x2f3338), 0);
    lv_roller_set_visible_row_count(time_roller1,4);
    lv_obj_add_style(time_roller1,&roller_style, 0);
    lv_obj_add_event_cb(time_roller1, event_handler_hour, LV_EVENT_CLICKED, NULL);

    lv_obj_align(time_roller2,LV_ALIGN_CENTER,35, 45);
    // lv_obj_set_style_text_color(time_roller2,  lv_color_hex(0xffb400), 0);
    lv_obj_set_style_text_color(time_roller2,  lv_color_white(), 0);
    lv_obj_set_style_bg_color(time_roller2, lv_color_hex(0x2f3338), 0);
    lv_roller_set_visible_row_count(time_roller2,4);
    lv_obj_add_style(time_roller2,&roller_style, 0);  
    lv_obj_add_event_cb(time_roller2, event_handler_min, LV_EVENT_CLICKED, NULL);

    label7 = lv_label_create(mbox);
    // lv_label_set_text(label7, "时");
    lv_label_set_text(label7,language_setting[date_label7]);
    LV_FONT_DECLARE(font_settime_chs_12);
    lv_obj_set_style_text_font(label7, &font_settime_chs_12, 0);
    lv_obj_align_to(label7, time_roller1, LV_ALIGN_BOTTOM_LEFT, 65, -40);
    lv_obj_set_style_text_color(label7, lv_color_white(), 0);

    label8 = lv_label_create(mbox);
    // lv_label_set_text(label8, "分");
    lv_label_set_text(label7,language_setting[date_label8]);
    LV_FONT_DECLARE(font_settime_chs_12);
    lv_obj_set_style_text_font(label8, &font_settime_chs_12, 0);
    lv_obj_align_to(label8, time_roller2, LV_ALIGN_BOTTOM_LEFT, 65, -40);
    lv_obj_set_style_text_color(label8, lv_color_white(), 0);
  
 }
void date(void){
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);

    label = lv_label_create(page);
    // lv_label_set_text(label, "语言与日期");
    lv_label_set_text(label, language_setting[date_label]);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    label2 = lv_label_create(page);
    // lv_label_set_text(label2, "本地开关");
    lv_label_set_text(label2, language_setting[date_label2]);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label2, &font_chs_10, 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 10, 70);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);


    lv_obj_t *language_btn=lv_btn_create(page);
    lv_obj_add_style(language_btn, &style_btn, 0);
    label3 = lv_label_create(language_btn);
    // lv_label_set_text(label3, "中文");
    lv_label_set_text(label3, language_setting[date_label3]);
    LV_FONT_DECLARE(font_setlanguage_chs_10);
    lv_obj_set_style_text_font(label3, &font_setlanguage_chs_10, 0);
    lv_obj_align(language_btn, LV_ALIGN_TOP_LEFT, 360, 60);
    lv_obj_set_style_text_color(label3, lv_color_white(), 0);
    lv_obj_add_event_cb(language_btn, event_handler_language, LV_EVENT_CLICKED, NULL);
    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{10, 120}, {440, 120}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_dash_width(&style_line, 10);
    lv_style_set_line_dash_gap(&style_line, 3);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(page);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);

    label4 = lv_label_create(page);
    // lv_label_set_text(label4, "自动同步日期与时间");
    lv_label_set_text(label4, language_setting[date_label4]);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label4, &font_chs_10, 0);
    lv_obj_align(label4, LV_ALIGN_TOP_LEFT, 10, 155);
    lv_obj_set_style_text_color(label4, lv_color_white(), 0);
    sw = lv_switch_create(page);
    lv_obj_align(sw, LV_ALIGN_TOP_RIGHT, -10, 155);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw, event_handler_switch, LV_EVENT_RELEASED, NULL);

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);

    label5 = lv_label_create(page);
    // lv_label_set_text(label5, "手动设置日期");
    lv_label_set_text(label5, language_setting[date_label5]);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label5, &font_chs_10, 0);
    lv_obj_align(label5, LV_ALIGN_TOP_LEFT, 10, 210);
    lv_obj_set_style_text_color(label5, lv_color_white(), 0);

    date_btn = lv_btn_create(page);
    lv_obj_add_style(date_btn, &style_btn, 0);
    lv_obj_t *date_img = lv_img_create(date_btn);
    lv_img_set_src(date_img, &icon_next_white); //设置图片源
    lv_obj_align(date_btn, LV_ALIGN_TOP_LEFT,400, 208);
    lv_obj_add_event_cb(date_btn, event_handler_date, LV_EVENT_CLICKED, NULL);


    time_btn = lv_btn_create(page);
    lv_obj_add_style(time_btn, &style_btn, 0);
    lv_obj_t *time_img = lv_img_create(time_btn);
    lv_img_set_src(time_img, &icon_next_white); //设置图片源
    lv_obj_align(time_btn, LV_ALIGN_TOP_LEFT,400, 260);
    lv_obj_add_event_cb(time_btn, event_handler_time, LV_EVENT_CLICKED, NULL);
    
    label6 = lv_label_create(page);
    // lv_label_set_text(label6, "手动设置时间");
    lv_label_set_text(label6, language_setting[date_label6]);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label6, &font_chs_10, 0);
    lv_obj_align(label6, LV_ALIGN_TOP_LEFT, 10, 265);
    lv_obj_set_style_text_color(label6, lv_color_white(), 0);
    char buf[32],buf1[32],buf2[32];
    //year
    label10_1 = lv_label_create(page);
    sprintf(buf, "%02d", setting_date_year);
    printf("%s\n",buf);
    lv_label_set_text(label10_1, buf);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label10_1, &font_chs_10, 0);
    lv_obj_align(label10_1, LV_ALIGN_TOP_LEFT, 270, 215);
    lv_obj_set_style_text_color(label10_1, lv_color_white(), 0);
    // 年
    label10_2 = lv_label_create(page);
    lv_label_set_text(label10_2, "年");
    LV_FONT_DECLARE(font_date_chs_10);
    lv_obj_set_style_text_font(label10_2, &font_date_chs_10, 0);
    lv_obj_align(label10_2, LV_ALIGN_TOP_LEFT, 312, 209);
    lv_obj_set_style_text_color(label10_2, lv_color_white(), 0);
    //mon
    label10_3 = lv_label_create(page);
    sprintf(buf1, "%02d", setting_date_mon);
    lv_label_set_text(label10_3, buf1);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label10_3, &font_chs_10, 0);
    lv_obj_align(label10_3, LV_ALIGN_TOP_LEFT, 330, 215);
    lv_obj_set_style_text_color(label10_3, lv_color_white(), 0);
    //月
    label10_4 = lv_label_create(page);
    lv_label_set_text(label10_4, "月");
    LV_FONT_DECLARE(font_date_chs_10);
    lv_obj_set_style_text_font(label10_4, &font_date_chs_10, 0);
    lv_obj_align(label10_4, LV_ALIGN_TOP_LEFT, 353, 209);
    lv_obj_set_style_text_color(label10_4, lv_color_white(), 0);
    //day
    label10_5 = lv_label_create(page);
    sprintf(buf2, "%02d", setting_date_day);
    lv_label_set_text(label10_5, buf2);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label10_5, &font_chs_10, 0);
    lv_obj_align(label10_5, LV_ALIGN_TOP_LEFT, 370, 215);
    lv_obj_set_style_text_color(label10_5, lv_color_white(), 0);
    //日
    label10_6 = lv_label_create(page);
    lv_label_set_text(label10_6, "日");
    LV_FONT_DECLARE(font_date_chs_10);
    lv_obj_set_style_text_font(label10_6, &font_date_chs_10, 0);
    lv_obj_align(label10_6, LV_ALIGN_TOP_LEFT, 390, 209);
    lv_obj_set_style_text_color(label10_6, lv_color_white(), 0);


    char hour_buf[32],min_buf[32];
    //hour
    label9_1 = lv_label_create(page);
    sprintf(hour_buf, "%02d", setting_time_hour);
    printf("%s\n",hour_buf);
    lv_label_set_text(label9_1, hour_buf);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label9_1, &font_chs_10, 0);
    lv_obj_align(label9_1, LV_ALIGN_TOP_LEFT, 355, 268);
    lv_obj_set_style_text_color(label9_1, lv_color_white(), 0);
    //:
    label9_2 = lv_label_create(page);
    lv_label_set_text(label9_2, ":");
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label9_2, &font_chs_10, 0);
    lv_obj_align(label9_2, LV_ALIGN_TOP_LEFT, 375, 266);
    lv_obj_set_style_text_color(label9_2, lv_color_white(), 0);
    //min
    label9_3= lv_label_create(page);
    sprintf(min_buf, "%02d", setting_time_min);
    lv_label_set_text(label9_3, min_buf);
    LV_FONT_DECLARE(font_chs_10);
    lv_obj_set_style_text_font(label9_3, &font_chs_10, 0);
    lv_obj_align(label9_3, LV_ALIGN_TOP_LEFT, 385, 268);
    lv_obj_set_style_text_color(label9_3, lv_color_white(), 0);
    

    if (is_checked)
    {
      lv_obj_add_state(sw, LV_STATE_CHECKED);
    }
    else
    {
      lv_obj_add_state(sw, LV_STATE_DEFAULT);
    }
 
}
