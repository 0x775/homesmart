/**tabview
 * @file date.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
#include "../../../lvgl/src/misc/lv_timer.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "date.h"

#define MAX_LINE 1024
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw1;
static lv_obj_t *sw2;
static lv_obj_t *panel;
static lv_obj_t *label_voice;
static lv_obj_t *label2_voice;
static lv_obj_t *label3_voice;
static lv_obj_t *label4_voice;
static lv_obj_t *label5_voice;
static lv_obj_t *label6_voice;
static lv_obj_t *label7_voice;
static lv_obj_t *label_date0;
static lv_obj_t *label_date1;
static lv_obj_t *label_date2;
static lv_obj_t *label_date3;
static lv_obj_t *label_date4;
static lv_obj_t *label_date5;
static lv_obj_t *label_date6;
static lv_obj_t *label_date7;
static lv_obj_t *label_date8;
static lv_obj_t *label_date9;
static lv_obj_t *date_img;
static lv_obj_t *label_date;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static bool is_checked;
lv_obj_t *slider;
lv_obj_t *slider_volum;
static lv_style_t style_main;
static lv_style_t style_indicator;
static lv_style_t style_knob;
static lv_obj_t * slider_label;
static lv_obj_t * slider_label2;
bool is_checked_sw1;
bool is_checked_volume;
int volume=99;
char buf_volume[8]="99";
char buf1[100];
/**********************s
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);
LV_FONT_DECLARE(font_chs_16);
LV_FONT_DECLARE(font_voice_chs_10);
LV_FONT_DECLARE(font_voice_chs_6);
LV_IMG_DECLARE(bg_loading1);
static void event_handler_sw1(lv_event_t *e)
{
   is_checked_sw1=lv_obj_has_state(sw1, LV_STATE_CHECKED); 
}
static void event_handler_sw2(lv_event_t *e)
{
   is_checked_volume=lv_obj_has_state(sw2, LV_STATE_CHECKED); 
   if (is_checked_volume)
   {
    //  system("amixer -c 0 set Master Playback Volume 0");
    system("echo 5 > /sys/class/gpio/export");
    system("echo out > /sys/class/gpio/gpio5/direction");
    system("echo 0 > /sys/class/gpio/gpio5/value");

   }else{
    printf("%d",volume);
    char buf[100];
    // sprintf(buf,"amixer -c 0 set Master Playback Volume %d",volume);
    system("echo 5 > /sys/class/gpio/export");
    system("echo out > /sys/class/gpio/gpio5/direction");
    system("echo 1 > /sys/class/gpio/gpio5/value");
    system(buf);
   }
}
static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}

static void slider_event_handler(lv_obj_t* obj, lv_event_t event)
{
    // if (event == LV_EVENT_VALUE_CHANGED) {
        printf("Value: %d\n", lv_slider_get_value(obj));
    // }
}
static void slider_show_event_cb(lv_event_t * e)
{
   
   lv_event_code_t code = lv_event_get_code(e);
   slider_volum = lv_event_get_target(e);
   if(code==LV_EVENT_VALUE_CHANGED) {
   lv_snprintf(buf_volume,sizeof(buf_volume),"%d",(int)lv_slider_get_value(slider_volum));
   lv_label_set_text(slider_label,buf_volume);
   volume=(int)lv_slider_get_value(slider_volum);
   lv_obj_set_style_text_color(slider_label, lv_color_hex(0xffb400), 0);
   lv_label_set_text(slider_label2,"%");                 //设置label内容

   lv_obj_set_style_text_color(slider_label2, lv_color_hex(0xffb400), 0);
   sprintf(buf1, "amixer -c 0 set Master Playback Volume %d",(int)lv_slider_get_value(slider_volum));
   system(buf1);
   //printf("value changed\n");
   } else if(code==LV_EVENT_RELEASED) {
   printf("volumn slide released\n");
        //printf("volumn slide code ----> %d, %d, %d\n",code,LV_EVENT_RELEASED,(int)lv_slider_get_value(slider_volum));
        system("aplay /opt/ding.wav &");
   }
}
void voice(void){
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);
    label_voice = lv_label_create(page);
    lv_label_set_text(label_voice, "语音控制与音量");
    // lv_obj_set_size(label, 200, 50);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_voice, &font_chs_16, 0);
    lv_obj_align_to(label_voice, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label_voice, lv_color_white(), 0);
    // lv_obj_set_pos(label, 60, 20);

    label2_voice = lv_label_create(page);
    lv_label_set_text(label2_voice ,"语音状态");
    LV_FONT_DECLARE(font_voice_chs_10);
    lv_obj_set_style_text_font(label2_voice, &font_voice_chs_10, 0);
    lv_obj_align(label2_voice, LV_ALIGN_TOP_LEFT, 10, 70);
    lv_obj_set_style_text_color(label2_voice, lv_color_white(), 0);
    label3_voice = lv_label_create(page);
    lv_label_set_text(label3_voice, "已启动");
    LV_FONT_DECLARE(font_voice_chs_10);
    lv_obj_set_style_text_font(label3_voice, &font_voice_chs_10, 0);
    lv_obj_align(label3_voice, LV_ALIGN_TOP_LEFT, 375, 70);
    lv_obj_set_style_text_color(label3_voice, lv_color_hex(0xffb400), 0);

    label4_voice = lv_label_create(page);
    lv_label_set_text(label4_voice, "语音控制");
    LV_FONT_DECLARE(font_voice_chs_10);
    lv_obj_set_style_text_font(label4_voice, &font_voice_chs_10, 0);
    lv_obj_align(label4_voice, LV_ALIGN_TOP_LEFT, 10, 120);
    lv_obj_set_style_text_color(label4_voice, lv_color_white(), 0);
    sw1 = lv_switch_create(page);
    lv_obj_align(sw1, LV_ALIGN_TOP_RIGHT, -10, 120);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw1, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw1, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw1, event_handler_sw1, LV_EVENT_RELEASED, NULL);
    label7_voice = lv_label_create(page);
    lv_label_set_text(label7_voice, "开启后，可用语音控制设备");
    LV_FONT_DECLARE(font_voice_chs_6);
    lv_obj_set_style_text_font(label7_voice, &font_voice_chs_6, 0);
    lv_obj_align(label7_voice, LV_ALIGN_TOP_LEFT, 12, 145);
    lv_obj_set_style_text_color(label7_voice, lv_color_hex(0x999999), 0);

    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{10, 180}, {440, 180}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_dash_width(&style_line, 10);
    lv_style_set_line_dash_gap(&style_line, 3);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(page);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);



    label5_voice = lv_label_create(page);
    lv_label_set_text(label5_voice, "静音勿扰");
    LV_FONT_DECLARE(font_voice_chs_10);
    lv_obj_set_style_text_font(label5_voice, &font_voice_chs_10, 0);
    lv_obj_align(label5_voice, LV_ALIGN_TOP_LEFT, 10, 210);
    lv_obj_set_style_text_color(label5_voice, lv_color_white(), 0);
    sw2 = lv_switch_create(page);
    lv_obj_align(sw2, LV_ALIGN_TOP_RIGHT, -10, 210);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw2, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw2, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw2, event_handler_sw2, LV_EVENT_RELEASED, NULL);

    label6_voice = lv_label_create(page);
    lv_label_set_text(label6_voice, "音量");
    LV_FONT_DECLARE(font_voice_chs_10);
    lv_obj_set_style_text_font(label6_voice, &font_voice_chs_10, 0);
    lv_obj_align(label6_voice, LV_ALIGN_TOP_LEFT, 10, 265);
    lv_obj_set_style_text_color(label6_voice, lv_color_white(), 0);

    /*Create a transition*/
    static const lv_style_prop_t props[] = {LV_STYLE_BG_COLOR, 0};
    static lv_style_transition_dsc_t transition_dsc;
    lv_style_transition_dsc_init(&transition_dsc, props, lv_anim_path_linear, 300, 0, NULL);

    lv_style_init(&style_main);
    lv_style_set_bg_opa(&style_main, LV_OPA_COVER);
    lv_style_set_radius(&style_main, LV_RADIUS_CIRCLE);
    lv_style_set_pad_ver(&style_main, -2); /*Makes the indicator larger*/

    lv_style_init(&style_indicator);
    lv_style_set_bg_opa(&style_indicator, LV_OPA_COVER);
    lv_style_set_radius(&style_indicator, LV_RADIUS_CIRCLE);
    lv_style_set_transition(&style_indicator, &transition_dsc);

    lv_style_init(&style_knob);
    lv_style_set_bg_opa(&style_knob, LV_OPA_COVER);
    lv_style_set_border_width(&style_knob, 1);
    lv_style_set_radius(&style_knob, LV_RADIUS_CIRCLE);
    lv_style_set_pad_all(&style_knob, 8); /*Makes the knob larger*/
    lv_style_set_transition(&style_knob, &transition_dsc);

    // lv_style_init(&style_pressed_color);
    // lv_style_set_bg_color(&style_pressed_color, lv_palette_darken(LV_PALETTE_CYAN, 2));

    // lv_obj_add_style(slider, &style_pressed_color, LV_PART_INDICATOR | LV_STATE_PRESSED);
    // lv_obj_add_style(slider, &style_pressed_color, LV_PART_KNOB | LV_STATE_PRESSED);

    /*Create a slider and add the style*/
    slider = lv_slider_create(page);
    // int slider_value = (int)lv_slider_get_value(slider);

    lv_obj_remove_style_all(slider); /*Remove the styles coming from the theme*/
    lv_obj_add_style(slider, &style_main, LV_PART_MAIN);
    lv_obj_set_size(slider, 415, 10);
    lv_obj_add_style(slider, &style_indicator, LV_PART_INDICATOR);
    lv_obj_add_style(slider, &style_knob, LV_PART_KNOB);
    lv_obj_align(slider, LV_ALIGN_TOP_LEFT, 20, 320);
    lv_style_set_bg_color(&style_indicator, lv_color_hex(0xffb400));
    slider_label = lv_label_create(page);         //创建Label
    // lv_label_set_text(slider_label,"0%");                 //设置label内容
    lv_label_set_text(slider_label,buf_volume);
    lv_obj_add_event_cb(slider,slider_show_event_cb,LV_EVENT_ALL,NULL); //设置回调显示
    //lv_obj_add_event_cb(slider,slider_released_event_cb,LV_EVENT_RELEASED,NULL); //设置回调显示
    slider_label2 = lv_label_create(page);         //创建Label
    lv_label_set_text(slider_label2,"%");                 //设置label内容
    lv_obj_align_to(slider_label2,slider,LV_ALIGN_OUT_BOTTOM_MID,-135,-68);
    lv_obj_set_style_text_color(slider_label2, lv_color_hex(0xffb400), 0);
    lv_obj_align_to(slider_label,slider,LV_ALIGN_OUT_BOTTOM_MID,-160,-68);
    lv_obj_set_style_text_color(slider_label, lv_color_hex(0xffb400), 0);
    lv_slider_set_range(slider, 0 , 99);
    lv_slider_set_value(slider, volume, LV_ANIM_ON);

    lv_label_set_text(label_voice, language_setting[voice_label_voice]);
    lv_label_set_text(label2_voice, language_setting[voice_label2_voice]);
    lv_label_set_text(label3_voice,language_setting[voice_label3_voice]);
    lv_label_set_text(label4_voice,language_setting[voice_label4_voice]);
    lv_label_set_text(label7_voice, language_setting[voice_label7_voice]);
    lv_label_set_text(label5_voice, language_setting[voice_label5_voice]);
    lv_label_set_text(label6_voice, language_setting[voice_label6_voice]);
    if (setting_language==0)
    {
      lv_obj_align_to(slider_label,slider,LV_ALIGN_OUT_BOTTOM_MID,-160,-68);
      lv_obj_align_to(slider_label2,slider,LV_ALIGN_OUT_BOTTOM_MID,-135,-68);
    }else if (setting_language==1)
    {
      lv_obj_align_to(slider_label,slider,LV_ALIGN_OUT_BOTTOM_MID,-145,-63);
      lv_obj_align_to(slider_label2,slider,LV_ALIGN_OUT_BOTTOM_MID,-120,-63);
    }else if (setting_language==2)
    {
      lv_obj_align_to(slider_label,slider,LV_ALIGN_OUT_BOTTOM_MID,-125,-63);
      lv_obj_align_to(slider_label2,slider,LV_ALIGN_OUT_BOTTOM_MID,-100,-63);
    }
    
    
   

    if (is_checked_sw1)
    {
      lv_obj_add_state(sw1, LV_STATE_CHECKED);
    }
    else
    {
      lv_obj_add_state(sw1, LV_STATE_DEFAULT);
    }

    if (is_checked_volume)
    {
      lv_obj_add_state(sw2, LV_STATE_CHECKED);
    system("echo 5 > /sys/class/gpio/export");
    system("echo out > /sys/class/gpio/gpio5/direction");
    system("echo 0 > /sys/class/gpio/gpio5/value");
    }
    else
    {
      lv_obj_add_state(sw2, LV_STATE_DEFAULT);
    system("echo 5 > /sys/class/gpio/export");
    system("echo out > /sys/class/gpio/gpio5/direction");
    system("echo 1 > /sys/class/gpio/gpio5/value");
    }
 
}
