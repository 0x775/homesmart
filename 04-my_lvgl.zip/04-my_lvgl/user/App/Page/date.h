/**
 * @file date.h
 *
 */

#ifndef LV_DATE_H
#define LV_DATE_H
#define mainwindow_label_wifi 0
#define mainwindow_label_sound 1
#define mainwindow_label_date 2
#define mainwindow_label_system 3
#define mainwindow_label_response 4
#define mainwindow_label_display 5
#define mainwindow_label_set 6
#define mainwindow_label_equipment 7
#define mainwindow_label_scenes 8
#define mainwindow_label_style 9
#define mainwindow_label_lamp1 10
#define mainwindow_label_lamp22 11
#define mainwindow_label_lamp33 12
#define mainwindow_label_door 13
#define mainwindow_label_AC 14
#define mainwindow_label_infrared 15
#define mainwindow_label_float 16
#define mainwindow_label_curtain 17
#define mainwindow_label_wind 18
#define mainwindow_label_theme1 19
#define mainwindow_label_theme2 20
#define wifi_label 21
#define wifi_label4 22
#define wifi_label3 23
#define voice_label_voice 24
#define voice_label2_voice 25
#define voice_label3_voice 26
#define voice_label4_voice 27
#define voice_label5_voice 28
#define voice_label6_voice 29
#define voice_label7_voice 30
#define date_label 31
#define date_label2 32
#define date_label3 33
#define date_label4 34
#define date_label5 35
#define date_label6 36
#define display_label 37
#define display_label2 38
#define display_label3 39
#define display_label4 40
#define display_label5 41
#define system_label 42
#define system_label_system 43
#define system_label_system1 44
#define system_label_system2 45
#define system_label_system3 46
#define system_label_reset2 47
#define system_label_mbox2 48
#define system_label_btn 49
#define system_label_btn2 50
#define wifi_label_mbox 51
#define wifi_label_btn 52
#define mainwindow_label_type 53
#define mainwindow_label_scenes11 54
#define mainwindow_label_devices 55
#define add_scene_label1 56
#define add_scene_label2 57
#define add_scene_label11 58
#define add_scene_label22 59
#define date_label_year 60
#define date_label_mon 61
#define date_label_day 62
#define date_label_mbox 63
#define date_label7 64
#define date_label8 65
#ifdef __cplusplus
extern "C"
{
#endif

    /*********************
     *      INCLUDES
     *********************/

    /*********************
     *      DEFINES
     *********************/

    /**********************
     *      TYPEDEFS
     **********************/

    /**********************
     * GLOBAL PROTOTYPES
     **********************/
    void date(void);
    extern int len;
    extern int setting_time_hour;
    extern int setting_time_hour;
    extern int label9_flag;
    extern int setting_date_year;
    extern int setting_date_mon;
    extern int setting_date_day;
    extern int date_flag;
    extern int setting_language;
    extern char language_Chinese[100][256];
    extern char language_English[100][256];
    extern char language_setting[100][256];
    /**********************
     *      MACROS
     **********************/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*LV_WIFI_H*/
