﻿/**
 * @file mainwindow.h
 *
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#ifdef __cplusplus
extern "C" {
#endif

    /*********************
     *      INCLUDES
     *********************/

     /*********************
      *      DEFINES
      *********************/

      /**********************
       *      TYPEDEFS
       **********************/

       /**********************
        * GLOBAL PROTOTYPES
        **********************/
        
    extern int device31_switch_state;
    extern int device32_switch_state;
    extern int device33_switch_state;
    extern int chg_device_switch;
    extern int is_checked_sw2;
    extern int is_checked_sw3;
    extern int is_checked_sw4;
    extern int is_checked_sw5;
    extern int is_checked_sw6;
    extern int is_checked_sw7;
    void mainwindow(void);

    /**********************
     *      MACROS
     **********************/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*MAINWINDOW_H*/
