/**
 * @file wifi_connect.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "wifi_connect.h"
#include "wifi.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
/*********************
 *      DEFINES
 *********************/
#define MAX_LINE 1024

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *page;
static lv_obj_t *bg;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label21;
static lv_obj_t *label22;
static lv_obj_t *password_input;
static char ipaddr[30];
static char macaddr[30];
static char safety[30];
char connected_wifi[50];

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0xp0000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_wifi);
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);
static char wname[50];
static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
}
static void event_handler1_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
    system("wpa_cli -i wlan0 disable_network 0");
    system("wpa_cli -i wlan0 list_network");
	memset(connected_wifi,0,50);
	disp_connect(connected_wifi);
}
static void event_handler_close(lv_event_t *e)
{
    lv_obj_clean(bg);
    lv_obj_del(bg);
}

static void msgbox_create(void)
{
    bg = lv_obj_create(lv_scr_act());
    lv_obj_set_size(bg, 480, 480);
    lv_obj_add_style(bg, &page_style, 0);
    lv_obj_set_style_bg_opa(bg, LV_OPA_70, 0);
    lv_obj_set_style_bg_color(bg, lv_color_black(), 0);

    lv_obj_t *mbox = lv_obj_create(bg);
    lv_obj_clear_flag(mbox, LV_OBJ_FLAG_SCROLLABLE); //禁止滚动
    lv_obj_align(mbox, LV_ALIGN_CENTER, 0, 0);
    lv_obj_add_style(mbox, &style_btn, 0);
    lv_obj_set_size(mbox, 300, 200);
    // lv_obj_set_style_text_color(mbox, lv_color_white(), 0);

    lv_obj_t *label_mbox = lv_label_create(mbox);
    lv_label_set_text(label_mbox, "密码错误，连接失败。");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_mbox, &font_chs_16, 0);
    lv_obj_align_to(label_mbox, mbox, LV_ALIGN_TOP_MID, 0, 30);
    lv_obj_set_style_text_color(label_mbox, lv_color_white(), 0);

    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{0, 100}, {300, 100}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(mbox);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);
    lv_obj_align_to(line1, mbox, LV_ALIGN_BOTTOM_MID, 0, -70);

    lv_obj_t *btn = lv_btn_create(mbox);
    lv_obj_add_style(btn, &style_btn, 0);
    lv_obj_align_to(btn, mbox, LV_ALIGN_BOTTOM_MID, -40, -30);
    lv_obj_add_event_cb(btn, event_handler_close, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label_btn = lv_label_create(btn);
    lv_label_set_text(label_btn, "知道了");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label_btn, &font_chs_16, 0);
    lv_obj_align_to(label_btn, btn, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_hex(0xffb400), 0);
}

static void event_handler_connect(lv_event_t *e)
{
	memset(connected_wifi,0,50);
	printf("event_handler_connect start--------------\n");
    char buf1[400];
    char buf2[1000];
    char buf3[400];
    const char *password = lv_textarea_get_text(password_input);
    system("wpa_cli -i wlan0 remove_network 0");
    usleep(10000);
    //system("wpa_cli -i wlan0 add_network");
    printf("wname:%s\n",wname);
    printf("password:%s\n",password);
    sprintf(buf1, "wpa_cli -i wlan0 set_network 0 ssid '\"%s\"'", wname);
    sprintf(buf2, "wpa_cli -i wlan0 set_network 0 psk '\"%s\"'", password);
    
	// sprintf(buf1, "adb shell \"su -c \'wpa_cli -i wlan0 set_network 0 ssid \'\\\"%s\\\"\'\'\"", wname);
	// sprintf(buf2, "adb shell \"su -c \'wpa_cli -i wlan0 set_network 0 psk \'\"%s\"\'\' \"", password);
    printf("buf1:%s\n",buf1);
    printf("buf2:%s\n",buf2);
    //system(buf1);
    //system(buf2);

    sprintf(buf1,"ctrl_interface=/var/run/wpa_supplicant\nap_scan=1\nnetwork={\nssid=\"%s\"\nkey_mgmt=WPA-PSK\npsk=\"%s\"\n}",wname,password);
    FILE* fptt;
	printf("fopen start-------------\n");
    if ((fptt = fopen("/userdata/wpa_supplicant.conf", "w")) == NULL)
        {
			printf("fopen error-------------\n");
            perror("fail to read");
            //exit(1);
        }
    
	printf("%s",buf1);
    fputs(buf1,fptt); 
    fclose(fptt);
    
    system("killall -9 wpa_supplicant && wpa_supplicant -B -i wlan0 -c /userdata/wpa_supplicant.conf");
    //system("wpa_cli -i wlan0 select_network 0");
	int tout = 20;
	int tcnt = 0;
	while(tcnt++ < tout*(1000/(1000/10))) {
		tcnt++;
		usleep(1000*(1000/10));
		system("wpa_cli -i wlan0 status > /userdata/wpa_status");
        FILE* fp;
		char buf[1000];
		memset(buf, 0, 1000);
		printf("fopen start-------------\n");
        if ((fp = fopen("/userdata/wpa_status", "r")) == NULL)
        {
			printf("fopen error-------------\n");
            perror("fail to read");
            //exit(1);
        }
        while (fp> 0 && fgets(buf, MAX_LINE, fp) != NULL)
        {
			printf("line:%s\n",buf);
			if(strlen(buf) > 0) {
				if(strstr(buf,"wpa_state=") != NULL) {
					if(strstr(buf,"COMPLETED") != NULL) {
						printf("wifi connected!----------");
                        wifi_saveconfig(wname,password);//链接成功后存入配置文件/userdata/wifi_save
						memset(connected_wifi,0,50);
						strcpy(connected_wifi,wname);
						disp_connect(connected_wifi);
						tout = 0;
						system("/etc/init.d/S49ntp restart");
						break;
					}
				}
				if(strstr(buf,"key_mgmt=") != NULL) {
					memset(safety,0,30);
					strcpy(safety,buf+9);
				}
			}
        }
		if(fp > 0) fclose(fp);
	}
	if(strlen(connected_wifi) > 0) {
		//printf("connected_wifi----->%s",connected_wifi);
		lv_obj_clean(page);
		lv_obj_del(page);
	}
	
    printf("event_handler_connect end--------------\n");
     
    // if (strcmp(password, "abc"))
    // {
    //     // printf("%s\n", password);
    //     msgbox_create();
    // }
}

static void ta_event_cb(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t *ta = lv_event_get_target(e);
    lv_obj_t *kb = lv_event_get_user_data(e);
    if (code == LV_EVENT_FOCUSED)
    {
        if (lv_indev_get_type(lv_indev_get_act()) != LV_INDEV_TYPE_KEYPAD)
        {
            lv_keyboard_set_textarea(kb, ta);
            lv_obj_set_style_max_height(kb, LV_HOR_RES * 2 / 3, 0);
            // lv_obj_update_layout(page); /*Be sure the sizes are recalculated*/
            lv_obj_set_height(page, LV_VER_RES - lv_obj_get_height(kb));
            lv_obj_clear_flag(kb, LV_OBJ_FLAG_HIDDEN);
            lv_obj_scroll_to_view_recursive(ta, LV_ANIM_OFF);
        }
    }
    else if (code == LV_EVENT_DEFOCUSED)
    {
        lv_keyboard_set_textarea(kb, NULL);
        lv_obj_set_height(page, LV_VER_RES);
        lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
    }
    else if (code == LV_EVENT_READY || code == LV_EVENT_CANCEL)
    {
        lv_obj_set_height(page, LV_VER_RES);
        lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_state(ta, LV_STATE_FOCUSED);
        lv_indev_reset(NULL, ta); /*To forget the last clicked object to make it focusable again*/
    }
}


// void wifi_saveconfig(char wifiname[],char password[]);
void wifi_saveconfig(char wifiname[],char password[]){
        char buf4[100];//wifi
		sprintf(buf4, "wifi=%s\tpasswd=%s", wifiname,password);
		printf("%s",buf4);
		FILE* fp;
        int i=0;
        if ((fp = fopen("/userdata/wifi_save", "w")) == NULL)
        {
        printf("fopen error-------------\n");
        perror("fail to open");
        }
        fputs(buf4,fp);
        fclose(fp);
	system("sync");
        }



void wifi_connect(char name[])
{
	memset(connected_wifi,0,50);
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -10, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_RELEASED, NULL);
    label = lv_label_create(return_btn);
    lv_label_set_text(label, "取消");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    // lv_obj_align_to(label, return_btn, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    static lv_style_t connect_style;
    lv_style_init(&connect_style);
    lv_style_set_bg_color(&connect_style, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&connect_style, 3);
    lv_style_set_border_color(&connect_style, lv_color_hex(0xffb400));
    lv_style_set_radius(&connect_style, 50);
    lv_style_set_shadow_width(&connect_style, 0);
    // lv_style_set_bg_opa(&connect_style, LV_OPA_0); // 设置背景的透明度

    lv_obj_t *connect_btn = lv_btn_create(page);
    lv_obj_add_style(connect_btn, &connect_style, 0);
    lv_obj_align(connect_btn, LV_ALIGN_TOP_RIGHT, 0, 0);
    lv_obj_add_event_cb(connect_btn, event_handler_connect, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label3 = lv_label_create(connect_btn);
    lv_label_set_text(label3, "连接");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label3, &font_chs_16, 0);
    // lv_obj_align_to(label, connect_btn, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_style_text_color(label3, lv_color_hex(0xffb400), 0);

    label2 = lv_label_create(page);
    

    char *tmp = NULL;
    // if ((tmp = strstr(name, "\n")))
    // {
    //     *tmp = '\0';
    // }
    memset(wname,0,50);
    strcpy(wname, name);
    //wname[strlen(wname)-1]=0;
    
	char label_text[10] = "请输入";
    lv_label_set_text(label2, label_text);
    LV_FONT_DECLARE(font_chs_qingshurulianjiemima_16);
    lv_obj_set_style_text_font(label2, &font_chs_qingshurulianjiemima_16, 0);
    lv_obj_align_to(label2, label, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);

	label21 = lv_label_create(page);
    lv_label_set_text(label21, name);
    LV_FONT_DECLARE(font_chs_18);
    lv_obj_set_style_text_font(label21, &font_chs_18, 0);
    lv_obj_align_to(label21, label2, LV_ALIGN_OUT_RIGHT_TOP, 10, 0);
    lv_obj_set_style_text_color(label21, lv_color_white(), 0);

    char label_text22[50] = "连接密码";
    label22 = lv_label_create(page);
    lv_label_set_text(label22, label_text22);
    LV_FONT_DECLARE(font_chs_qingshurulianjiemima_16);
    lv_obj_set_style_text_font(label22, &font_chs_qingshurulianjiemima_16, 0);
    lv_obj_align_to(label22, label2, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_set_style_text_color(label22, lv_color_white(), 0);

    /*Create a keyboard*/
    lv_obj_t *kb = lv_keyboard_create(lv_scr_act());
    lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);

    static lv_style_t input_style;
    lv_style_init(&input_style);
    lv_style_set_border_width(&input_style, 0);
    lv_style_set_bg_color(&input_style, lv_color_hex(0x454c52));
    lv_style_set_radius(&input_style, 10);
    lv_style_set_shadow_width(&input_style, 0);

    password_input = lv_textarea_create(page);
    lv_obj_set_size(password_input, 440, 70);
    lv_obj_add_style(password_input, &input_style, 0);
    lv_textarea_set_one_line(password_input, true);
    lv_textarea_set_password_mode(password_input, true);
    lv_textarea_set_placeholder_text(password_input, "password");
    lv_obj_set_style_text_color(password_input, lv_color_white(), 0);
    // lv_obj_set_style_text_font(password_input, &font_chs_16, 0);
    lv_textarea_set_align(password_input, LV_ALIGN_CENTER);
    lv_obj_align_to(password_input, label22, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
    lv_obj_add_event_cb(password_input, ta_event_cb, LV_EVENT_ALL, kb);
}

void wifi_connected(char name[])
{
	FILE* fp;
	char buf[1000];
	memset(buf, 0, 1000);
	memset(ipaddr,0,30);
	memset(macaddr,0,30);
	memset(safety,0,30);
	system("wpa_cli -i wlan0 status > /userdata/wpa_status");
	printf("fopen start-------------\n");
	if ((fp = fopen("/userdata/wpa_status", "r")) == NULL)
	{
		printf("fopen error-------------\n");
		perror("fail to read");
		//exit(1);
	}
	while (fp> 0 && fgets(buf, MAX_LINE, fp) != NULL)
	{
		printf("line:%s\n",buf);
		if(strlen(buf) > 0) {
			if(strstr(buf,"ip_address=") != NULL) {
				strcpy(ipaddr,buf+11);
			}
			if(strstr(buf,"address=") != NULL) {
				strcpy(macaddr,buf+8);
			}
			if(strstr(buf,"key_mgmt=") != NULL) {
				strcpy(safety,buf+9);
			}
		}
	}
	if(fp > 0) fclose(fp);
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_RELEASED, NULL);

    label = lv_label_create(page);
    lv_label_set_text(label, name);
    LV_FONT_DECLARE(font_chs_18);
    lv_obj_set_style_text_font(label, &font_chs_18, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);

    static lv_style_t disconnect_style;
    lv_style_init(&disconnect_style);
    lv_style_set_bg_color(&disconnect_style, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&disconnect_style, 3);
    lv_style_set_border_color(&disconnect_style, lv_color_white());
    lv_style_set_radius(&disconnect_style, 50);
    lv_style_set_shadow_width(&disconnect_style, 0);

    lv_obj_t *disconnect_btn = lv_btn_create(page);
    lv_obj_add_style(disconnect_btn, &disconnect_style, 0);
    lv_obj_align(disconnect_btn, LV_ALIGN_TOP_RIGHT, 0, 0);
    lv_obj_add_event_cb(disconnect_btn, event_handler1_return, LV_EVENT_RELEASED, NULL);
    lv_obj_t *label3 = lv_label_create(disconnect_btn);
    lv_label_set_text(label3, "断开连接");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label3, &font_chs_16, 0);
    // lv_obj_align_to(label, disconnect_btn, LV_ALIGN_LEFT_MID, 0, 0);
    lv_obj_set_style_text_color(label3, lv_color_white(), 0);

    label2 = lv_label_create(page);
    lv_label_set_text(label2, "WIFI状态");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label2, &font_chs_16, 0);
    lv_obj_align_to(label2, return_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 20, 10);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);

    lv_obj_t *connected_btn = lv_btn_create(page);
    lv_obj_add_style(connected_btn, &style_btn, 0);
    lv_obj_t *connected_img = lv_img_create(connected_btn);
    LV_IMG_DECLARE(icon_next_white);
    lv_img_set_src(connected_img, &icon_next_white); //设置图片源
    lv_obj_align_to(connected_btn, disconnect_btn, LV_ALIGN_OUT_BOTTOM_RIGHT, 0, 0);

    lv_obj_t *label4 = lv_label_create(page);
    lv_label_set_text(label4, "已连接");
    lv_obj_set_style_text_font(label4, &font_chs_16, 0);
    lv_obj_align_to(label4, connected_btn, LV_ALIGN_OUT_LEFT_MID, 0, 0);
    lv_obj_set_style_text_color(label4, lv_color_hex(0xffb400), 0);

    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{10, 90}, {440, 90}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_dash_width(&style_line, 10);
    lv_style_set_line_dash_gap(&style_line, 3);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(page);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);

    lv_obj_t *label_signal = lv_label_create(page);
    lv_label_set_text(label_signal, "信号强度");
    lv_obj_set_style_text_font(label_signal, &font_chs_16, 0);
    lv_obj_align_to(label_signal, line1, LV_ALIGN_OUT_BOTTOM_LEFT, 10, 30);
    lv_obj_set_style_text_color(label_signal, lv_color_white(), 0);
    lv_obj_t *label_signal_value = lv_label_create(page);
    lv_label_set_text(label_signal_value, "强");
    lv_obj_set_style_text_font(label_signal_value, &font_chs_16, 0);
    lv_obj_align_to(label_signal_value, line1, LV_ALIGN_OUT_BOTTOM_RIGHT, 0, 30);
    lv_obj_set_style_text_color(label_signal_value, lv_color_white(), 0);

    lv_obj_t *label_IP = lv_label_create(page);
    lv_label_set_text(label_IP, "IP地址");
    lv_obj_set_style_text_font(label_IP, &font_chs_16, 0);
    lv_obj_align_to(label_IP, label_signal, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 30);
    lv_obj_set_style_text_color(label_IP, lv_color_white(), 0);
    lv_obj_t *label_IP_value = lv_label_create(page);
    lv_label_set_text(label_IP_value, ipaddr);
    lv_obj_set_style_text_font(label_IP_value, &font_chs_16, 0);
    lv_obj_align_to(label_IP_value, label_signal_value, LV_ALIGN_OUT_BOTTOM_RIGHT, 0, 30);
    lv_obj_set_style_text_color(label_IP_value, lv_color_white(), 0);

    lv_obj_t *label_MAC = lv_label_create(page);
    lv_label_set_text(label_MAC, "MAC地址");
    lv_obj_set_style_text_font(label_MAC, &font_chs_16, 0);
    lv_obj_align_to(label_MAC, label_IP, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 30);
    lv_obj_set_style_text_color(label_MAC, lv_color_white(), 0);
    lv_obj_t *label_MAC_value = lv_label_create(page);
    lv_label_set_text(label_MAC_value, macaddr);
    lv_obj_set_style_text_font(label_MAC_value, &font_chs_16, 0);
    lv_obj_align_to(label_MAC_value, label_IP_value, LV_ALIGN_OUT_BOTTOM_RIGHT, 0, 15);
    lv_obj_set_style_text_color(label_MAC_value, lv_color_white(), 0);

    lv_obj_t *label_secure = lv_label_create(page);
    lv_label_set_text(label_secure, "安全性");
    lv_obj_set_style_text_font(label_secure, &font_chs_16, 0);
    lv_obj_align_to(label_secure, label_MAC, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 30);
    lv_obj_set_style_text_color(label_secure, lv_color_white(), 0);
    lv_obj_t *label_secure_value = lv_label_create(page);
    lv_label_set_text(label_secure_value, safety);
    lv_obj_set_style_text_font(label_secure_value, &font_chs_16, 0);
    lv_obj_align_to(label_secure_value, label_MAC_value, LV_ALIGN_OUT_BOTTOM_RIGHT, 0, 15);
    lv_obj_set_style_text_color(label_secure_value, lv_color_white(), 0);
}
