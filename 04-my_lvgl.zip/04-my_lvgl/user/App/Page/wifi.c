/**
 * @file wifi.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../../lvgl/lvgl.h"
#include "../../../lvgl/src/misc/lv_timer.h"
//#include "../App/Pages/login.h"
//#include "../App/Pages/device.h"
#include "./mainwindow.h"
#include "./screen_protection.h"
#include "./voice_response.h"
#include "../../../lv_conf.h"
#include "wifi.h"
#include "wifi_connect.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iconv.h>
#define MAX_LINE 1024
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t *page;
static lv_style_t page_style;
static lv_style_t style_btn;
static lv_obj_t *return_btn;
static lv_obj_t *sw;
static lv_obj_t *panel;
static lv_obj_t *label;
static lv_obj_t *label2;
static lv_obj_t *label3;
static lv_obj_t *label4;
static lv_obj_t *label_wifi0;
static lv_obj_t *label_wifi1;
static lv_obj_t *label_wifi2;
static lv_obj_t *label_wifi3;
static lv_obj_t *label_wifi4;
static lv_obj_t *label_wifi5;
static lv_obj_t *label_wifi6;
static lv_obj_t *label_wifi7;
static lv_obj_t *label_wifi8;
static lv_obj_t *label_wifi9;
static lv_obj_t *connect_img;
static lv_obj_t *label_connect;
static bool is_checked;
lv_timer_t *task_wifi;
lv_timer_t *task_sw;
lv_timer_t *task_sw2;

static int connect_img_flag=0;
static char connected_wifi_name[];
static char wifi_name[200];
static char scan_wifiname[30][200] = {};
static char safety[30];
char sw_flag[5]={'n'};
void task_cb_sw2(lv_timer_t * task);
/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK lv_color_hex(0x000000)
#define COLOR_GREY lv_color_hex(0x333333)
#define COLOR_ORANGE lv_color_hex(0xff931e)
#define COLOR_GRE lv_color_hex(0xd8d8d8)
#define COLOR_GREA lv_color_hex(0xffffff)

//声明图片指针
LV_IMG_DECLARE(img_src_wifi);
LV_IMG_DECLARE(img_src_left);
LV_IMG_DECLARE(icon_voice_02);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);
LV_FONT_DECLARE(font_loading);

void disp_connect(char name[])
{
	printf("connect_img: %d\n",connect_img);
	if(connect_img > 0) {
		if(strlen(connected_wifi) > 0) {
			printf("connect_img1: %d\n",connect_img);
			printf("label_connect1: %d\n",label_connect);
			lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -10, 0);
			printf("connect_img1: %d\n",connect_img);
			lv_label_set_text(label_connect, connected_wifi);
			lv_obj_align_to(label_connect, connect_img, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
			printf("label_connect1: %d\n",label_connect);
		} else if(strlen(connected_wifi) <= 0) {
			printf("label_connect2: %d\n",label_connect);
			lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -40, 0);
			printf("connect_img2: %d\n",connect_img);
			lv_label_set_text(label_connect, "");
			printf("label_connect2: %d\n",label_connect);
		}
		printf("end1 connect_img: %d\n",connect_img);
	}
}

void task_cb_wifi(lv_timer_t * task)
{
	//printf("connected_wifi: %s\n",connected_wifi);
	printf("connect_img: %d\n",connect_img);
	if(connect_img > 0) {
		if(strlen(connected_wifi) > 0 && connect_img_flag==0) {
			printf("label_connect: %d\n",label_connect);
			lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -10, 0);
			lv_label_set_text(label_connect, connected_wifi);
			lv_obj_align_to(label_connect, connect_img, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
			connect_img_flag=1;
			lv_timer_del(task_wifi);
		} else if(strlen(connected_wifi) <= 0 && connect_img_flag==1) {
			/*printf("label_connect: %d\n",label_connect);
			lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -40, 0);
			printf("1111connect_img: %d\n",connect_img);
			lv_label_set_text(label_connect, "");
			printf("2222label_connect: %d\n",label_connect);*/
			connect_img_flag=0;
			lv_timer_del(task_wifi);
		}
		printf("end1 connect_img: %d\n",connect_img);
	}
	printf("end connect_img: %d\n",connect_img);
}

static void event_handler_return(lv_event_t *e)
{
    lv_obj_clean(page);
    lv_obj_del(page);
    //analytics_create(t2);
        //mainwindow();

}

static void event_handler_connected(lv_event_t *e)
{
    lv_obj_t *btn_event = lv_event_get_target(e);
    lv_obj_t *label_event = lv_obj_get_child(btn_event, 1); //获取第二个子对象
    char *name = lv_label_get_text(label_event);
	if(strlen(connected_wifi) > 0) {
		wifi_connected(name);
	}
}

static void event_handler_connect(lv_event_t *e)
{
    lv_obj_t *btn_event = lv_event_get_target(e);
    lv_obj_t *label_event = lv_obj_get_child(btn_event, 0); //获取第二个子对象
    char *name = lv_label_get_text(label_event);
    wifi_connect(name);
}
void task_cb_sw(lv_timer_t * task)
{
    if (is_checked)
    {
        strcpy(sw_flag,"y");
        system("echo 'y' > /userdata/sw_flag");
        system("sync");
		system("rm -f /userdata/scan_result");
		system("rm -f /userdata/scan_result2");
        system("wpa_cli -i wlan0 scan");
		usleep(1000000);
        // system("adb shell \"su -c \'wpa_cli -i wlan0 scan_result\' \"");
	wifi_scan:
        system("wpa_cli -i wlan0 scan_result>/userdata/scan_result");
        // system("cat /userdata/scan_result|col -x >/userdata/scan_result2");
        system("cp /userdata/scan_result /userdata/scan_result2");
        system("sed -i '1d' /userdata/scan_result2");
        //system("sed -i '$d' /userdata/scan_result2");


        //system("cat /userdata/2.txt|col -x >/userdata/3.txt");
        //system("sed -i '1d' /userdata/3.txt");
        //system("sed -i '$d' /userdata/3.txt");
        usleep(100000);
		//printf("cp-------------\n");
        // system("cp ./2.txt ./3.txt");
        char buf[MAX_LINE];  /*缓冲区*/
        FILE* fp;           /*文件指针*/
        char *ptr;
        int i=0;
		int j=0;
		int wlen=0;
        char buf2[MAX_LINE];
        int n2=-1;
        memset(buf, 0, sizeof(buf));
		printf("fopen start-------------\n");
        if ((fp = fopen("/userdata/scan_result2", "r")) == NULL)
        {
			printf("fopen error-------------\n");
            perror("fail to read");
            //exit(1);
        }
        while (fp > 0 && fgets(buf, MAX_LINE, fp) != NULL)
        {
			// ptr=strrchr(buf,'\t');
			/*ptr=strrchr(buf,' ');
			if (ptr[1]!='['&&ptr[1]!='\\')
			{
				printf("%s", ptr + 1);
				strcpy(scan_wifiname[i], ptr + 1);
				i++;
            } */
			if(i == 0) {
				i++;
				continue;
			}
			printf("wifi:%s\n",buf);
			j = strlen(buf);
			while(j > 0) {
				j--;
				if(buf[j] == '\t') {
					if(strlen(buf+j+1)-1>0){
					memcpy(scan_wifiname[i-1],buf+j+1,strlen(buf+j+1)-1);
					printf("name:%s\n",scan_wifiname[i-1]);
					i++;}
					break;
				} else {
					//printf("buf not \\t-------------\n");
					wlen++;
				}
			}
        }
        if(fp > 0) fclose(fp);
        printf("i=11111:%d\nss",i);
		if(i <=0 ) {
			usleep(2000000);
			goto wifi_scan;
		}
		system("rm -f /userdata/scan_result");
        static lv_style_t panel_style;
        lv_style_init(&panel_style);
        lv_style_set_border_width(&panel_style, 0);
        lv_style_set_bg_color(&panel_style, lv_color_hex(0x2f3338));
        lv_style_set_radius(&panel_style, 0);

        panel = lv_obj_create(page);
        lv_obj_set_size(panel, 450, 380);
        lv_obj_add_style(panel, &panel_style, 0);
        lv_obj_set_pos(panel, 5, 100);
        //lv_obj_set_scroll_dir(panel, LV_DIR_TOP);

        label3 = lv_label_create(panel);
        lv_label_set_text(label3, "连接的WLAN");
        LV_FONT_DECLARE(font_chs_16);
        lv_obj_set_style_text_font(label3, &font_chs_16, 0);
        lv_obj_align(label3, LV_ALIGN_TOP_LEFT, -15, -10);
        lv_obj_set_style_text_color(label3, lv_color_white(), 0);

        lv_obj_t *connect_btn = lv_btn_create(panel);
        lv_obj_add_style(connect_btn, &style_btn, 0);
        lv_obj_set_size(connect_btn, 450, 40);
        lv_obj_align_to(connect_btn, label3, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 10);
																						
        lv_obj_add_event_cb(connect_btn, event_handler_connected, LV_EVENT_LONG_PRESSED, NULL);
        LV_IMG_DECLARE(icon_WLAN_y);
        connect_img = lv_img_create(connect_btn);
        lv_img_set_src(connect_img, &icon_WLAN_y); //设置图片源
        lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -40, 0);
        label_connect = lv_label_create(connect_btn);
        LV_FONT_DECLARE(font_chs_18);
        lv_obj_set_style_text_font(label_connect, &font_chs_18, 0);
        lv_label_set_text(label_connect, "");
        lv_obj_align_to(label_connect, connect_img, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
		//task_wifi = lv_timer_create(task_cb_wifi, 50, NULL);
		disp_connect(connected_wifi);
		
		
        label4 = lv_label_create(panel);
        lv_label_set_text(label4, "选取附近的WLAN");
        LV_FONT_DECLARE(font_chs_16);
        lv_obj_set_style_text_font(label4, &font_chs_16, 0);
        lv_obj_align_to(label4, connect_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 10);
        lv_obj_set_style_text_color(label4, lv_color_white(), 0);
		
		lv_obj_t * preobj = label4;
		for(int n=0;n<30;n++) {
			//printf("strlen:%d, scan_wifiname[%d]:%s\n",strlen(scan_wifiname[n]),n,scan_wifiname[n]);
			if(strlen(scan_wifiname[n])>0)
			{
                printf("\n%s\n",scan_wifiname[n]);
		
			    for(i=0;i<strlen(scan_wifiname[n]);i++){
			
                if(scan_wifiname[n][i]=='\\'&&scan_wifiname[n][i+1]=='x'){
                    n2=n;
                    printf("\nCHI:%s\n",scan_wifiname[n2]);
                if ((fp = fopen("/userdata/wifiname_cludexx", "w")) == NULL)
                {
                    printf("fopen error-------------\n");
                    perror("fail to open");
                }
                fputs(scan_wifiname[n2],fp);	
                fclose(fp);

				//system("rm -rf /userdata/wifiname_cn");
                system("echo -e `cat /userdata/wifiname_cludexx` > /userdata/wifiname_cn");
                system("rm -rf /userdata/wifiname_cludexx");
                //转码
				//system("iconv -f UTF-8 -t GBK /userdata/wifiname_cn -o /userdata/wifiname_cn");
                
                if ((fp = fopen("/userdata/wifiname_cn", "r")) == NULL)
                {
                    printf("fopen error-------------\n");
                    perror("fail to open");
                }
                while (fp > 0 && fgets(buf2, 1024, fp) != NULL);
                fclose(fp);
                
                //strcpy(scan_wifiname[n2],buf2);
                buf2[strlen(buf2)-1]='\0';
                printf("\nafter %s\n",buf2);
                system("rm -rf /userdata/wifiname_cn");
                break;
            }
			
		}

				lv_obj_t *wifi_btn = lv_btn_create(panel);
				lv_obj_t *label_wifi = lv_label_create(wifi_btn);
				lv_obj_add_style(wifi_btn, &style_btn, 0);
				lv_obj_set_size(wifi_btn, 440, 40);
				lv_obj_align_to(wifi_btn, preobj, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
				lv_obj_add_event_cb(wifi_btn, event_handler_connect, LV_EVENT_LONG_PRESSED, label_wifi);
				LV_IMG_DECLARE(icon_WLAN_white);
				lv_obj_t *wifi_img = lv_img_create(wifi_btn);
				lv_img_set_src(wifi_img, &icon_WLAN_white); //设置图片源
				lv_obj_align(wifi_img, LV_ALIGN_LEFT_MID, -10, 0);
				LV_FONT_DECLARE(font_chs_18);

				LV_FONT_DECLARE(lv_font_montserrat_18);
				// if(!strcmp(connected_wifi,buf2))
				// continue;
                strcpy(wifi_name, scan_wifiname[n]);
                if(n==n2){//中文字体
                lv_obj_set_style_text_font(label_wifi, &font_chs_18, 0);

                lv_label_set_text(label_wifi, buf2);
				lv_obj_align_to(label_wifi, wifi_img, LV_ALIGN_OUT_RIGHT_TOP, 20, -10);
				lv_obj_t *label_hint = lv_label_create(wifi_btn);
				lv_obj_set_style_text_font(label_hint, &lv_font_montserrat_18, 0);
				lv_label_set_text(label_hint, "WPA WAP2");
				lv_obj_set_style_text_color(label_hint, lv_color_hex(0x80878c), 0);
				lv_obj_align_to(label_hint, label_wifi, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 0);
                }
                else{
				lv_obj_set_style_text_font(label_wifi, &lv_font_montserrat_18, 0);
				
                lv_label_set_text(label_wifi, wifi_name);
				lv_obj_align_to(label_wifi, wifi_img, LV_ALIGN_OUT_RIGHT_TOP, 20, -10);
				lv_obj_t *label_hint = lv_label_create(wifi_btn);
				lv_obj_set_style_text_font(label_hint, &lv_font_montserrat_18, 0);
				lv_label_set_text(label_hint, "WPA WAP2");
				lv_obj_set_style_text_color(label_hint, lv_color_hex(0x80878c), 0);
				lv_obj_align_to(label_hint, label_wifi, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 0);
                }
                

				LV_IMG_DECLARE(icon_lock);
				lv_obj_t *lock_img = lv_img_create(wifi_btn);
				lv_img_set_src(lock_img, &icon_lock); //设置图片源
				lv_obj_align(lock_img, LV_ALIGN_RIGHT_MID, 10, 0);
				preobj = wifi_btn;
				memset(scan_wifiname[n],0,50);
			}
		}
		printf("\nend---------------\n");
    }
    else
    {
		//lv_obj_clean(connect_img);
		//lv_obj_del(connect_img);
		//lv_obj_clean(label_connect);
		//lv_obj_del(label_connect);
		//lv_timer_del(task_wifi);
 
		system("wpa_cli -i wlan0 disconnect");
		memset(connected_wifi,0,50);
        lv_obj_clean(panel);
        lv_obj_del(panel);

            strcpy(sw_flag,"n");
            system("echo 'n' > /userdata/sw_flag");
            system("chmod 777 /userdata/sw_flag");
            system("echo 'n' > /userdata/sw_flag");
            system("sync");
            system("echo `cat /userdata/sw_flag`");
            printf("\nflag=%s\n",sw_flag);
			label_connect=0;
			connect_img=0;
        
    }task_sw2 = lv_timer_create(task_cb_sw2, 50, NULL);
    lv_timer_del(task_sw);

}

void task_cb_sw2(lv_timer_t * task)
{
 if (is_checked)
    {
	printf("11111111111111111111111\n");
    //判断是否有网
    //system("wpa_cli -i wlan0 status > /userdata/wpa_status");
    FILE* fp1;
    char bufstatus[100];
    memset(bufstatus, 0, 100);
    char buf1[400];
    system("touch /userdata/wifi_save");
    if ((fp1 = fopen("/userdata/wifi_save", "r")) == NULL)
    {
        printf("fopen error-------------\n");
        perror("fail to read wifi_save");
        //exit(1);
    }
    while (fp1> 0 && fgets(bufstatus, 100, fp1) != NULL);
    fclose(fp1);
    printf("line:%s\n",bufstatus);
        if(strlen(bufstatus) > 0) {
                           //1.读文件获取上一次连接的wifi
                            char wifiname[50]={};
                            char wifipasswd[50]={};
                            wifi_readconfig(wifiname,wifipasswd);
                            printf("\n%s %s\n",wifiname,wifipasswd);
                            //2.连接wifi
                            sprintf(buf1,"ctrl_interface=/var/run/wpa_supplicant\nap_scan=1\nnetwork={\nssid=\"%s\"\nkey_mgmt=WPA-PSK\npsk=\"%s\"\n}",wifiname,wifipasswd);
                            FILE* fptt;
                            printf("fopen start-------------\n");
                            if ((fptt = fopen("/userdata/wpa_supplicant.conf", "w")) == NULL)
                                {
                                    printf("fopen error-------------\n");
                                    perror("fail to read");
                                    //exit(1);
                                }
                            
                            printf("\n%s\n\n",buf1);
                            fputs(buf1,fptt); 
                            fclose(fptt);
                            
                            system("killall -9 wpa_supplicant && wpa_supplicant -B -i wlan0 -c /userdata/wpa_supplicant.conf");
                            int tout = 30;
                            int tcnt = 0;
                            while(tcnt++ < tout*(1000/(1000/10))) {
                                tcnt++;
                                usleep(1000*(1000/10));
                                system("wpa_cli -i wlan0 status > /userdata/wpa_status");
                                FILE* fp;
                                char buf[1000];
                                memset(buf, 0, 1000);
                                printf("fopen start222222-------------\n");
                                if ((fp = fopen("/userdata/wpa_status", "r")) == NULL)
                                {
                                    printf("fopen error-------------\n");
                                    perror("fail to read");
                                    //exit(1);
                                }
                                int p=0;
                                while (fp> 0 && fgets(buf, MAX_LINE, fp) != NULL)
                                {
                                    printf("line:%s\n",buf);
                                    if(strlen(buf) > 0) {
                                        if(strstr(buf,"wpa_state=") != NULL) {
                                            if(strstr(buf,"COMPLETED") != NULL) {
                                                printf("second time wifi connected!----------\n");
                                                memset(connected_wifi,0,50);
                                                strcpy(connected_wifi,wifiname);
                                                disp_connect(connected_wifi);
                                                tout = 0;
                                                system("/etc/init.d/S49ntp restart");
                                                break;
                                            }
                                        }
                                        if(strstr(buf,"key_mgmt=") != NULL) {
                                            memset(safety,0,30);
                                            strcpy(safety,buf+9);
                                        }
                                    }
                                }
                                if(fp > 0) fclose(fp);
                            }
                            if(strlen(connected_wifi) > 0) {
                                //printf("connected_wifi----->%s",connected_wifi);
                                //lv_obj_clean(page);
                                //lv_obj_del(page);
                            }
                            
                            printf("encond time event_handler_connect end--------------\n");

        }
    


        
    }
    lv_timer_del(task_sw2);
}



static void event_handler_switch(lv_event_t *e)
{
    is_checked = lv_obj_has_state(sw, LV_STATE_CHECKED); // 返回 bool 类型， 开-1 ； 关-0
    task_sw = lv_timer_create(task_cb_sw, 50, NULL);
    
}

void wifi(void)
{
	
    //背景
    lv_style_init(&page_style);
    lv_style_set_border_width(&page_style, 0);
    lv_style_set_bg_color(&page_style, lv_color_hex(0x2f3338));
    lv_style_set_radius(&page_style, 0);

    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    lv_obj_add_style(page, &page_style, 0);
    lv_obj_set_scroll_dir(page, LV_DIR_TOP);                //只能垂直滚动
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF); //从不显示滚动条

    lv_style_init(&style_btn);
    lv_style_set_bg_color(&style_btn, lv_color_hex(0x2f3338));
    lv_style_set_border_width(&style_btn, 0);
    lv_style_set_radius(&style_btn, 10);
    lv_style_set_shadow_width(&style_btn, 0);
    // lv_style_set_bg_opa(&style_btn, LV_OPA_0); // 设置背景的透明度

    return_btn = lv_btn_create(page);
    // lv_obj_set_size(return_btn, 50, 50);
    LV_IMG_DECLARE(icon_return);
    lv_obj_add_style(return_btn, &style_btn, 0);
    lv_obj_t *return_img = lv_img_create(return_btn);
    lv_img_set_src(return_img, &icon_return); //设置图片源
    lv_obj_align(return_btn, LV_ALIGN_TOP_LEFT, -5, 0);
    lv_obj_add_event_cb(return_btn, event_handler_return, LV_EVENT_CLICKED, NULL);

    label = lv_label_create(page);
    lv_label_set_text(label, "连接无线网络");
    // lv_obj_set_size(label, 200, 50);
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label, &font_chs_16, 0);
    lv_obj_align_to(label, return_btn, LV_ALIGN_OUT_RIGHT_MID, 0, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);
    // lv_obj_set_pos(label, 60, 20);

    label2 = lv_label_create(page);
    lv_label_set_text(label2, "WLAN");
    LV_FONT_DECLARE(font_chs_16);
    lv_obj_set_style_text_font(label2, &font_chs_16, 0);
    lv_obj_align(label2, LV_ALIGN_TOP_LEFT, 10, 50);
    lv_obj_set_style_text_color(label2, lv_color_white(), 0);

    sw = lv_switch_create(page);
    lv_obj_align(sw, LV_ALIGN_TOP_RIGHT, -10, 50);
    // 修改开关状态指示器部分，关闭状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0x80878c), LV_PART_MAIN);
    // 修改开关状态指示器部分，打开状态时的背景颜色
    lv_obj_set_style_bg_color(sw, lv_color_hex(0xffb400), LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw, event_handler_switch, LV_EVENT_RELEASED, NULL);

    /*Create an array for the points of the line*/
    static lv_point_t line_points[] = {{10, 90}, {440, 90}};

    /*Create style*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    // lv_style_set_line_width(&style_line, 2);
    lv_style_set_line_dash_width(&style_line, 10);
    lv_style_set_line_dash_gap(&style_line, 3);
    lv_style_set_line_color(&style_line, lv_color_white());

    /*Create a line and apply the new style*/
    lv_obj_t *line1;
    line1 = lv_line_create(page);
    lv_line_set_points(line1, line_points, 2); /*Set the points*/
    lv_obj_add_style(line1, &style_line, 0);
	
    FILE* fpflag;/*文件指针*/ 
    if ((fpflag = fopen("/userdata/sw_flag", "r")) == NULL){ 
        perror("fail to read flag");}
    else{
        fgets(sw_flag, 5, fpflag);fclose(fpflag);}
    printf("sw_flag==========%s\n",sw_flag);
    if(sw_flag[0]=='y'){
		printf("\nkaishisaomiao\n");
        lv_obj_add_state(sw, LV_STATE_CHECKED);
		//lv_obj_add_state(sw, LV_STATE_CHECKED);
		system("rm -f /userdata/scan_result");
		system("rm -f /userdata/scan_result2");
        system("wpa_cli -i wlan0 scan");
		usleep(1000000);
	wifi_scan:
        // system("echo -e \'wpa_cli -i wlan0 scan_result>/userdata/scan_result\'");
        system("wpa_cli -i wlan0 scan_result>/userdata/scan_result");
		system("cp /userdata/scan_result /userdata/scan_result2");
        system("sed -i '1d' /userdata/scan_result2");
        //system("sed -i '$d' /userdata/scan_result2");
        usleep(100000);
        char buf[MAX_LINE];
        FILE* fp;
        char *ptr;
        int i=0;
		int j=0;
		int wlen=0;
        char buf2[MAX_LINE];
        int n2=-1;
        memset(buf, 0, sizeof(buf));
		printf("fopen start-------------\n");
        if ((fp = fopen("/userdata/scan_result2", "r")) == NULL)
        {
			printf("fopen error-------------\n");
            perror("fail to read");
            //exit(1);
        }
        while (fp > 0 && fgets(buf, MAX_LINE, fp) != NULL)
        {
			if(i == 0) {
				i++;
				continue;
			}
			printf("wifi:%s\n",buf);
			j = strlen(buf);
			while(j > 0) {
				j--;
				if(buf[j] == '\t') {
					memcpy(scan_wifiname[i-1],buf+j+1,strlen(buf+j+1)-1);
					printf("name:%s\n",scan_wifiname[i-1]);
					i++;
					break;
				} else {
					//printf("buf not \\t-------------\n");
					wlen++;
				}
			}
        }
        if(fp > 0) fclose(fp);
		if(i <=0 ) {
			usleep(1000000);
			goto wifi_scan;
		}
		system("rm -f /userdata/scan_result");
        static lv_style_t panel_style;
        lv_style_init(&panel_style);
        lv_style_set_border_width(&panel_style, 0);
        lv_style_set_bg_color(&panel_style, lv_color_hex(0x2f3338));
        lv_style_set_radius(&panel_style, 0);

        panel = lv_obj_create(page);
        lv_obj_set_size(panel, 450, 380);
        lv_obj_add_style(panel, &panel_style, 0);
        lv_obj_set_pos(panel, 5, 100);
        //lv_obj_set_scroll_dir(panel, LV_DIR_TOP);

        label3 = lv_label_create(panel);
        lv_label_set_text(label3, "连接的WLAN");
        LV_FONT_DECLARE(font_chs_16);
        lv_obj_set_style_text_font(label3, &font_chs_16, 0);
        lv_obj_align(label3, LV_ALIGN_TOP_LEFT, -15, -10);
        lv_obj_set_style_text_color(label3, lv_color_white(), 0);

        lv_obj_t *connect_btn = lv_btn_create(panel);
        lv_obj_add_style(connect_btn, &style_btn, 0);
        lv_obj_set_size(connect_btn, 450, 40);
        lv_obj_align_to(connect_btn, label3, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 10);
        lv_obj_add_event_cb(connect_btn, event_handler_connected, LV_EVENT_LONG_PRESSED, NULL);
        LV_IMG_DECLARE(icon_WLAN_y);
        connect_img = lv_img_create(connect_btn);
        lv_img_set_src(connect_img, &icon_WLAN_y); //设置图片源
       
        LV_FONT_DECLARE(font_chs_18);
        if (strlen(connected_wifi) > 0 )//如果已经连接了为ifi
        {													
        lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -10, 0);
        label_connect = lv_label_create(connect_btn);

        lv_obj_set_style_text_font(label_connect, &font_chs_18, 0);
        lv_label_set_text(label_connect, connected_wifi);
        lv_obj_align_to(label_connect, connect_img, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
		//task_wifi = lv_timer_create(task_cb_wifi, 50, NULL);
        }
        else{																			
        lv_obj_align(connect_img, LV_ALIGN_LEFT_MID, -40, 0);
        label_connect = lv_label_create(connect_btn);
        
        lv_obj_set_style_text_font(label_connect, &font_chs_18, 0);
        lv_label_set_text(label_connect, "");
        lv_obj_align_to(label_connect, connect_img, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
		//task_wifi = lv_timer_create(task_cb_wifi, 50, NULL);
		disp_connect(connected_wifi);

        }
        label4 = lv_label_create(panel);
        lv_label_set_text(label4, "选取附近的WLAN");
        LV_FONT_DECLARE(font_chs_16);
        lv_obj_set_style_text_font(label4, &font_chs_16, 0);
        lv_obj_align_to(label4, connect_btn, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 10);
        lv_obj_set_style_text_color(label4, lv_color_white(), 0);
		
		lv_obj_t * preobj = label4;
		for(int n=0;n<30;n++) {
			//printf("strlen:%d, scan_wifiname[%d]:%s\n",strlen(scan_wifiname[n]),n,scan_wifiname[n]);
			if(strlen(scan_wifiname[n])>0)
			{
                printf("\n%s\n",scan_wifiname[n]);
		
			    for(i=0;i<strlen(scan_wifiname[n]);i++){
			
                if(scan_wifiname[n][i]=='\\'&&scan_wifiname[n][i+1]=='x'){
                    n2=n;
                    printf("\nCHI:%s\n",scan_wifiname[n2]);
                if ((fp = fopen("/userdata/wifiname_cludexx", "w")) == NULL)
                {
                    printf("fopen error-------------\n");
                    perror("fail to open");
                }
                fputs(scan_wifiname[n2],fp);	
                fclose(fp);

				//system("rm -rf /userdata/wifiname_cn");
                system("echo -e `cat /userdata/wifiname_cludexx` > /userdata/wifiname_cn");
                system("rm -rf /userdata/wifiname_cludexx");
                //转码
				//system("iconv -f UTF-8 -t GBK /userdata/wifiname_cn -o /userdata/wifiname_cn");
                
                if ((fp = fopen("/userdata/wifiname_cn", "r")) == NULL)
                {
                    printf("fopen error-------------\n");
                    perror("fail to open");
                }
                while (fp > 0 && fgets(buf2, 1024, fp) != NULL);
                fclose(fp);
                
                //strcpy(scan_wifiname[n2],buf2);
                buf2[strlen(buf2)-1]='\0';
                printf("\nafter %s\n",buf2);
                system("rm -rf /userdata/wifiname_cn");
                break;
            }
			
		}

				lv_obj_t *wifi_btn = lv_btn_create(panel);
				lv_obj_t *label_wifi = lv_label_create(wifi_btn);
				lv_obj_add_style(wifi_btn, &style_btn, 0);
				lv_obj_set_size(wifi_btn, 440, 40);
				lv_obj_align_to(wifi_btn, preobj, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 20);
				lv_obj_add_event_cb(wifi_btn, event_handler_connect, LV_EVENT_LONG_PRESSED, label_wifi);
				LV_IMG_DECLARE(icon_WLAN_white);
				lv_obj_t *wifi_img = lv_img_create(wifi_btn);
				lv_img_set_src(wifi_img, &icon_WLAN_white); //设置图片源
				lv_obj_align(wifi_img, LV_ALIGN_LEFT_MID, -10, 0);
				LV_FONT_DECLARE(font_chs_18);
				
				LV_FONT_DECLARE(lv_font_montserrat_18);
				// printf("connected_wifi:%s\nscan_wifiname[n]:%s",connected_wifi,scan_wifiname[n]);
				// if(!strcmp(connected_wifi,buf2))
				// continue;
                strcpy(wifi_name, scan_wifiname[n]);
                if(n==n2){//中文字体
                lv_obj_set_style_text_font(label_wifi, &font_chs_18, 0);
                lv_label_set_text(label_wifi, buf2);
                }
                else{
				lv_obj_set_style_text_font(label_wifi, &lv_font_montserrat_18, 0);
                lv_label_set_text(label_wifi, wifi_name);
				}
				lv_obj_align_to(label_wifi, wifi_img, LV_ALIGN_OUT_RIGHT_TOP, 20, -10);
				lv_obj_t *label_hint = lv_label_create(wifi_btn);
				lv_obj_set_style_text_font(label_hint, &lv_font_montserrat_18, 0);
				lv_label_set_text(label_hint, "WPA WAP2");
				lv_obj_set_style_text_color(label_hint, lv_color_hex(0x80878c), 0);
				lv_obj_align_to(label_hint, label_wifi, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 0);
                
 
				LV_IMG_DECLARE(icon_lock);
				lv_obj_t *lock_img = lv_img_create(wifi_btn);
				lv_img_set_src(lock_img, &icon_lock); //设置图片源
				lv_obj_align(lock_img, LV_ALIGN_RIGHT_MID, 10, 0);
				preobj = wifi_btn;
				memset(scan_wifiname[n],0,50);
			}
		}
        
    }
    
}

//void wifi_readconfig(char wifiname[],char password[]);
void wifi_readconfig(char wifiname[],char password[]){
        int i,j,a,b,n,k,n1,k1;
        a=b=0;
        n1=k1=0;
        char buf[100];
        FILE* fp;
        system("touch /userdata/wifi_save");
        if ((fp = fopen("/userdata/wifi_save", "r")) == NULL)
            {
            printf("fopen error-------------\n");
            perror("fail to open");
            }
        while (fp > 0 && fgets(buf, MAX_LINE, fp) != NULL);
            fclose(fp);
            //printf("%s\n",buf);
                        
            for(j=0;j<strlen(buf)-2;j++){
                if((buf[j])=='i'&&buf[j+1]=='='){//wifi=
                        n=j+2;//起始下标
                        n1=n;
                        //printf(" n%d",n);
                while((buf[n1++])!='\t'){a++;}printf(" a%d",a);
                            }
                        }
                            
            for(i=0;i<strlen(buf)-2;i++){
                if((buf[i])=='d'&&buf[i+1]=='='){//passwd=
                        k=i+2;//起始下标
                        k1=k;
                        //printf(" k%d",k);
                while((buf[k1++])!='\0'){b++;}printf(" b%d",b);
                            }
                        }
                    memcpy(wifiname,&buf[n],a);  
                    memcpy(password,&buf[k],b);
                    //wifiname[strlen(wifiname)-1]='\0';
                    //password[strlen(password)-1]='\0';

    }
