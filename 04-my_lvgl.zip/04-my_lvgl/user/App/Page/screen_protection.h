﻿/**
 * @file screen_protection.h
 *
 */

#ifndef SCREEN_PROTECTION_H
#define SCREEN_PROTECTION_H

#ifdef __cplusplus
extern "C" {
#endif

    /*********************
     *      INCLUDES
     *********************/

     /*********************
      *      DEFINES
      *********************/

      /**********************
       *      TYPEDEFS
       **********************/

       /**********************
        * GLOBAL PROTOTYPES
        **********************/
    void screen_protection(void);


    /**********************
     *      MACROS
     **********************/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*SCREEN_PROTECTION_H*/
