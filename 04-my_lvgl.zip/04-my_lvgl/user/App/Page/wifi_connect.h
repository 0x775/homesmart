/**
 * @file wifi_connect.h
 *
 */

#ifndef LV_WIFI_CONNECT_H
#define LV_WIFI_CONNECT_H

#ifdef __cplusplus
extern "C"
{
#endif

    /*********************
     *      INCLUDES
     *********************/

    /*********************
     *      DEFINES
     *********************/

    /**********************
     *      TYPEDEFS
     **********************/

    /**********************
     * GLOBAL PROTOTYPES
     **********************/
	extern char connected_wifi[50];
	 
    void wifi_connect(char name[]);
    void wifi_connected(char name[]);

    /**********************
     *      MACROS
     **********************/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*LV_WIFI_CONNECT_H*/
