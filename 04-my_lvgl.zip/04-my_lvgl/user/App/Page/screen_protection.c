﻿#include "screen_protection.h"
#include "../../../lvgl/lvgl.h"
#include <time.h>

LV_FONT_DECLARE(font_time_65);
LV_FONT_DECLARE(font_chs_16);
LV_FONT_DECLARE(font_unlock_10);

LV_IMG_DECLARE(bg_loading1); //声明图片
LV_IMG_DECLARE(bg_voice);
LV_IMG_DECLARE(icon_voice_01);

lv_obj_t* page;

void screen_protection(void)
{
    page = lv_obj_create(lv_scr_act());
    lv_obj_set_size(page, 480, 480);
    page = lv_img_create(lv_scr_act());//创建一个图像对象
    lv_img_set_src(page, &bg_loading1);//设置图片源
    lv_obj_center(page);

    lv_obj_t* label = lv_label_create(page);
    lv_obj_set_style_opa(label, 60, 0);
    lv_obj_align(label, LV_ALIGN_TOP_MID, 0, 25);
    lv_obj_set_style_text_font(label, &font_unlock_10, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(0xffffff), 0);
    lv_label_set_text(label, "触屏解锁");

    time_t nowtime;
    //首先创建一个time_t 类型的变量nowtime
    struct tm* p;
    //然后创建一个新时间结构体指针 p 
    time(&nowtime);
    //使用该函数就可得到当前系统时间，使用该函数需要将传入time_t类型变量nowtime的地址值。
    p = localtime(&nowtime);

    lv_obj_t* time_label = lv_label_create(page);
    lv_obj_set_height(time_label, LV_SIZE_CONTENT);
    lv_obj_align(time_label, LV_ALIGN_CENTER, 0, -80);
    lv_label_set_text_fmt(time_label, "%02d:%02d", p->tm_hour, p->tm_min);
    lv_obj_set_style_text_font(time_label, &font_time_65, 0);
    lv_obj_set_style_text_color(time_label, lv_color_hex(0xffffff), 0);

    lv_obj_t* date_label = lv_label_create(page);
    lv_obj_align(date_label, LV_ALIGN_CENTER, -55, 0);
    lv_label_set_text_fmt(date_label, "%4d/%02d/%02d", p->tm_year+1900, p->tm_mon+1, p->tm_mday);
    lv_obj_set_style_text_font(date_label, &font_chs_16, 0);
    lv_obj_set_style_text_color(date_label, lv_color_hex(0xffffff), 0);

    lv_obj_t* week_label = lv_label_create(page);
    lv_obj_align(week_label, LV_ALIGN_CENTER, 75, 0);
    //LV_FONT_DECLARE(font_date_16);
    switch (p->tm_wday)
    {
    case 0:
        lv_label_set_text_fmt(week_label, "星期日");
        break;
    case 1:
        lv_label_set_text_fmt(week_label, "星期一");
        break;
    case 2:
        lv_label_set_text_fmt(week_label, "星期二");
        break;
    case 3:
        lv_label_set_text_fmt(week_label, "星期三");
        break;
    case 4:
        lv_label_set_text_fmt(week_label, "星期四");
        break;
    case 5:
        lv_label_set_text_fmt(week_label, "星期五");
        break;
    case 6:
        lv_label_set_text_fmt(week_label, "星期六");
        break;
    }
    lv_obj_set_style_text_font(week_label, &font_chs_16, 0);
    lv_obj_set_style_text_color(week_label, lv_color_hex(0xffffff), 0);

    lv_obj_t* bg_voice_img = lv_img_create(page);
    lv_img_set_src(bg_voice_img, &bg_voice);
    lv_obj_align(bg_voice_img, LV_ALIGN_CENTER, 0, 120);

    lv_obj_t* voice_img = lv_img_create(page);
    lv_img_set_src(voice_img, &icon_voice_01);
    lv_obj_align(voice_img, LV_ALIGN_CENTER, 0, 120);
}
