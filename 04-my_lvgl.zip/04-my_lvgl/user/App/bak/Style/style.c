﻿/**
 * @file Style.c
 * 
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "../../../lvgl/lvgl.h"

/**********************
 *  STATIC PROTOTYPES
 **********************/

void style(){

static lv_style_t style_line;
lv_style_init(&style_line);
lv_style_set_line_width(&style_line, 1);
lv_style_set_line_color(&style_line, lv_color_hex(0x979797));
lv_style_set_line_rounded(&style_line, true);

}
