﻿/**
 * @file lv_app.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "../../lvgl/lvgl.h"
#include "../App/Pages/login.h"
#include "../App/Pages/device.h"
#include "../../lvgl/src/core/lv_obj.h"



/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/
typedef enum {
    DISP_SMALL,
    DISP_MEDIUM,
    DISP_LARGE,
}disp_size_t;

/**********************
 *  STATIC PROTOTYPES
 **********************/


static void lv_wifi_list(lv_obj_t* cont);
static void roller_event_handler(lv_obj_t* obj, lv_event_t event);
static void imgbtn1_event_handler(lv_obj_t* obj, lv_event_t event);
static void wifi_pages(lv_obj_t* e);
static void lv_wifi_keyboard(void);
static void ta_event_cb(lv_event_t * e);
//static void lv_wifi_keyboard(lv_event_t* e); //
static void taw_event_cb(lv_event_t* e);



/**********************
 *  STATIC VARIABLES
 **********************/
static disp_size_t disp_size;

static lv_obj_t * par;
static lv_obj_t * par1;
static lv_obj_t * par2;
static lv_obj_t * par3;
static lv_obj_t * tv;
static lv_obj_t * calendar;
static lv_obj_t * calendar_header;
static lv_obj_t * btnm;
static lv_style_t style_text_muted;
static lv_style_t style_title;
static lv_style_t style_icon;
static lv_style_t style_bullet;


static lv_obj_t * meter1;
static lv_obj_t * meter2;
static lv_obj_t * meter3;

static lv_obj_t * chart1;
static lv_obj_t * chart2;
static lv_obj_t * chart3;
static lv_timer_t* my_timer;

static lv_chart_series_t * ser1;
static lv_chart_series_t * ser2;
static lv_chart_series_t * ser3;
static lv_chart_series_t * ser4;

static const lv_font_t * font_large;
static const lv_font_t * font_normal;

static uint32_t session_desktop = 1000;
static uint32_t session_tablet = 1000;
static uint32_t session_mobile = 1000;

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BLACK     lv_color_hex(0x000000)
#define COLOR_GREY      lv_color_hex(0x333333)
#define COLOR_ORANGE    lv_color_hex(0xff931e)
#define COLOR_GRE       lv_color_hex(0xd8d8d8)
#define COLOR_GREA      lv_color_hex(0xffffff)

 //声明图片指针
LV_IMG_DECLARE(img_src_wifi);
LV_IMG_DECLARE(img_src_left);
// 字体声明指针
LV_FONT_DECLARE(font_src_pingfang_28);
LV_FONT_DECLARE(font_src_pingfang_27);
LV_FONT_DECLARE(font_src_password_27);


void lv_app(void)
{
    lv_obj_t* par = lv_obj_create(lv_scr_act());
    lv_obj_set_size(par, 480, 480);
    //lv_obj_set_style_radius(par1, 170, 0);
    lv_obj_center(par);
    lv_obj_set_style_bg_opa(par,  LV_STATE_DEFAULT, LV_OPA_100);
    lv_obj_set_style_bg_color(par, COLOR_BLACK,LV_STATE_DEFAULT );


    //logo
    LV_IMG_DECLARE(img_src_logo);

    lv_obj_t* img = lv_img_create(par);
    lv_img_set_src(img, &img_src_logo);
    lv_obj_center(img);
    //lv_obj_align(img, NULL, LV_ALIGN_CENTER, 0, 0);

     //进度条
    //lv_obj_t* bar1 = lv_bar_create(par, NULL);
    //lv_obj_set_size(bar1, 100, 4);
    //lv_obj_align_to(bar1, img, LV_ALIGN_OUT_BOTTOM_MID, 0, 20);
    ////lv_obj_center(bar1);

  /*  lv_obj_set_style_bg_color(bar1, COLOR_GREY, 0);
    lv_obj_set_style_bg_opa(bar1, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(bar1, LV_RADIUS_CIRCLE, 0);*/

    //lv_obj_set_style_bg_color(bar1, COLOR_ORANGE, LV_PART_INDICATOR);
    //lv_obj_set_style_bg_opa(bar1, LV_OPA_COVER, LV_PART_INDICATOR);
    //lv_obj_set_style_radius(bar1, LV_RADIUS_CIRCLE, LV_PART_INDICATOR);
    //lv_bar_set_range(bar1, 0, 1000);

        //动态加载
    //lv_scr_load_anim(wifi_pages, LV_SCR_LOAD_ANIM_FADE_ON, 20,2000, true);
    //wifi_pages(par);
     login();
    //device();



}


 static void wifi_pages(lv_obj_t* e){

    lv_obj_t* par1 = lv_obj_create(lv_scr_act());
    lv_obj_set_size(par1, 340, 340);
    lv_obj_set_style_radius(par1, 170, 0);
    lv_obj_center(par1);
    lv_obj_set_style_bg_opa(par1, LV_STATE_DEFAULT, LV_OPA_COVER);
    lv_obj_set_style_bg_color(par1, COLOR_BLACK, LV_STATE_DEFAULT);

    //wifi
    lv_obj_t* img1 = lv_img_create(par1);
    lv_img_set_src(img1, &img_src_wifi);
    lv_obj_align(img1, LV_ALIGN_TOP_MID, 0, 51);
    //lv_obj_center(img1);

    //延迟删除,单位毫秒
    //lv_obj_del_delayed(e, 20);
   // lv_obj_clean(e);

    //加载WiFi按键阵列    
    lv_wifi_list(par1);
}

 static void roller_event_handler(lv_obj_t* obj, lv_event_t event)
 {
    lv_wifi_keyboard();

    //lv_obj_del_delayed(par1, 20);


 }


 static void imgbtn1_event_handler(lv_obj_t* obj, lv_event_t event)
 {
     wifi_pages(par3);
     //if (event == LV_EVENT_VALUE_CHANGED) {
     //    char buf[32];
     //    lv_roller_get_selected_str(obj, buf, sizeof(buf));
     //   // printf("Selected month: %s\n", buf);
     //}

 }



 void lv_wifi_list(lv_obj_t* cont)
 {
     static const char map[] = { "TP_Link\n" "Dav\n" "zhangshuqi\n" "jindangjun\n" "test\n""Hello\n" };

     lv_obj_t* roller1 = lv_roller_create(cont);
     lv_roller_set_options(roller1,map,LV_ROLLER_MODE_INFINITE);
     
     

     // 设置可见的行个数
     lv_roller_set_visible_row_count(roller1,3);
     lv_obj_set_width(roller1, 254.34);     
     lv_obj_align(roller1, LV_ALIGN_TOP_MID, 0, 130);     
     lv_obj_set_style_text_font(roller1, &font_src_pingfang_28, 0);

     //设置滚轮选的
     lv_obj_set_style_bg_color(roller1, COLOR_GRE, LV_PART_SELECTED);
     lv_obj_set_style_radius(roller1, 26.85, LV_PART_SELECTED);
     lv_obj_set_style_text_opa(roller1, 100, LV_PART_SELECTED);
     //lv_obj_set_style_opa(roller1,50, LV_PART_SELECTED);

     lv_obj_set_style_bg_color(roller1, COLOR_GREY, LV_STATE_DEFAULT);     
     lv_obj_set_style_border_color(roller1, COLOR_GREY, LV_STATE_DEFAULT);// 设置滚轮边框颜色   
     lv_obj_set_style_text_color(roller1, COLOR_GREA, LV_STATE_DEFAULT);
     lv_obj_set_style_text_opa(roller1,49, LV_STATE_DEFAULT);
     lv_obj_add_event_cb(roller1, roller_event_handler, LV_EVENT_CLICKED, NULL);

     
 }





 static void taw_event_cb(lv_event_t* e)
 {
     lv_event_code_t code = lv_event_get_code(e);    
     //const char* str = lv_event_get_code(e);

     lv_obj_t* ta = lv_event_get_target(e);
     lv_obj_t* kb = lv_event_get_user_data(e);
     if (code == LV_EVENT_FOCUSED) {
         lv_keyboard_set_textarea(kb, ta); //textarea
         lv_obj_clear_flag(kb, LV_OBJ_FLAG_HIDDEN);//取消隐藏
         
     }

     else if (code == LV_EVENT_DEFOCUSED) {
         lv_keyboard_set_textarea(kb, NULL);
         lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
         
     }
     //判断键盘完成还是插入字符.认为完成并跳转到用户登录界面
     else if (code == LV_EVENT_READY || code == LV_EVENT_CANCEL){

         //触发用户登录页面
         login();

     }

         

     

 }





 void lv_wifi_keyboard(void)
 {
     lv_obj_t* par3 = lv_obj_create(lv_scr_act());
     lv_obj_set_size(par3, 340, 340);
     lv_obj_set_style_radius(par3, 170, 0);
     lv_obj_center(par3);
     lv_obj_set_style_bg_opa(par3, LV_STATE_DEFAULT, LV_OPA_COVER);
     lv_obj_set_style_bg_color(par3, COLOR_BLACK, LV_STATE_DEFAULT);

     //密码页的网络标签
     lv_obj_t* la_wl = lv_label_create(par3);
     lv_obj_set_style_text_font(la_wl,  &font_src_password_27,0);
     lv_obj_set_style_text_color(la_wl, COLOR_GREA, LV_STATE_DEFAULT);
     lv_label_set_text(la_wl, "密码");
     //lv_textarea_set_pwd_mode(la_wl, true); //密码输入模式

     lv_obj_align(la_wl, LV_ALIGN_TOP_MID, 0, 55);
    
     

     //密码页返回按钮
     lv_obj_t* btn1 = lv_imgbtn_create(par3);
     lv_obj_align(btn1, LV_ALIGN_TOP_MID, -52, 55);
     lv_obj_set_width(btn1, 15);
     lv_obj_set_height(btn1, 27);     
     lv_obj_add_event_cb(btn1, imgbtn1_event_handler, LV_EVENT_CLICKED, NULL);//按键增加返回事件
     lv_imgbtn_set_src(btn1, LV_IMGBTN_STATE_RELEASED,NULL,&img_src_left,NULL); 
       
     

     /*Create a keyboard to use it with an of the text areas*/
     lv_obj_t* kb = lv_keyboard_create(par3);   //lv_scr_act()
     lv_obj_set_size(kb, 234, 97);
     lv_obj_align(kb, LV_ALIGN_TOP_MID, 0, 190);
     lv_obj_set_style_bg_color(kb, COLOR_BLACK, LV_STATE_DEFAULT);
     //lv_obj_set_pos(kb, 0, 0);
     lv_keyboard_set_mode(kb, LV_KEYBOARD_MODE_TEXT_LOWER);

     /*Create a text area. The keyboard will write here*/
     lv_obj_t* ta;
     ta = lv_textarea_create(par3);
     lv_obj_align(ta, LV_ALIGN_TOP_MID, 0, 135);
     lv_obj_add_event_cb(ta, taw_event_cb, LV_EVENT_ALL, kb);
     lv_textarea_set_placeholder_text(ta, "Password");    
     lv_obj_set_style_radius(ta, 26.85, 0); //密码框圆角
     lv_obj_set_style_text_color(ta, COLOR_GREA, LV_STATE_DEFAULT);
     lv_textarea_set_one_line(ta, true); // 设置为单行输入
     lv_obj_set_style_text_font(ta, &font_src_pingfang_27, 0);
     lv_obj_set_style_bg_color(ta, COLOR_GRE, LV_STATE_DEFAULT);     
     lv_obj_set_size(ta, 254, 49);
         
     lv_keyboard_set_textarea(kb, ta);
 }

 


