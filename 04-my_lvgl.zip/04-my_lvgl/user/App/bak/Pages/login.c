﻿/**
 * @file login.c
 *
 *
 */

 /*********************
  *      INCLUDES
  *********************/
#include "../../../lvgl/src/core/lv_obj.h"
#include "../../../lvgl/lvgl.h"

//#include "../../App/Style/style.h"
//#include "../../App/Pages/device.h"

  /**********************
   *  STATIC PROTOTYPES
   **********************/

static void imgbtn_event_return(lv_obj_t* obj, lv_event_t event);
static void event_login(lv_obj_t* obj, lv_event_t event);
static void event_cb_login(lv_event_t* e);
static void event_cb_uesr(lv_event_t* e);



static  lv_obj_t* par_login ;
static  lv_obj_t* kb;
static  lv_obj_t* ta_uesr;
static  lv_obj_t* tv;




  /**********************
   *   GLOBAL FUNCTIONS
   **********************/
#define COLOR_BLACK     lv_color_hex(0x000000)
#define COLOR_GREY      lv_color_hex(0x333333)
#define COLOR_ORANGE    lv_color_hex(0xff931e)
#define COLOR_GRE       lv_color_hex(0xd8d8d8)
#define COLOR_GREA      lv_color_hex(0xffffff)
#define COLOR_SKY_BLUE      lv_color_hex(0x0FB3F7)

//声明图片指针
LV_IMG_DECLARE(img_src_left);
// 字体声明指针
LV_FONT_DECLARE(font_src_shs_20);
LV_FONT_DECLARE(font_src_shs_16);
LV_FONT_DECLARE(font_src_shs_14);
LV_FONT_DECLARE(font_src_shs_12);
LV_FONT_DECLARE(font_src_shs_11);




void login(void) {

    lv_obj_t* par_login = lv_obj_create(lv_scr_act());
    lv_obj_set_size(par_login, 340, 340);
    lv_obj_set_style_radius(par_login, 170, 0);
    lv_obj_center(par_login);
    lv_obj_set_style_bg_opa(par_login, LV_STATE_DEFAULT, LV_OPA_COVER);
    lv_obj_set_style_bg_color(par_login, COLOR_BLACK, LV_STATE_DEFAULT);


   // tv = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, 70);

    //登录页标签
    lv_obj_t* la_login = lv_label_create(par_login);
    lv_obj_set_style_text_font(la_login, &font_src_shs_20, 0);
    lv_obj_set_style_text_color(la_login, COLOR_GREA, LV_STATE_DEFAULT);
    lv_label_set_text(la_login, "用户登录");
    lv_obj_align(la_login, LV_ALIGN_TOP_MID, 0, 42);


    //密码页返回按钮
    lv_obj_t* imgbtn_login_return = lv_imgbtn_create(par_login);
    lv_obj_align(imgbtn_login_return, LV_ALIGN_TOP_MID, -52, 40);
    lv_obj_set_width(imgbtn_login_return, 10);
    lv_obj_set_height(imgbtn_login_return, 18);
    lv_obj_add_event_cb(imgbtn_login_return, imgbtn_event_return, LV_EVENT_CLICKED, NULL);//按键增加返回事件
    lv_imgbtn_set_src(imgbtn_login_return, LV_IMGBTN_STATE_RELEASED, NULL, &img_src_left, NULL);

    //账号标签
    lv_obj_t* la_uesr = lv_label_create(par_login);
    lv_obj_set_style_text_font(la_uesr, &font_src_shs_14, 0);
    lv_obj_set_style_text_color(la_uesr, COLOR_GREA, LV_STATE_DEFAULT);
    lv_label_set_text(la_uesr, "账号");
    lv_obj_align(la_uesr, LV_ALIGN_TOP_MID, -115, 93);

    //密码标签
    lv_obj_t* la_uesr_password = lv_label_create(par_login);
    lv_obj_set_style_text_font(la_uesr_password, &font_src_shs_14, 0);
    lv_obj_set_style_text_color(la_uesr_password, COLOR_GREA, LV_STATE_DEFAULT);
    lv_label_set_text(la_uesr_password, "密码");
    lv_obj_align(la_uesr_password, LV_ALIGN_TOP_MID, -115, 168);

    /*Create a keyboard*/
    lv_obj_t* kb = lv_keyboard_create(lv_scr_act());
    lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);//键盘隐藏起来
    lv_obj_set_size(kb, 200, 87);
    lv_obj_align(kb, LV_ALIGN_TOP_MID, 0, 309);
    lv_obj_set_style_bg_color(kb, COLOR_GREY, LV_STATE_DEFAULT);


    //账号输入框
    lv_obj_t* ta_uesr = lv_textarea_create(par_login);
    lv_obj_align(ta_uesr, LV_ALIGN_TOP_MID, -80, 120);
    lv_obj_set_size(ta_uesr, 120, 18);
    lv_textarea_set_one_line(ta_uesr, true);
    lv_obj_set_style_text_color(ta_uesr, COLOR_GREA, LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(ta_uesr, COLOR_GREY, LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ta_uesr, COLOR_GREY, LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ta_uesr, &font_src_shs_12,  0);
    lv_obj_add_event_cb(ta_uesr, event_cb_uesr, LV_EVENT_ALL, kb);
    lv_textarea_set_placeholder_text(ta_uesr, "wujiangming wujiangming");


    //密码输入框
    lv_obj_t* ta_password = lv_textarea_create(par_login);
    lv_obj_align(ta_password, LV_ALIGN_TOP_MID, -80, 195);
    lv_obj_set_size(ta_password, 120, 18);
    lv_textarea_set_one_line(ta_password, true);// 设置为单行输入   
    lv_textarea_set_password_mode(ta_password, true);//密码输入模式
    lv_obj_set_style_text_color(ta_password, COLOR_GREA, LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(ta_password, COLOR_GREY, LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ta_password, COLOR_GREY, LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ta_password, &font_src_shs_12, 0);
    lv_obj_add_event_cb(ta_password, event_cb_uesr, LV_EVENT_ALL, kb);
    lv_textarea_set_placeholder_text(ta_password, "000000000000");

       

    /*创建线条位置*/
   
    static lv_point_t line_points[] = { {-255, 0}, {255, 0} };

    /*创建线条试样*/
    static lv_style_t style_line;
    lv_style_init(&style_line);
    lv_style_set_line_width(&style_line, 1);
    lv_style_set_line_color(&style_line, lv_color_hex(0x979797));
    lv_style_set_line_rounded(&style_line, true);

    lv_obj_t* line1 = lv_line_create(par_login);
    lv_line_set_points(line1, line_points, 2);     
    //lv_obj_add_style(line1, &style_line, 0);
    lv_obj_add_style(line1, &style_line, 0);
    lv_obj_align(line1, LV_ALIGN_TOP_MID, 0, 145);

    lv_obj_t* line2 = lv_line_create(par_login);
    lv_line_set_points(line2, line_points, 2);
    lv_obj_add_style(line2, &style_line, 0);
    lv_obj_align(line2, LV_ALIGN_TOP_MID, 0, 220);


    lv_obj_t* btn_login = lv_btn_create(par_login);
    lv_obj_add_event_cb(btn_login, event_login, LV_EVENT_PRESSED, NULL);
    lv_obj_align(btn_login, LV_ALIGN_TOP_MID, 0, 258);

    lv_obj_t* la_login1 = lv_label_create(btn_login);
    lv_obj_set_style_text_font(la_login1, &font_src_shs_16, 0);
    lv_obj_set_style_text_color(la_login1, COLOR_GREA, LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(la_login1, LV_TEXT_ALIGN_CENTER, 0);
    lv_label_set_text(la_login1, "登录");
    lv_obj_set_size(la_login1, 60, 20);
    lv_obj_set_style_radius(la_login1, 15, 0); //圆角


    //扫描登录标签
    lv_obj_t* la_scan_code = lv_label_create(par_login);
    lv_obj_set_style_text_font(la_scan_code, &font_src_shs_11, 0);
    lv_obj_set_style_text_color(la_scan_code, COLOR_SKY_BLUE, LV_STATE_DEFAULT);
    lv_label_set_text(la_scan_code, "扫码登录");
    lv_obj_align(la_scan_code, LV_ALIGN_TOP_MID, -105, 230);

    //忘记密码标签
    lv_obj_t* la_forget = lv_label_create(par_login);
    lv_obj_set_style_text_font(la_forget, &font_src_shs_11, 0);
    lv_obj_set_style_text_color(la_forget, COLOR_SKY_BLUE, LV_STATE_DEFAULT);
    lv_label_set_text(la_forget, "忘记密码");
    lv_obj_align(la_forget, LV_ALIGN_TOP_MID, 105, 230);



}

static void imgbtn_event_return(lv_obj_t* obj, lv_event_t event) {



}

static void event_login(lv_obj_t* obj, lv_event_t event) {

    device();

}

static void event_cb_uesr(lv_event_t* e)
{
    ///*键盘弹出*/
    //lv_obj_t* kb = lv_keyboard_create(lv_scr_act());
    //lv_obj_set_size(kb, 234, 97);
    //lv_obj_align(kb, LV_ALIGN_TOP_MID, 0, 190);
    //lv_obj_set_style_bg_color(kb, COLOR_GREY, LV_STATE_DEFAULT);
    ////lv_obj_set_pos(kb, 0, 0);
    //lv_keyboard_set_mode(kb, LV_KEYBOARD_MODE_TEXT_LOWER);  
    //lv_keyboard_set_textarea(kb, ta_uesr);


    /*键盘弹出*/
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* ta = lv_event_get_target(e);
    lv_obj_t* kb = lv_event_get_user_data(e);
    if (code == LV_EVENT_FOCUSED) {
        if (lv_indev_get_type(lv_indev_get_act()) != LV_INDEV_TYPE_KEYPAD) {
            lv_keyboard_set_textarea(kb, ta);
            //lv_obj_set_style_max_height(kb, LV_HOR_RES * 2/ 3, 0);
            //lv_obj_update_layout(tv);   /*Be sure the sizes are recalculated*/
            //lv_obj_set_height(tv, LV_VER_RES - lv_obj_get_height(kb));
            lv_obj_clear_flag(kb, LV_OBJ_FLAG_HIDDEN); //取消隐藏
            lv_obj_scroll_to_view_recursive(ta, LV_ANIM_OFF);
        }
    }
    else if (code == LV_EVENT_DEFOCUSED) {
        lv_keyboard_set_textarea(kb, NULL);
        //lv_obj_set_height(tv, LV_VER_RES);
        lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
    }
    else if (code == LV_EVENT_READY || code == LV_EVENT_CANCEL) {
       // lv_obj_set_height(tv, LV_VER_RES);
        lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
        lv_obj_clear_state(ta, LV_STATE_FOCUSED);
        lv_indev_reset(NULL, ta);   /*To forget the last clicked object to make it focusable again*/
       
    }


}



