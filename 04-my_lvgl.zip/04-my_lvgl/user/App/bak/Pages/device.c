﻿/**
 * @file device.c
 * 
 *
 */

 /*********************
  *      INCLUDES
  *********************/

#include "../../../lvgl/lvgl.h"

  /**********************
   *      TYPEDEFS
   **********************/
typedef enum {
    DISP_SMALL,
    DISP_MEDIUM,
    DISP_LARGE,
}disp_size_t;





 /**********************
  *   GLOBAL FUNCTIONS
  **********************/
#define COLOR_GREY      lv_color_hex(0x333333)
#define COLOR_AAAA      lv_color_hex(0x505C70)

  //声明图片指针
LV_IMG_DECLARE(img_src_air_conditioner);
LV_IMG_DECLARE(img_src_sweep);
LV_IMG_DECLARE(img_src_television);
LV_IMG_DECLARE(img_src_washer);
// 字体声明指针
LV_FONT_DECLARE(font_pingfang_28);
LV_FONT_DECLARE(font_wangluo28);

/**********************
 *  STATIC VARIABLES
 **********************/
static disp_size_t disp_size;
static lv_style_t style_text_muted;
static lv_obj_t* create_shop_item(lv_obj_t* parent, const void* img_src, const char* name, const char* category, const char* price);

void device(void) {

    static lv_style_t style_panel;
    lv_style_init(&style_panel);
    lv_style_set_bg_color(&style_panel, COLOR_AAAA);
    lv_style_set_bg_opa(&style_panel, 21);
    lv_style_set_width(&style_panel,95 );
    lv_style_set_height(&style_panel, 100);
    lv_style_set_border_color( &style_panel, COLOR_AAAA);

    static lv_style_t style_grid;
    lv_style_init(&style_grid);
    lv_style_set_bg_color(&style_grid, COLOR_AAAA);
    lv_style_set_bg_opa(&style_grid, 21);
    lv_style_set_width(&style_grid, 195);
    lv_style_set_height(&style_grid, 50);
    lv_style_set_border_color(&style_grid, COLOR_AAAA);

    static lv_style_t style_list;
    lv_style_init(&style_list);
    lv_style_set_bg_color(&style_list, COLOR_AAAA);
    lv_style_set_bg_opa(&style_list, 21);
    lv_style_set_width(&style_list, 225);
    lv_style_set_height(&style_list, 300);
    lv_style_set_border_color(&style_list, COLOR_AAAA);


    lv_obj_t* par_device = lv_obj_create(lv_scr_act());
    lv_obj_set_size(par_device, 340, 340);
    lv_obj_set_style_radius(par_device, 170, 0);
    lv_obj_center(par_device);
    lv_obj_set_style_bg_opa(par_device, LV_STATE_DEFAULT, LV_OPA_COVER);
    lv_obj_set_style_bg_color(par_device, COLOR_GREY, LV_STATE_DEFAULT);

    lv_obj_t* device_plan0 = lv_obj_create(par_device);
    lv_obj_add_style(device_plan0, &style_panel, 0);
    lv_obj_align(device_plan0, LV_ALIGN_TOP_LEFT, 51, 50);

    lv_obj_t* device_plan1 = lv_obj_create(par_device);
    lv_obj_add_style(device_plan1, &style_panel, 0);
    lv_obj_align(device_plan1, LV_ALIGN_TOP_LEFT, 154, 50);

    lv_obj_t* device_plan2 = lv_obj_create(par_device);
    lv_obj_add_style(device_plan2, &style_panel, 0);
    lv_obj_align(device_plan2,LV_ALIGN_TOP_LEFT, 51, 159);

    lv_obj_t* device_plan3 = lv_obj_create(par_device);
    lv_obj_add_style(device_plan3, &style_panel, 0);
    lv_obj_align(device_plan3,LV_ALIGN_TOP_LEFT, 154, 159);


    lv_obj_t* title = lv_label_create(par_device);
    lv_label_set_text(title, "Monthly Summary");
    lv_obj_add_style(title, &style_grid, 0);



    lv_obj_t* list = lv_obj_create(par_device);
    if (disp_size == DISP_SMALL) {
        lv_obj_add_flag(list, LV_OBJ_FLAG_FLEX_IN_NEW_TRACK);
        //lv_obj_set_height(list, LV_PCT(100));
        lv_obj_add_style(list, &style_list, 0);
    }
    else {
        lv_obj_set_height(list, LV_PCT(100));
        //lv_obj_set_style_max_height(list, 100, 0);
        lv_obj_set_style_max_height(list, &style_list, 0);
    }

    lv_obj_set_flex_flow(list, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_grow(list, 1);
    lv_obj_add_flag(list, LV_OBJ_FLAG_FLEX_IN_NEW_TRACK);

    title = lv_label_create(list);
    lv_label_set_text(title, "Top products");
    lv_obj_add_style(title, &style_grid, 0);

    LV_IMG_DECLARE(img_clothes);
    create_shop_item(list, &img_src_sweep, "Blue jeans", "Clothes", "$722");
    create_shop_item(list, &img_src_sweep, "Blue jeans", "Clothes", "$411");


}

static lv_obj_t* create_shop_item(lv_obj_t* parent, const void* img_src, const char* name, const char* category, const char* price)
{
    //static lv_coord_t grid_col_dsc[] = { LV_GRID_CONTENT, 5, LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST };
    //static lv_coord_t grid_row_dsc[] = { LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_FR(1),LV_GRID_TEMPLATE_LAST };

    static lv_coord_t grid_col_dsc[] = { LV_GRID_FR(1), LV_GRID_FR(1), LV_GRID_TEMPLATE_LAST };
    static lv_coord_t grid_row_dsc[] = { LV_GRID_FR(1), LV_GRID_FR(1),LV_GRID_TEMPLATE_LAST };

    lv_style_init(&style_text_muted);
    lv_style_set_text_opa(&style_text_muted, LV_OPA_50);

    lv_obj_t* cont = lv_obj_create(parent);
    lv_obj_remove_style_all(cont);
    lv_obj_set_size(cont, LV_PCT(100), LV_SIZE_CONTENT);
  
    lv_obj_set_grid_dsc_array(cont, grid_col_dsc, grid_row_dsc);

    lv_obj_t* img = lv_img_create(cont);
    lv_img_set_src(img, img_src);
    lv_obj_set_grid_cell(img, LV_GRID_ALIGN_START, 0, 1, LV_GRID_ALIGN_START, 0, 2);

    lv_obj_t* img1 = lv_img_create(cont);
    lv_img_set_src(img1, img_src);
    lv_obj_set_grid_cell(img1, LV_GRID_ALIGN_START, 1, 1, LV_GRID_ALIGN_START, 0, 2);

    lv_obj_t* label;
    label = lv_label_create(cont);
    lv_label_set_text(label, name);
    lv_obj_set_grid_cell(label, LV_GRID_ALIGN_START, 2, 1, LV_GRID_ALIGN_END, 0, 1);

    //label = lv_label_create(cont);
    //lv_label_set_text(label, category);
    //lv_obj_add_style(label, &style_text_muted, 0);
    //lv_obj_set_grid_cell(label, LV_GRID_ALIGN_START, 2, 1, LV_GRID_ALIGN_START, 1, 1);

    //label = lv_label_create(cont);
    //lv_label_set_text(label, price);
    //lv_obj_set_grid_cell(label, LV_GRID_ALIGN_END, 3, 1, LV_GRID_ALIGN_END, 0, 1);

    return cont;
}
