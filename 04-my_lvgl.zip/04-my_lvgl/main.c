#include <sys/time.h>


#include "lvgl/lvgl.h"
#include "lv_drivers/display/drm.h"
#include "lv_drivers/indev/evdev.h"
#include "lv_drivers/display/fbdev.h"
#include "lvgl/src/widgets/lv_img.h"
#include "lvgl/src/core/lv_event.h"
#include "lvgl/examples/porting/lv_port_disp.h"
#include "lvgl/examples/porting/lv_port_indev.h"
#include "lvgl/src/core/lv_obj.h"
#include "user/App/Recource/recource.h"
#include "user/App/app.h"

#include <unistd.h>

//#define DISP_BUF_SIZE (100 * LV_HOR_RES_MAX) //lvgl用于绘制屏幕的缓冲区。这里用100行像素作为缓冲区这个可以修改。
static lv_obj_t *label1;
static lv_obj_t *label;
static lv_obj_t *cont_empty;


static lv_obj_t * par;


/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_GREY      lv_color_hex(0x333333)
#define COLOR_ORANGE    lv_color_hex(0xff931e)
#define COLOR_GRE       lv_color_hex(0xd8d8d8)
#define COLOR_GREA      lv_color_hex(0xffffff)
#define LVGL_TICK 	5

static lv_obj_t *label;
//static lv_color_t buf[DISP_BUF_SIZE];

static lv_color_t buf_1[LV_HOR_RES_MAX * 480];
static lv_color_t buf_2[LV_HOR_RES_MAX * 480];






//kang 增加代码
void lv_demo(void)
{
    lv_obj_t* par = lv_obj_create(lv_scr_act());
    lv_obj_set_size(par, 480, 480);
    //lv_obj_set_style_radius(par1, 170, 0);
    lv_obj_center(par);
    lv_obj_set_style_bg_opa(par,  LV_STATE_DEFAULT, LV_OPA_100);
    lv_obj_set_style_bg_color(par, COLOR_GREY,LV_STATE_DEFAULT );


    //logo
    LV_IMG_DECLARE(img_src_logo);	

    lv_obj_t* img = lv_img_create(par);
    lv_img_set_src(img, &img_src_logo);
    lv_obj_center(img);
    
    //wifi_pages(par);

}

//int main(int argc, char **argv)
int main(int argc, char **argv)

{
	lv_init();	//lvgl gui初始化

    //Lcd kangjin
    //lv_port_disp_init();        // 显示器初始化
    //fbdev_init();
    drm_init(); //初始化
    //static lv_color_t buf[DISP_BUF_SIZE];
	static lv_disp_draw_buf_t  disp_buf;

    //lv_disp_draw_buf_init(&disp_buf, buf_1, buf_2, DISP_BUF_SIZE);
    lv_disp_draw_buf_init(&disp_buf, buf_1, buf_2, LV_HOR_RES_MAX*LV_VER_RES_MAX);
    
    lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.draw_buf = &disp_buf;
    //disp_drv.flush_cb = fbdev_flush;    /* fbdev_flush这就是输入显示驱动提供的操作函数 */
    //disp_drv.flush_cb = disp_flush;
	disp_drv.flush_cb = drm_flush;
    disp_drv.hor_res = 480;
    disp_drv.ver_res = 480; 

	lv_disp_t * disp;    
    disp = lv_disp_drv_register(&disp_drv);

	//TP
	evdev_init();
	//lv_port_indev_init();       // 输入设备初始化（如果没有实现就注释掉）
	lv_indev_drv_t indev_drv;
	lv_indev_drv_init(&indev_drv);
	indev_drv.type =LV_INDEV_TYPE_POINTER;
	indev_drv.read_cb =evdev_read;
	lv_indev_drv_register(&indev_drv);




	//KEYPAD
    //lv_indev_drv_t indev_drv2;
	//lv_indev_drv_init(&indev_drv2);
	//indev_drv2.type =LV_INDEV_TYPE_KEYPAD;
	//indev_drv2.read_cb =evdev_read;
	//indev_keypad = lv_indev_drv_register(&indev_drv2);

	//UI
	//lv_demo();
    lv_app();

	
	
	while (1)
	{
		
        //lv_tick_inc(LVGL_TICK);		// tick 提供时钟，LVGL_TICK 一般为 5ms 即可
        lv_timer_handler(); 		// 运行所有lvgl的timer
		//HAL_Delay(LVGL_TICK);
		usleep(5000);
	}
}

/*Set in lv_conf.h as `LV_TICK_CUSTOM_SYS_TIME_EXPR`*/
uint32_t custom_tick_get(void)
{
    static uint64_t start_ms = 0;
    if(start_ms == 0) {
        struct timeval tv_start;
        gettimeofday(&tv_start, NULL);
        start_ms = (tv_start.tv_sec * 1000000 + tv_start.tv_usec) / 1000;
    }

    struct timeval tv_now;
    gettimeofday(&tv_now, NULL);
    uint64_t now_ms;
    now_ms = (tv_now.tv_sec * 1000000 + tv_now.tv_usec) / 1000;

    uint32_t time_ms = now_ms - start_ms;
    //printf("custom_tick_get------------->%d\n",time_ms);
    return time_ms;
}
