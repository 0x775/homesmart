/**
 * @file wifi_connect.h
 *
 */

#ifndef LV_MAIN_H
#define LV_MAIN_H

#ifdef __cplusplus
extern "C"
{
#endif
uint32_t custom_tick_get(void);
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*LV_WIFI_CONNECT_H*/
